import { Renderer } from './renderer.js';
import { SoundEngine } from './audio.js';
import { guests, levelCopy } from './content.js';
import { makeLevel } from './levels.js';
import { WorkshopShooter } from './shooter.js';

const $ = id => document.getElementById(id);
const clamp = (n,a,b) => Math.max(a,Math.min(b,n));
const overlaps = (a,b) => a.x < b.x+b.w && a.x+a.w>b.x && a.y < b.y+b.h && a.y+a.h>b.y;
const approach = (a,b,amount) => a < b ? Math.min(a+amount,b) : Math.max(a-amount,b);
const renderer = new Renderer($('world'));
const sound = new SoundEngine();
const keys = new Set();
const guestById = Object.fromEntries(guests.map(g=>[g.id,g]));
const touchActions = new Map();
let toastTimer, dialogue = null, jumpBuffer = 0, coyote = 0, frameLast = 0, accumulator = 0, hudTick = 0;
let soundOn = false;
sound.setMuted(true);


const game = {
  mode:'menu',mapOpen:false,shooter:null,bonusCompleted:false,resumeMode:'playing',completedLevels:[],time:0,elapsed:0,level:makeLevel(0,guestById),player:{x:710,y:462,w:34,h:48,vx:0,vy:0,facing:1,grounded:true,invincible:0,jumpCount:0,walkPhase:0},
  camera:{x:0,y:0},viewScale:1,particles:[],effects:{shake:0,flash:0},modules:0,score:0,health:3,checkpoint:{x:100,y:640},levelStartScore:0,transitioning:false
};

function resize() {
  renderer.resize();
  game.viewScale = renderer.width<580 ? clamp(renderer.width/620,.58,.95) : clamp(Math.min(renderer.width/1000,renderer.height/650),.50,1.5);
  const worldHeight=renderer.height/game.viewScale;
  game.camera.y = game.mode==='menu' ? Math.max(-100,(game.level.height||760)-worldHeight) : (game.level.height||760)-worldHeight+(renderer.width<580?100:0);
  updateCamera(1,true);
}
function setMenuPose(){const platform=game.level.platforms.find(p=>p.type!=='floor'&&p.x<=710&&p.x+p.w>=744);game.menuPlayerY=(platform?.y||690)-48;Object.assign(game.player,{x:710,y:game.menuPlayerY,vx:0,vy:0,invincible:0,walkPhase:0,grounded:true,support:null});}
window.addEventListener('resize',resize);setMenuPose();resize();

function showToast(message,seconds=4) {
  clearTimeout(toastTimer); $('toast').textContent=message; $('toast').classList.remove('hidden');
  toastTimer=setTimeout(()=>$('toast').classList.add('hidden'),seconds*1000);
}
function burst(x,y,color,count=14) {
  for(let i=0;i<count;i++) {const angle=Math.random()*Math.PI*2, speed=40+Math.random()*150;game.particles.push({x,y,vx:Math.cos(angle)*speed,vy:Math.sin(angle)*speed-40,life:.45+Math.random()*.6,maxLife:1,color,size:2+Math.random()*4});}
}
function closeDialogue(){dialogue=null;$('dialogue').classList.add('hidden');keys.clear();if(game.mode==='playing')$('world').focus({preventScroll:true});}
function talk(){
  if(game.mode!=='playing')return;
  if(dialogue){dialogue.index++;if(dialogue.index>=dialogue.guest.lines.length){closeDialogue();return;}writeDialogue();return;}
  const guest=nearestGuest();if(!guest)return;
  dialogue={guest,index:0};writeDialogue();sound.cue('talk');keys.clear();
}
function writeDialogue(){
  const {guest,index}=dialogue;$('guest-name').textContent=guest.name;$('guest-role').textContent=guest.role;$('guest-line').textContent=guest.lines[index];
  $('portrait').style.color=guest.color;$('portrait').textContent=guest.guestId==='linkedin'?'in':guest.guestId==='pid'?'▣':guest.guestId==='arduino'?'µ':guest.guestId==='coach'?'↗':'⚙';$('dialogue').classList.remove('hidden');$('hint').classList.add('hidden');
}
function nearestGuest(){return game.level.npcs.find(n=>Math.abs(n.x-(game.player.x+17))<115&&Math.abs(n.y-game.player.y)<95);}
function syncUI(){
  const active=game.mode!=='menu';$('menu').classList.toggle('hidden',active);$('hud').classList.toggle('hidden',!active||game.mode==='shooting'||game.mode==='briefing'||game.resumeMode==='shooting'&&game.mode==='paused');
  $('touch-controls').classList.toggle('hidden',game.mode!=='playing');$('shoot-touch').classList.toggle('hidden',game.mode!=='shooting');$('game-caption').classList.toggle('hidden',game.mode!=='playing');
  for(const [id,mode] of [['pause-overlay','paused'],['dead-overlay','dead'],['won-overlay','won'],['shooter-briefing','briefing']])$(id).classList.toggle('hidden',game.mode!==mode||game.mapOpen);
  const shootingPause=game.resumeMode==='shooting';
  $('pause-copy').textContent=shootingPause?'Pilote le drone avec les flèches et maintiens Espace ou X pour tirer. Détruis les trois noyaux défectueux, puis reprends le semestre à Pivotland.':'Récupère les 3 modules lumineux de chaque niveau, puis rejoins la sortie. Saute sur les robots pour les désactiver.';
  $('pause-controls').classList.toggle('hidden',shootingPause);$('resume-label').textContent=shootingPause?'REPRENDRE LE BANC D’ESSAI':'RETOUR AU LABO';
  $('map-overlay').classList.toggle('hidden',!game.mapOpen);$('shoot-pause').classList.toggle('hidden',game.mode!=='shooting');
  document.querySelectorAll('[data-map-level]').forEach(el=>{const i=Number(el.dataset.mapLevel);el.classList.toggle('map-complete',game.completedLevels.includes(i));el.classList.toggle('map-current',active&&i===game.level.index);el.querySelector('.map-status').textContent=game.completedLevels.includes(i)?'VALIDÉ':active&&i===game.level.index?'EN COURS':'À DÉCOUVRIR';});
  $('level-number').textContent=`0${game.level.index+1} / 04`;$('level-name').textContent=game.level.name;$('level-subtitle').textContent=game.level.subtitle;
  $('mission-label').textContent=game.level.index===2?'PREUVES DE TRAVAIL RÉEL':'MODULES VALIDÉS';$('module-count').textContent=`${game.modules} / 3`;
  [...$('modules').children].forEach((el,i)=>el.classList.toggle('active',i<game.modules));$('score').textContent=String(game.score).padStart(3,'0');
  $('health').textContent=Array.from({length:3},(_,i)=>i<game.health?'♥':'♡').join(' ');
}
function loadLevel(index){
  game.resumeMode='playing';game.level=makeLevel(index,guestById);game.modules=0;game.health=3;game.checkpoint={x:100,y:640};game.levelStartScore=game.score;game.transitioning=false;game.exitHintAt=-10;resize();
  Object.assign(game.player,{x:100,y:640,vx:0,vy:0,jumpCount:0,grounded:false,invincible:1,walkPhase:0,support:null});game.particles=[];game.effects.shake=0;game.camera.x=0;
  keys.clear();jumpBuffer=0;coyote=0;closeDialogue();sound.setScene(index);syncUI();updateCamera(1,true);
  showToast(game.level.brief,6);
}
function startGame(){
  game.mode='playing';game.mapOpen=false;game.shooter=null;game.bonusCompleted=false;game.completedLevels=[];game.score=0;game.elapsed=0;loadLevel(0);syncUI();sound.start();$('world').focus({preventScroll:true});
  setTimeout(()=>{if(game.mode==='playing'&&game.level.index===0)showToast('Espace ou ↑ : deux sauts. Trois modules cyan ouvrent la sortie. E : écouter les guests.',6);},6500);
}
function togglePause(){
  if(dialogue){closeDialogue();return;}
  if(game.mapOpen){closeMap();return;}
  if(game.mode==='playing'||game.mode==='shooting'){game.resumeMode=game.mode;game.mode='paused';keys.clear();jumpBuffer=0;sound.pause();}
  else if(game.mode==='paused'){game.mode=game.resumeMode||'playing';sound.start();$('world').focus({preventScroll:true});}
  syncUI();
}
let mapResumeOnClose=false;
function openMap(){mapResumeOnClose=game.mode==='playing'||game.mode==='shooting';if(mapResumeOnClose)togglePause();game.mapOpen=true;syncUI();}
function closeMap(){game.mapOpen=false;if(mapResumeOnClose&&game.mode==='paused')togglePause();else syncUI();mapResumeOnClose=false;}
function returnToMenu(){
  closeDialogue();keys.clear();sound.pause();game.mode='menu';game.mapOpen=false;game.shooter=null;game.resumeMode='playing';game.level=makeLevel(0,guestById);game.modules=0;game.particles=[];
  setMenuPose();resize();$('toast').classList.add('hidden');$('hint').classList.add('hidden');syncUI();
}
function setSound(){
  soundOn=!soundOn;sound.setMuted(!soundOn);$('sound').querySelector('span').textContent=soundOn?'SON ON':'SON OFF';$('sound').setAttribute('aria-label',soundOn?'Couper le son':'Activer le son');$('sound').title=soundOn?'Couper le son':'Activer le son';
  if(soundOn&&['playing','shooting','menu'].includes(game.mode))sound.start();if(['playing','shooting'].includes(game.mode))$('world').focus({preventScroll:true});
}
function respawn(){
  Object.assign(game.player,{x:game.checkpoint.x,y:game.checkpoint.y,vx:0,vy:0,invincible:2,jumpCount:0,grounded:false,support:null});game.effects.shake=.22;jumpBuffer=0;coyote=0;keys.clear();closeDialogue();updateCamera(1,true);
}
function damage(reason){
  if(game.player.invincible>0||game.mode!=='playing')return;
  game.health--;sound.cue('hit');burst(game.player.x+17,game.player.y+25,'#ff8f6b',24);game.effects.flash=.18;
  if(game.health<=0){game.mode='dead';game.resumeMode='playing';$('death-title').textContent=reason==='fall'?'La gravité a raison.':'Tolérance dépassée.';$('death-copy').textContent='Ça compte comme un retour d’expérience. Tes modules sont conservés : on a déjà assez souffert en projet de groupe.';$('retry-label').textContent='REPRENDRE AU CHECKPOINT';sound.pause();closeDialogue();}
  else{respawn();showToast(reason==='fall'?'Chute non prévue dans le cahier des charges.':'Le prototype a choisi la violence. Caféine vitale −1.',3);}
  syncUI();
}
function win(){
  game.mode='won';keys.clear();closeDialogue();$('hint').classList.add('hidden');$('toast').classList.add('hidden');sound.cue('win');$('best').textContent=`DERNIER SEMESTRE : ${game.score} BOULONS · DIPLÔMÉ, MAIS FATIGUÉ.`;$('final-score').textContent=game.score;$('final-time').textContent=`${Math.floor(game.elapsed/60)}:${String(Math.floor(game.elapsed%60)).padStart(2,'0')}`;
  try{const prev=JSON.parse(localStorage.getItem('mecaPanicBest')||'null');if(!prev||game.score>prev.score)localStorage.setItem('mecaPanicBest',JSON.stringify({score:game.score,time:Math.floor(game.elapsed)}));}catch{}
  syncUI();
}
function nextLevel(){
  if(game.transitioning)return;game.transitioning=true;keys.clear();sound.cue('checkpoint');
  if(!game.completedLevels.includes(game.level.index))game.completedLevels.push(game.level.index);
  if(game.level.index===3){win();return;}
  if(game.level.index===1&&!game.bonusCompleted){game.mode='briefing';game.shooter=new WorkshopShooter({sound});closeDialogue();$('hint').classList.add('hidden');$('toast').classList.add('hidden');sound.pause();syncUI();return;}
  loadLevel(game.level.index+1);showToast(levelCopy[game.level.index-1].completion,5);
}
function startShooter(){game.mode='shooting';game.resumeMode='shooting';keys.clear();game.shooter=game.shooter||new WorkshopShooter({sound});sound.setScene(1);sound.start();$('world').focus({preventScroll:true});syncUI();}
function updateShooter(dt){
  const input={left:keys.has('ArrowLeft')||keys.has('KeyQ')||keys.has('KeyA'),right:keys.has('ArrowRight')||keys.has('KeyD'),up:keys.has('ArrowUp')||keys.has('KeyW'),down:keys.has('ArrowDown')||keys.has('KeyS'),shoot:keys.has('Space')||keys.has('KeyZ')||keys.has('KeyX')};
  game.elapsed+=dt;const result=game.shooter.update(dt,input);
  if(result==='won'){game.bonusCompleted=true;game.score+=game.shooter.score||50;game.mode='playing';game.resumeMode='playing';keys.clear();loadLevel(2);showToast('Prototype réparé ! Retour aux plateformes. Kevin Synergie veut s’attribuer le succès.',6);}
  else if(result==='lost'){game.mode='dead';game.resumeMode='shooting';keys.clear();$('death-title').textContent='Prototype en panne.';$('death-copy').textContent='Le banc d’essai a déclaré forfait. Relance le mini-jeu : ton parcours et tes modules sont conservés.';$('retry-label').textContent='RELANCER LE BANC D’ESSAI';sound.pause();syncUI();}
}
function requestJump(){if(game.mode==='playing'&&!dialogue)jumpBuffer=.14;}
function updateCamera(dt,snap=false){
  if(game.mode==='menu'){game.camera.x=0;return;}
  const vw=renderer.width/game.viewScale,target=clamp(game.player.x-vw*.39,0,Math.max(0,game.level.width-vw));
  game.camera.x=snap?target:game.camera.x+(target-game.camera.x)*(1-Math.exp(-dt*6));
  const vh=renderer.height/game.viewScale,baseY=(game.level.height||760)-vh+(renderer.width<580?100:0);
  const targetY=baseY>0?clamp(game.player.y-vh*.43,0,baseY):baseY;
  game.camera.y=snap?targetY:game.camera.y+(targetY-game.camera.y)*(1-Math.exp(-dt*6));
}
function physics(dt){
  const p=game.player,l=game.level;
  if(dialogue){p.vx=0;updateCamera(dt);return;}
  l.motionTime=(l.motionTime||0)+dt;
  for(const plat of l.platforms){
    const oldX=plat.x,oldY=plat.y;plat.dx=0;plat.dy=0;
    if(plat.type==='moving'){
      plat.baseX??=plat.x;plat.baseY??=plat.y;
      const wave=Math.sin(l.motionTime/(plat.period||5)*Math.PI*2+(plat.phase||0));
      plat.x=plat.baseX+(plat.amplitudeX||0)*wave;plat.y=plat.baseY+(plat.amplitudeY||0)*wave;plat.dx=plat.x-oldX;plat.dy=plat.y-oldY;
    }
    if(p.grounded&&p.support===plat){p.x+=plat.dx+(plat.type==='conveyor'?(plat.beltDir||1)*(plat.beltSpeed||60)*dt:0);p.y+=plat.dy;}
  }
  game.elapsed+=dt; p.invincible=Math.max(0,p.invincible-dt);jumpBuffer=Math.max(0,jumpBuffer-dt);
  if(p.grounded)coyote=.11;else coyote=Math.max(0,coyote-dt);
  const left=keys.has('ArrowLeft')||keys.has('KeyQ')||keys.has('KeyA'),right=keys.has('ArrowRight')||keys.has('KeyD');
  const direction=Number(right)-Number(left);
  p.vx=approach(p.vx,direction*300,dt*(p.grounded?2050:1500));if(direction)p.facing=direction;
  if(jumpBuffer>0&&(p.grounded||coyote>0||p.jumpCount<2)){
    const first=p.grounded||coyote>0;
    p.vy=first?-650:-610;p.jumpCount=first?1:p.jumpCount+1;p.grounded=false;p.support=null;coyote=0;jumpBuffer=0;
    sound.cue(first?'jump':'doubleJump');burst(p.x+17,p.y+48,first?'#f5cf63':'#85e7d4',first?6:12);
  }
  const oldY=p.y;
  p.vy=Math.min(p.vy+1550*dt,1000);
  p.x=clamp(p.x+p.vx*dt,0,l.width-p.w);
  for(const plat of l.platforms)if(plat.type==='floor'&&overlaps(p,plat)&&oldY+p.h>plat.y+8){
    if(p.vx>0)p.x=plat.x-p.w;else if(p.vx<0)p.x=plat.x+plat.w;
  }
  p.y+=p.vy*dt;p.grounded=false;p.support=null;
  for(const plat of l.platforms){
    if(p.x+p.w>plat.x+2&&p.x<plat.x+plat.w-2&&p.vy>=0&&oldY+p.h<=plat.y+3+Math.abs(plat.dy||0)&&p.y+p.h>=plat.y){p.y=plat.y-p.h;p.vy=0;p.grounded=true;p.jumpCount=0;p.support=plat;}
  }
  p.walkPhase+=Math.abs(p.vx)*dt*.06;
  for(const item of l.pickups){
    if(item.collected||Math.abs(item.x-(p.x+17))>31||Math.abs(item.y-(p.y+23))>39)continue;
    item.collected=true;burst(item.x,item.y,item.type==='module'?'#7ce4d7':'#f5cf63',item.type==='module'?25:10);sound.cue(item.type);
    if(item.type==='module'){game.modules++;game.score+=25;l.exit.open=game.modules===3;showToast(game.modules===3?'3 / 3 — Sortie ouverte. Le rapport peut attendre.':`${game.modules} / 3 — ${l.index===2?'Une preuve de travail réel. Kevin est confus.':'Module validé. Sans réunion supplémentaire.'}`,3);}
    else if(item.type==='coffee'){game.health=Math.min(3,game.health+1);showToast('Café obtenu. Les lois de la thermodynamique peuvent patienter.',3);}
    else game.score++;
    syncUI();
  }
  for(const enemy of l.enemies){
    if(!enemy.alive)continue;enemy.x+=enemy.dir*enemy.speed*dt;
    if(enemy.bobAmp){enemy.baseY??=enemy.y;enemy.y=enemy.baseY+Math.sin(l.motionTime/(enemy.bobPeriod||3)*Math.PI*2+(enemy.phase||0))*enemy.bobAmp;}
    if(enemy.x>enemy.max){enemy.x=enemy.max;enemy.dir=-1;}if(enemy.x<enemy.min){enemy.x=enemy.min;enemy.dir=1;}
    if(!overlaps(p,enemy))continue;
    if(p.vy>30&&oldY+p.h<=enemy.y+13){enemy.alive=false;p.vy=-410;p.jumpCount=1;game.score+=5;burst(enemy.x+enemy.w/2,enemy.y+15,l.index===2?'#bc9bf8':'#ff9269',18);sound.cue('stomp');if(l.index===2)showToast(`« ${(enemy.label||'bullshit').toLowerCase()} » neutralisé. Enfin du concret.`,2);syncUI();}
    else damage('hit');
  }
  for(const h of l.hazards)if(overlaps(p,h))damage('hit');
  if(p.y>840)damage('fall');
  for(const cp of l.checkpoints)if(!cp.active&&p.x>cp.x){cp.active=true;game.checkpoint={x:cp.x+20,y:cp.y-p.h};sound.cue('checkpoint');burst(cp.x,cp.y-45,'#8de9ce',15);showToast('Checkpoint enregistré. Le fichier ne s’appelle plus final_FINAL_v12.',3);}
  if(overlaps(p,l.exit)){if(l.exit.open)nextLevel();else if(!game.exitHintAt||game.elapsed-game.exitHintAt>5){game.exitHintAt=game.elapsed;showToast('Accès refusé : il manque des modules cyan. Oui, même si ton rapport fait 80 pages.',4);}}
  updateCamera(dt);
  const guest=nearestGuest();$('hint').classList.toggle('hidden',!guest||!!dialogue);if(guest)$('hint').querySelector('span').textContent=`Parler à ${guest.name}`;
}

function frame(ms){
  const dt=Math.min((ms-(frameLast||ms))/1000,.05);frameLast=ms;game.time+=dt;
  if(game.mode==='playing'||game.mode==='shooting'){accumulator+=dt;while(accumulator>=1/120){const mode=game.mode;if(mode==='playing')physics(1/120);else updateShooter(1/120);accumulator-=1/120;if(game.mode!==mode){accumulator=0;break;}}}else accumulator=0;
  game.effects.shake=Math.max(0,game.effects.shake-dt);game.effects.flash=Math.max(0,game.effects.flash-dt);
  for(const particle of game.particles){particle.life-=dt;particle.x+=particle.vx*dt;particle.y+=particle.vy*dt;particle.vy+=220*dt;}
  game.particles=game.particles.filter(p=>p.life>0);
  if(game.mode==='menu'){game.player.walkPhase=0;game.player.y=game.menuPlayerY+Math.sin(game.time*2)*2;}
  if(game.shooter&&(game.mode==='shooting'||game.mode==='paused'&&game.resumeMode==='shooting'||game.mode==='dead'&&game.resumeMode==='shooting'))game.shooter.render($('world'),game.time);else renderer.render(game,dt);
  hudTick+=dt;if(hudTick>.2){hudTick=0;if(game.mode==='playing'||game.mode==='shooting')syncUI();}
  requestAnimationFrame(frame);
}

document.addEventListener('keydown',e=>{
  const control=['ArrowLeft','ArrowRight','ArrowUp','ArrowDown','Space','KeyQ','KeyD','KeyA','KeyE','KeyP','Escape','KeyZ','KeyX','KeyW','KeyS','KeyM'];
  if(control.includes(e.code)&&!(e.target instanceof HTMLButtonElement&&e.code==='Space'))e.preventDefault();
  if(e.repeat){if(game.mode==='shooting'||['ArrowLeft','ArrowRight','KeyQ','KeyD','KeyA'].includes(e.code))keys.add(e.code);return;}
  if(e.code==='Escape'||e.code==='KeyP'){togglePause();return;}
  if(e.code==='KeyM'){if(game.mapOpen)closeMap();else openMap();return;}
  if(game.mapOpen)return;
  if(game.mode==='shooting'){keys.add(e.code);return;}
  if(game.mode==='menu'&&(e.code==='Enter'||e.code==='Space')){startGame();return;}
  if(e.code==='KeyE'||e.code==='ArrowDown'){talk();return;}
  if(e.code==='Space'||e.code==='ArrowUp'){requestJump();return;}
  keys.add(e.code);
});
document.addEventListener('keyup',e=>keys.delete(e.code));
window.addEventListener('blur',()=>{keys.clear();if(['playing','shooting'].includes(game.mode)&&!dialogue)togglePause();});
document.addEventListener('visibilitychange',()=>{if(document.hidden&&['playing','shooting'].includes(game.mode)){closeDialogue();togglePause();}});
$('start').addEventListener('click',startGame);$('again').addEventListener('click',startGame);$('restart').addEventListener('click',startGame);
$('pause').addEventListener('click',togglePause);$('shoot-pause').addEventListener('click',togglePause);$('resume').addEventListener('click',togglePause);$('sound').addEventListener('click',setSound);
$('retry').addEventListener('click',()=>{if(game.resumeMode==='shooting'){game.shooter.reset();startShooter();return;}game.health=3;game.mode='playing';respawn();syncUI();sound.start();$('world').focus({preventScroll:true});});
$('start-shooter').addEventListener('click',startShooter);$('return-home').addEventListener('click',returnToMenu);$('pause-home').addEventListener('click',returnToMenu);
$('menu-map').addEventListener('click',openMap);$('pause-map').addEventListener('click',openMap);$('close-map').addEventListener('click',closeMap);
$('next-dialogue').addEventListener('click',talk);$('close-dialogue').addEventListener('click',closeDialogue);
document.querySelector('.brand').addEventListener('click',e=>{e.preventDefault();if(['playing','shooting'].includes(game.mode))togglePause();});
$('fullscreen').addEventListener('click',async()=>{try{if(document.fullscreenElement)await document.exitFullscreen();else await document.documentElement.requestFullscreen();}catch{showToast('Le navigateur ne propose pas le plein écran ici. Le labo reste ouvert.',4);}});
for(const button of document.querySelectorAll('[data-action]')){
  button.addEventListener('pointerdown',e=>{e.preventDefault();button.setPointerCapture(e.pointerId);const action=button.dataset.action;touchActions.set(e.pointerId,action);if(action==='jump')requestJump();else if(action==='talk')talk();else keys.add(action==='left'?'ArrowLeft':'ArrowRight');});
  const release=e=>{const action=touchActions.get(e.pointerId);if(action==='left'||action==='right')keys.delete(action==='left'?'ArrowLeft':'ArrowRight');touchActions.delete(e.pointerId);};
  button.addEventListener('pointerup',release);button.addEventListener('pointercancel',release);button.addEventListener('lostpointercapture',release);
}
for(const button of document.querySelectorAll('[data-shoot-action]')){
  const key={left:'ArrowLeft',right:'ArrowRight',up:'ArrowUp',down:'ArrowDown',fire:'Space'}[button.dataset.shootAction];
  button.addEventListener('pointerdown',e=>{e.preventDefault();button.setPointerCapture(e.pointerId);keys.add(key);});
  const release=()=>keys.delete(key);button.addEventListener('pointerup',release);button.addEventListener('pointercancel',release);button.addEventListener('lostpointercapture',release);
}
try{const best=JSON.parse(localStorage.getItem('mecaPanicBest')||'null');if(best)$('best').textContent=`MEILLEUR SEMESTRE : ${best.score} BOULONS · DIPLÔMÉ, MAIS FATIGUÉ.`;}catch{}
syncUI();requestAnimationFrame(frame);

// Read-only snapshot for regression checks and browser accessibility tools.
window.mecaPanic = Object.freeze({snapshot:()=>({mode:game.mode,level:game.level.index,modules:game.modules,score:game.score,health:game.health,elapsed:game.elapsed,bonusCompleted:game.bonusCompleted,completedLevels:[...game.completedLevels],player:{x:game.player.x,y:game.player.y,vx:game.player.vx,vy:game.player.vy,jumpCount:game.player.jumpCount,grounded:game.player.grounded},exitOpen:game.level.exit.open,checkpoint:{...game.checkpoint},camera:{...game.camera},dialogue:dialogue?{guest:dialogue.guest.name,line:dialogue.index}:null,shooter:game.shooter?{health:game.shooter.health,cores:game.shooter.cores,elapsed:game.shooter.elapsed}:null})});
