/** Small, self-contained workshop synthesizer. Activate from a user gesture. */
export class SoundEngine {
  constructor() {
    this.context = null;
    this.master = null;
    this.muted = false;
    this.running = false;
    this.scene = 0;
    this._timer = null;
    this._voices = new Set();
    this._step = 0;
    this._nextBeat = 0;
    this._lastCue = Object.create(null);
    this._noiseBuffer = null;
    this._activation = 0;
  }

  _init() {
    if (this.context) return true;
    const AudioContext = globalThis.AudioContext || globalThis.webkitAudioContext;
    if (!AudioContext) return false;
    try {
      this.context = new AudioContext();
      this.master = this.context.createGain();
      this.master.gain.value = this.muted ? 0 : 0.48;
      const compressor = this.context.createDynamicsCompressor();
      compressor.threshold.value = -18;
      compressor.knee.value = 18;
      compressor.ratio.value = 4;
      this.master.connect(compressor);
      compressor.connect(this.context.destination);
      this._noiseBuffer = this.context.createBuffer(1, this.context.sampleRate, this.context.sampleRate);
      const samples = this._noiseBuffer.getChannelData(0);
      for (let i = 0; i < samples.length; i++) samples[i] = Math.random() * 2 - 1;
      return true;
    } catch {
      this.context = null;
      this.master = null;
      return false;
    }
  }

  async start() {
    if (!this._init()) return false;
    if (this.running) {
      try { await this.context.resume(); } catch { return false; }
      return true;
    }
    const activation = ++this._activation;
    this.running = true;
    try {
      await this.context.resume();
      if (!this.running || activation !== this._activation) return false;
      this._nextBeat = this.context.currentTime + 0.08;
      this._step = 0;
      this._schedule();
      return true;
    } catch {
      this.running = false;
      return false;
    }
  }

  setMuted(muted) {
    this.muted = Boolean(muted);
    if (this.context && this.master) {
      const now = this.context.currentTime;
      this.master.gain.cancelScheduledValues(now);
      this.master.gain.setTargetAtTime(this.muted ? 0 : 0.48, now, 0.025);
    }
    return this.muted;
  }

  setScene(index) {
    this.scene = Math.max(0, Math.min(3, Number(index) | 0));
    this._step = 0;
  }

  pause() {
    this.running = false;
    ++this._activation;
    if (this._timer !== null) clearTimeout(this._timer);
    this._timer = null;
    for (const voice of this._voices) {
      try { voice.stop(); } catch { /* The voice may already have ended. */ }
    }
    this._voices.clear();
    if (this.context?.state === 'running') this.context.suspend().catch(() => {});
  }

  stop() { this.pause(); }

  _frequency(note) { return 440 * 2 ** ((note - 69) / 12); }

  _tone(note, at, duration, gain = 0.08, type = 'triangle', endNote = note) {
    if (!this.context || !this.master) return;
    const osc = this.context.createOscillator();
    const envelope = this.context.createGain();
    osc.type = type;
    osc.frequency.setValueAtTime(this._frequency(note), at);
    if (endNote !== note) osc.frequency.exponentialRampToValueAtTime(this._frequency(endNote), at + duration * 0.8);
    envelope.gain.setValueAtTime(0.0001, at);
    envelope.gain.exponentialRampToValueAtTime(Math.max(0.0001, gain), at + 0.009);
    envelope.gain.exponentialRampToValueAtTime(0.0001, at + duration);
    osc.connect(envelope);
    envelope.connect(this.master);
    this._voices.add(osc);
    osc.onended = () => {
      this._voices.delete(osc);
      osc.disconnect();
      envelope.disconnect();
    };
    osc.start(at);
    osc.stop(at + duration + 0.02);
  }

  _noise(at, duration, gain = 0.07, frequency = 1200) {
    if (!this.context || !this._noiseBuffer) return;
    const source = this.context.createBufferSource();
    const filter = this.context.createBiquadFilter();
    const envelope = this.context.createGain();
    source.buffer = this._noiseBuffer;
    filter.type = 'bandpass';
    filter.frequency.value = frequency;
    filter.Q.value = 1.1;
    envelope.gain.setValueAtTime(gain, at);
    envelope.gain.exponentialRampToValueAtTime(0.0001, at + duration);
    source.connect(filter);
    filter.connect(envelope);
    envelope.connect(this.master);
    this._voices.add(source);
    source.onended = () => {
      this._voices.delete(source);
      source.disconnect();
      filter.disconnect();
      envelope.disconnect();
    };
    source.start(at);
    source.stop(at + duration + 0.02);
  }

  _schedule() {
    if (!this.running || !this.context) return;
    this._timer = null;
    const now = this.context.currentTime;
    if (this._nextBeat < now - 0.3) this._nextBeat = now + 0.04;
    const stepDuration = 60 / 104 / 2;
    while (this._nextBeat < now + 0.35) {
      if (!this.muted) this._musicStep(this._step, this._nextBeat, stepDuration);
      this._step = (this._step + 1) % 64;
      this._nextBeat += stepDuration;
    }
    this._timer = setTimeout(() => this._schedule(), 110);
  }

  _musicStep(step, at, duration) {
    // A quiet pentatonic melody, a round bass, and tiny metallic workshop ticks.
    const sceneRoots = [[50, 55, 57, 55], [45, 48, 50, 52], [47, 52, 54, 52], [48, 53, 55, 57]];
    const root = sceneRoots[this.scene][Math.floor(step / 16)];
    const motif = [12, null, 19, 16, null, 21, 19, null, 16, null, 14, 19, null, 16, 12, null];
    const melody = motif[step % 16];
    if (melody !== null) {
      this._tone(root + melody, at, duration * 1.45, 0.025, 'triangle');
      // The very quiet upper harmonic gives the notes a glass-and-metal shimmer.
      this._tone(root + melody + 12, at + 0.016, duration * 0.7, 0.007, 'sine');
    }
    if (step % 4 === 0) {
      this._tone(root - 12, at, duration * 2.8, 0.043, 'sine');
      this._tone(38, at, 0.11, 0.032, 'sine', 24);
    }
    if (step % 8 === 4) this._noise(at, 0.06, 0.014, 1500);
    if (step % 2 === 1) this._noise(at, 0.027, 0.007, 6200);
  }

  cue(name) {
    if (!this.context || !this.running || this.muted) return;
    const at = this.context.currentTime + 0.005;
    if (at - (this._lastCue[name] ?? -Infinity) < 0.04) return;
    this._lastCue[name] = at;
    try {
      switch (name) {
        case 'jump':
          this._tone(55, at, 0.16, 0.095, 'triangle', 72);
          break;
        case 'doubleJump':
          this._tone(67, at, 0.18, 0.085, 'triangle', 84);
          this._tone(79, at + 0.055, 0.12, 0.035, 'sine', 88);
          break;
        case 'bolt':
          this._tone(83, at, 0.09, 0.08, 'triangle');
          this._tone(90, at + 0.055, 0.16, 0.055, 'sine');
          break;
        case 'module':
          [64, 71, 76, 83].forEach((note, i) => this._tone(note, at + i * 0.07, 0.25, 0.07));
          break;
        case 'coffee':
          [60, 64, 67, 72].forEach((note, i) => this._tone(note, at + i * 0.055, 0.17, 0.055, 'sine'));
          this._noise(at, 0.16, 0.025, 2200);
          break;
        case 'hit':
          this._tone(48, at, 0.25, 0.11, 'sawtooth', 29);
          this._noise(at, 0.22, 0.11, 650);
          break;
        case 'stomp':
          this._tone(45, at, 0.12, 0.1, 'triangle', 31);
          this._noise(at, 0.055, 0.055, 900);
          break;
        case 'checkpoint':
          [62, 66, 69, 74].forEach((note, i) => this._tone(note, at + i * 0.09, 0.34, 0.065, 'triangle'));
          break;
        case 'win':
          [60, 64, 67, 72, 76, 79, 84].forEach((note, i) => this._tone(note, at + i * 0.11, 0.4, 0.075));
          [60, 64, 67].forEach(note => this._tone(note, at + 0.88, 1.2, 0.045, 'sine'));
          break;
        case 'talk':
          this._tone(70, at, 0.075, 0.037, 'triangle', 74);
          this._tone(67, at + 0.085, 0.07, 0.03, 'triangle');
          break;
      }
    } catch { /* Sound must never prevent the game from running. */ }
  }
}
