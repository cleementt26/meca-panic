const TAU = Math.PI * 2;
const P = {
  ink: '#06171f', navy: '#09252f', steel: '#16454d', teal: '#40d5c6',
  mint: '#b5fff0', gold: '#ffd46b', orange: '#f9a945', cream: '#f5edcf',
  red: '#ff6c78', pink: '#e87da5', blue: '#6cdcff', muted: '#669594',
};

function round(c, x, y, w, h, r = 8) {
  r = Math.min(r, Math.abs(w) / 2, Math.abs(h) / 2);
  c.beginPath();
  c.moveTo(x + r, y); c.arcTo(x + w, y, x + w, y + h, r);
  c.arcTo(x + w, y + h, x, y + h, r); c.arcTo(x, y + h, x, y, r);
  c.arcTo(x, y, x + w, y, r); c.closePath();
}
function rect(c, x, y, w, h, fill, r = 0, stroke = null, line = 1) {
  if (r) round(c, x, y, w, h, r); else { c.beginPath(); c.rect(x, y, w, h); }
  if (fill) { c.fillStyle = fill; c.fill(); }
  if (stroke) { c.strokeStyle = stroke; c.lineWidth = line; c.stroke(); }
}
function line(c, x1, y1, x2, y2, color, width = 1) {
  c.beginPath(); c.moveTo(x1, y1); c.lineTo(x2, y2); c.strokeStyle = color;
  c.lineWidth = width; c.stroke();
}
function circle(c, x, y, r, fill, stroke = null, lw = 1) {
  c.beginPath(); c.arc(x, y, r, 0, TAU);
  if (fill) { c.fillStyle = fill; c.fill(); }
  if (stroke) { c.strokeStyle = stroke; c.lineWidth = lw; c.stroke(); }
}
function ellipse(c, x, y, rx, ry, fill) {
  c.beginPath(); c.ellipse(x, y, rx, ry, 0, 0, TAU); c.fillStyle = fill; c.fill();
}
function label(c, text, x, y, size = 12, color = P.cream, align = 'left', weight = 600) {
  c.font = `${weight} ${size}px "Trebuchet MS", system-ui, sans-serif`;
  c.fillStyle = color; c.textAlign = align; c.textBaseline = 'middle'; c.fillText(text, x, y);
}
function hash(n) { const v = Math.sin(n * 127.1 + 311.7) * 43758.5453; return v - Math.floor(v); }
function gear(c, x, y, r, teeth, rotation, fill, rim, hub = true) {
  c.save(); c.translate(x, y); c.rotate(rotation); c.beginPath();
  for (let i = 0; i < teeth * 4; i++) {
    const a = i / (teeth * 4) * TAU;
    const rad = i % 4 === 1 || i % 4 === 2 ? r : r * .87;
    const px = Math.cos(a) * rad, py = Math.sin(a) * rad;
    if (!i) c.moveTo(px, py); else c.lineTo(px, py);
  }
  c.closePath(); c.fillStyle = fill; c.fill();
  if (rim) { c.strokeStyle = rim; c.lineWidth = 2; c.stroke(); }
  circle(c, 0, 0, r * .68, null, rim || '#17434a', 2);
  if (hub) {
    for (let i = 0; i < 6; i++) {
      const a = i / 6 * TAU;
      line(c, Math.cos(a) * r * .2, Math.sin(a) * r * .2, Math.cos(a) * r * .65, Math.sin(a) * r * .65, rim || '#17434a', r * .085);
    }
    circle(c, 0, 0, r * .22, fill, rim || '#17434a', 2);
    circle(c, 0, 0, r * .085, rim || '#17434a');
  }
  c.restore();
}

export class Renderer {
  constructor(canvas) {
    this.canvas = canvas;
    this.ctx = canvas.getContext('2d', { alpha: false });
    this.width = 1000; this.height = 650; this.dpr = 1; this.elapsed = 0;
    this.resize();
  }

  resize() {
    const bounds = this.canvas.getBoundingClientRect();
    this.width = Math.max(1, bounds.width || window.innerWidth || 1000);
    this.height = Math.max(1, bounds.height || window.innerHeight || 650);
    this.dpr = Math.min(window.devicePixelRatio || 1, 2);
    this.canvas.width = Math.round(this.width * this.dpr);
    this.canvas.height = Math.round(this.height * this.dpr);
    this.ctx.setTransform(this.dpr, 0, 0, this.dpr, 0, 0);
  }

  render(game, dt = 1 / 60) {
    this.elapsed += Math.min(dt || 0, .05);
    const c = this.ctx, t = Number.isFinite(game.time) ? game.time : this.elapsed;
    const level = game.level;
    c.setTransform(this.dpr, 0, 0, this.dpr, 0, 0);
    c.globalAlpha = 1; c.shadowBlur = 0;
    this.background(game, t);
    if (!level) return;
    const scale = game.viewScale || 1, camera = game.camera || { x: 0, y: 0 };
    const shake = Math.min(game.effects?.shake || 0, 1) * 20;
    c.save();
    c.translate(shake ? Math.sin(t * 97) * shake : 0, shake ? Math.cos(t * 83) * shake * .6 : 0);
    c.scale(scale, scale); c.translate(-camera.x, -camera.y);
    this.worldBackdrop(game, t);
    for (const cp of level.checkpoints || []) this.checkpoint(cp, t);
    for (const p of level.platforms || []) if (this.visible(p, game, 90)) this.platform(p, t, level.index || 0);
    for (const h of level.hazards || []) if (this.visible(h, game, 90)) this.hazard(h, t);
    if (level.exit) this.exit(level.exit, game, t);
    for (const item of level.pickups || []) if (!item.collected && this.visible(item, game, 70)) this.pickup(item, t);
    for (const npc of level.npcs || []) if (this.visible(npc, game, 100)) this.npc(npc, t);
    for (const enemy of level.enemies || []) if (enemy.alive && this.visible(enemy, game, 80)) this.enemy(enemy, t);
    if (game.player) this.player(game.player, t, game.mode);
    this.particles(game.particles || []);
    c.restore();
    this.foreground(game, t);
    if ((game.effects?.flash || 0) > 0) {
      c.fillStyle = `rgba(255,245,205,${Math.min(game.effects.flash * .5, .35)})`;
      c.fillRect(0, 0, this.width, this.height);
    }
  }

  visible(o, game, padding = 0) {
    const cx = game.camera?.x || 0, cy = game.camera?.y || 0, s = game.viewScale || 1;
    return o.x + (o.w || 80) > cx - padding && o.x < cx + this.width / s + padding &&
      o.y + (o.h || 120) > cy - padding && o.y < cy + this.height / s + padding;
  }

  background(game, t) {
    const c = this.ctx, w = this.width, h = this.height;
    const camera = game.camera || { x: 0, y: 0 }, s = game.viewScale || 1;
    const index = game.level?.index || 0;
    const sky = c.createLinearGradient(0, 0, 0, h);
    sky.addColorStop(0, index === 2 ? '#231c38' : index === 3 ? '#222c2e' : '#081f2b');
    sky.addColorStop(.6, index === 2 ? '#294256' : index === 1 ? '#104d55' : index === 3 ? '#42514a' : '#12474d');
    sky.addColorStop(1, '#062028');
    c.fillStyle = sky; c.fillRect(0, 0, w, h);

    if (index > 0) {
      this.universeBackground(index, camera, s, t);
      return;
    }

    // The circular reactor is a landmark, offset in depth as the camera moves.
    const reactorX = w * .76 - camera.x * s * .035;
    const reactorY = h * .35 - camera.y * s * .06;
    const radius = Math.min(w * .205, h * .39);
    const glow = c.createRadialGradient(reactorX, reactorY, radius * .2, reactorX, reactorY, radius * 1.9);
    glow.addColorStop(0, 'rgba(73,220,190,.17)'); glow.addColorStop(1, 'rgba(30,160,155,0)');
    c.fillStyle = glow; c.fillRect(0, 0, w, h);
    c.save(); c.globalAlpha = .28;
    gear(c, reactorX, reactorY, radius, 32, t * .024, '#164b50', '#54a59b');
    circle(c, reactorX, reactorY, radius * .78, '#123e47', '#3d8780', 1);
    c.setLineDash([3, 13]); circle(c, reactorX, reactorY, radius * .73, null, '#77beb0', 1); c.setLineDash([]);
    for (let i = 0; i < 12; i++) {
      const a = i * TAU / 12 + t * .024;
      const x = reactorX + Math.cos(a) * radius * .55, y = reactorY + Math.sin(a) * radius * .55;
      circle(c, x, y, 3, '#8ddace');
    }
    circle(c, reactorX, reactorY, radius * .37, '#173e48', '#61bba9', 2);
    circle(c, reactorX, reactorY, radius * .33, null, '#307275', 8);
    gear(c, reactorX, reactorY, radius * .25, 16, -t * .07, '#204c51', '#81c9b6');
    c.restore();

    // Distant factory roof, windows, cables and fine blueprint annotations.
    const roofY = h * .66 - camera.y * s * .1;
    const offset = ((-camera.x * s * .13) % 250) - 250;
    for (let x = offset; x < w + 250; x += 250) {
      const n = Math.round((x - offset) / 250), bh = 75 + hash(n + 10) * 115;
      rect(c, x, roofY - bh, 217, h - roofY + bh, '#0b303b');
      rect(c, x + 23, roofY - bh - 36, 40, 36, '#0b303b');
      rect(c, x + 77, roofY - bh - 18, 21, 18, '#0b303b');
      line(c, x, roofY - bh, x + 217, roofY - bh, '#25565b', 2);
      for (let col = 0; col < 5; col++) for (let row = 0; row < 3; row++) {
        rect(c, x + 18 + col * 40, roofY - bh + 22 + row * 33, 20, 14,
          hash(col + row * 5 + n * 17) > .38 ? '#245857' : '#133e47', 2);
        line(c, x + 28 + col * 40, roofY - bh + 22 + row * 33, x + 28 + col * 40, roofY - bh + 36 + row * 33, '#143d46');
      }
      c.beginPath(); c.moveTo(x + 50, roofY - bh - 34);
      c.bezierCurveTo(x + 100, roofY - bh + 2, x + 180, roofY - bh + 2, x + 250, roofY - bh - 25);
      c.strokeStyle = '#1e5057'; c.lineWidth = 2; c.stroke();
    }

    c.save(); c.globalAlpha = .085;
    const grid = 46 * s;
    for (let x = (-camera.x * s * .06) % grid; x < w; x += grid) line(c, x, 0, x, h, '#a6eadd');
    for (let y = (-camera.y * s * .06) % grid; y < h; y += grid) line(c, 0, y, w, y, '#a6eadd');
    c.restore();
    c.save(); c.globalAlpha = .15;
    label(c, 'FIG. 07 / SYSTÈME À PEU PRÈS STABLE', w * .62, 32, 9, '#b6ead8', 'left', 500);
    line(c, w * .62, 48, w * .89, 48, '#8bbcac');
    label(c, 'η = CONFIANCE / CAFÉ', w * .68, h * .17, 10, '#b6ead8', 'left', 500);
    c.restore();

    // Broad shafts of daylight, with no noisy per-frame texture.
    c.save(); c.globalCompositeOperation = 'screen';
    for (let i = 0; i < 3; i++) {
      const top = w * (.55 + i * .19);
      const beam = c.createLinearGradient(top, 0, top - h * .35, h);
      beam.addColorStop(0, 'rgba(168,235,202,.07)'); beam.addColorStop(1, 'rgba(94,221,192,0)');
      c.beginPath(); c.moveTo(top, 0); c.lineTo(top + 55, 0);
      c.lineTo(top - h * .5 + 130, h); c.lineTo(top - h * .5 - 160, h);
      c.closePath(); c.fillStyle = beam; c.fill();
    }
    c.restore();
    for (let i = 0; i < 64; i++) {
      const x = ((hash(i + 40) * w + t * (3 + hash(i) * 7) - camera.x * s * .04) % w + w) % w;
      const y = ((hash(i + 99) * h - t * (2 + hash(i + 3) * 5)) % h + h) % h;
      circle(c, x, y, .5 + hash(i + 7) * 1.1, `rgba(174,231,208,${.08 + hash(i + 1) * .17})`);
    }
  }

  universeBackground(index, camera, s, t) {
    const c = this.ctx, w = this.width, h = this.height;
    const parallax = camera.x * s * .08;
    if (index === 1) {
      const g = c.createLinearGradient(0, 0, 0, h);
      g.addColorStop(0, '#041a31'); g.addColorStop(.6, '#0d3d51'); g.addColorStop(1, '#062935');
      c.fillStyle = g; c.fillRect(0, 0, w, h);
      const chipX = w * .73 - parallax, chipY = h * .32, r = Math.min(w * .16, h * .26);
      c.save(); c.globalAlpha = .3;
      for (let i = 0; i < 10; i++) {
        const py = chipY - r + i * r * .21;
        const px = chipX - r - 40 - (i % 3) * 55;
        line(c, chipX - r, py, px, py, '#62e8d3', 2);
        line(c, px, py, px - 28, py + 28, '#62e8d3', 2);
        line(c, px - 28, py + 28, px - 105, py + 28, '#62e8d3', 2);
        circle(c, px - 105, py + 28, 4, '#184b60', '#85f5d5', 1.5);
        line(c, chipX + r, py, chipX + r + 45 + (i % 2) * 60, py, '#62e8d3', 2);
      }
      rect(c, chipX - r, chipY - r, r * 2, r * 2, '#0d3045', 16, '#47a5a7', 3);
      rect(c, chipX - r * .82, chipY - r * .82, r * 1.64, r * 1.64, '#144356', 6, '#71cbbb', 2);
      circle(c, chipX, chipY, r * .58, '#082e43', '#91e6c6', 2);
      c.setLineDash([2, 7]); circle(c, chipX, chipY, r * .5, null, '#81dece'); c.setLineDash([]);
      c.beginPath();
      for (let i = 0; i <= 70; i++) {
        const dx = i / 70 * r * .88 - r * .44;
        const dy = Math.sin(i * .16 - t * 1.4) * r * .19;
        if (!i) c.moveTo(chipX + dx, chipY + dy); else c.lineTo(chipX + dx, chipY + dy);
      }
      c.strokeStyle = '#a6ffd6'; c.lineWidth = 3; c.stroke();
      label(c, 'P / I / D', chipX, chipY + r * .35, 13, '#c6ffee', 'center');
      c.restore();
      const offset = (-parallax * 1.6) % 210 - 210;
      for (let x = offset; x < w + 210; x += 210) {
        rect(c, x, h * .61, 190, h * .39, '#0a293d', 4, '#1e5665', 1);
        for (let i = 0; i < 6; i++) {
          rect(c, x + 12, h * .64 + i * 28, 162, 19, '#133d4a', 3);
          for (let j = 0; j < 7; j++) circle(c, x + 24 + j * 18, h * .64 + i * 28 + 9, 1.5, hash(i * 4 + j) > .5 ? '#60c9a8' : '#2b6267');
          line(c, x + 149, h * .64 + i * 28 + 6, x + 163, h * .64 + i * 28 + 6, '#417a75', 2);
        }
      }
    } else if (index === 2) {
      const g = c.createLinearGradient(0, 0, 0, h);
      g.addColorStop(0, '#2e2949'); g.addColorStop(.52, '#617283'); g.addColorStop(1, '#1c2948');
      c.fillStyle = g; c.fillRect(0, 0, w, h);
      const offset = (-parallax * 1.7) % 270 - 270;
      for (let x = offset; x < w + 270; x += 270) {
        const towerIndex = Math.floor(parallax * 1.7 / 270) + Math.round((x - offset) / 270);
        const towerHeight = h * (.48 + hash(towerIndex + 23) * .18);
        const glass = c.createLinearGradient(x, 0, x + 210, h);
        glass.addColorStop(0, '#657488'); glass.addColorStop(.5, '#404e6c'); glass.addColorStop(1, '#253b54');
        rect(c, x, h - towerHeight, 223, towerHeight, glass, 2, '#8b94a1', 1);
        for (let i = 0; i < 6; i++) line(c, x + i * 40, h - towerHeight, x + i * 40, h, 'rgba(205,225,230,.17)', 2);
        for (let i = 0; i < 12; i++) line(c, x, h - towerHeight + i * 34, x + 223, h - towerHeight + i * 34, 'rgba(220,230,242,.18)', 1);
        c.save(); c.globalAlpha = .11;
        c.beginPath(); c.moveTo(x + 6, h - towerHeight + 4); c.lineTo(x + 83, h - towerHeight + 4); c.lineTo(x + 212, h); c.lineTo(x + 132, h); c.closePath(); c.fillStyle = '#e2f4ff'; c.fill(); c.restore();
      }
      c.save(); c.globalAlpha = .2;
      const bx = w * .8 - parallax, by = h * .37;
      c.beginPath(); c.moveTo(bx - 160, by + 130); c.lineTo(bx - 70, by + 72); c.lineTo(bx - 2, by + 99); c.lineTo(bx + 100, by - 40); c.lineTo(bx + 83, by - 41); c.moveTo(bx + 100, by - 40); c.lineTo(bx + 103, by - 17);
      c.strokeStyle = '#efd7fa'; c.lineWidth = 17; c.lineJoin = 'round'; c.stroke();
      label(c, 'CROISSANCE INFINIE*', bx, by - 73, 20, '#f6eafa', 'center', 700);
      label(c, '* sauf le budget du prototype', bx, by - 44, 10, '#f6eafa', 'center', 500);
      c.restore();
    } else {
      const g = c.createLinearGradient(0, 0, 0, h);
      g.addColorStop(0, '#2b262d'); g.addColorStop(.52, '#615545'); g.addColorStop(1, '#282b32');
      c.fillStyle = g; c.fillRect(0, 0, w, h);
      const offset = (-parallax * 1.5) % 320 - 320;
      for (let x = offset; x < w + 320; x += 320) {
        rect(c, x + 20, 80, 250, h - 80, '#342e33', 5, '#796d57', 2);
        for (let row = 0; row < 7; row++) {
          const yy = 118 + row * 65;
          for (let book = 0; book < 13; book++) {
            const bh = 30 + hash(row * 30 + book) * 16, bx = x + 31 + book * 17;
            const color = ['#655b56', '#8a7660', '#6f585e', '#576466'][book % 4];
            rect(c, bx, yy + 47 - bh, 12, bh, color, 1);
            line(c, bx + 2, yy + 41 - bh, bx + 10, yy + 41 - bh, '#a3987c');
          }
          rect(c, x + 25, yy + 49, 240, 7, '#817057', 1);
        }
        rect(c, x + 279, 52, 27, h - 52, '#776756', 3, '#9b886c', 1);
        for (let i = 0; i < 3; i++) line(c, x + 286 + i * 7, 66, x + 286 + i * 7, h, '#504a46', 2);
        rect(c, x + 270, 44, 45, 17, '#a69272', 2);
      }
      const sealX = w * .8 - parallax, sealY = h * .28, r = Math.min(h * .2, 145);
      c.save(); c.globalAlpha = .14; c.translate(sealX, sealY); c.rotate(-.17);
      circle(c, 0, 0, r, null, '#dfb67b', 8); circle(c, 0, 0, r * .86, null, '#dfb67b', 2);
      label(c, 'PRESQUE', 0, -19, r * .23, '#ffe0a0', 'center', 800);
      label(c, 'CONFORME', 0, 19, r * .23, '#ffe0a0', 'center', 800);
      label(c, 'COMMISSION DU DOUTE', 0, r * .57, 9, '#ffe0a0', 'center', 600); c.restore();
    }
    // A faint grid and suspended dust retain the shared illustrated style.
    c.save(); c.globalAlpha = index === 2 ? .045 : .07;
    const grid = (index === 3 ? 74 : 43) * s;
    for (let x = (-parallax * .4) % grid; x < w; x += grid) line(c, x, 0, x, h, '#cef6e7');
    for (let y = 0; y < h; y += grid) line(c, 0, y, w, y, '#cef6e7'); c.restore();
    for (let i = 0; i < 45; i++) {
      const x = ((hash(i + 31) * w + t * 4 - parallax) % w + w) % w;
      const y = ((hash(i + 63) * h - t * 3) % h + h) % h;
      circle(c, x, y, .5 + hash(i + 9), index === 3 ? 'rgba(242,217,164,.2)' : 'rgba(210,241,243,.18)');
    }
  }

  worldBackdrop(game, t) {
    const c = this.ctx, level = game.level, cx = game.camera?.x || 0;
    const max = cx + this.width / (game.viewScale || 1);
    const stageHeight = 760;
    if (level.index >= 2) this.officeBackdrop(cx, max, level.index, t);
    else {
    // Monumental structural ribs give the level its readable vertical scale.
    for (let x = Math.floor((cx - 160) / 430) * 430; x < max + 200; x += 430) {
      rect(c, x + 18, 66, 27, stageHeight - 66, '#0c3039', 2, '#214c52');
      rect(c, x + 5, 69, 52, 14, '#245054', 2);
      rect(c, x + 6, 610, 50, 14, '#21494f', 2);
      line(c, x + 47, 92, x + 205, 217, '#16424b', 12);
      line(c, x + 40, 92, x + 205, 217, '#2a565b', 2);
      circle(c, x + 31, 93, 3, '#4b6e6d');
      circle(c, x + 31, 598, 3, '#4b6e6d');
      const light = c.createRadialGradient(x + 140, 138, 2, x + 140, 138, 75);
      light.addColorStop(0, 'rgba(250,204,95,.11)'); light.addColorStop(1, 'rgba(250,204,95,0)');
      c.fillStyle = light; c.fillRect(x + 65, 63, 150, 150);
      line(c, x + 140, 0, x + 140, 127, '#10373e', 4);
      rect(c, x + 121, 127, 38, 8, '#45645d', 3);
      rect(c, x + 124, 136, 32, 4, '#ffdb8c', 2);
    }

    // Utility pipes travel behind all collision platforms.
    for (const y of [254, 550]) {
      line(c, Math.max(0, cx - 60), y + 4, Math.min(level.width, max + 60), y + 4, '#071f29', 17);
      line(c, Math.max(0, cx - 60), y, Math.min(level.width, max + 60), y, '#275052', 11);
      line(c, Math.max(0, cx - 60), y - 4, Math.min(level.width, max + 60), y - 4, '#3c6864', 1);
      for (let x = Math.floor(cx / 180) * 180; x < max + 90; x += 180) {
        rect(c, x, y - 9, 10, 18, '#163a44', 2, '#386460');
        circle(c, x + 5, y - 6, 1, '#6d8580');
        circle(c, x + 5, y + 6, 1, '#6d8580');
      }
    }
    }

    const corporate = level.index === 2;
    const jokes = corporate
      ? ['ALIGNEMENT STRATÉGIQUE', 'VISION 360°', 'ÇA SCALE', 'ROADMAP DE LA ROADMAP', 'PIVOTER EST UN MÉTIER', 'SYNERGIE À IMPACT POSITIF']
      : level.index === 1
        ? ['LE SYSTÈME EST STABLE. TOI, MOINS.', 'ERREUR : CONFIANCE TROP ÉLEVÉE', 'P + I + D ≠ REPOS', 'BOUCLE FERMÉE, NUITS OUVERTES', 'DÉPASSEMENT DE DEADLINE', 'ATTENTION AU POINT-VIRGULE']
        : level.index === 3
          ? ['SOUTENANCE : LE BOSS FINAL', 'VOTRE ANNEXE A UNE ANNEXE ?', '10 MINUTES. 12 QUESTIONS.', 'CERTIFIÉ PRESQUE CONFORME', 'DÉMONSTRATION SOUS PRESSION', 'MERCI DE JUSTIFIER LE CAFÉ']
          : ['LABO : ÇA DEVRAIT MARCHER', 'CECI N’EST PAS UN BUG', 'BUREAU DES TOLÉRANCES', 'ISO 9001 — À PEU PRÈS', 'LE CAFÉ EST STRUCTUREL', 'NE PAS SIMULER LE TRAVAIL'];
    for (let x = Math.floor((cx - 300) / 680) * 680; x < max + 200; x += 680) {
      const i = Math.abs(Math.floor(x / 680));
      if (corporate) this.presentation(x + 225, 398, t, i);
      else if (level.index === 1) this.oscilloscope(x + 225, 425, t, i);
      else if (level.index === 3) this.juryDesk(x + 185, 592, t, i);
      else this.machine(x + 230, 510, t, i);
      const sx = x + 90, sy = 325 - (i % 2) * 66;
      line(c, sx + 25, sy - 60, sx + 25, sy, '#436764', 2);
      line(c, sx + 189, sy - 60, sx + 189, sy, '#436764', 2);
      rect(c, sx, sy, 214, 43, '#102f39', 6, '#446963', 1.5);
      rect(c, sx + 8, sy + 8, 4, 27, P.gold, 2);
      label(c, jokes[i % jokes.length], sx + 22, sy + 22, jokes[i % jokes.length].length > 29 ? 8 : 10, '#a8bbaa', 'left', 700);
      circle(c, sx + 204, sy + 8, 2, '#739083'); circle(c, sx + 204, sy + 35, 2, '#739083');
    }

    // Blueprints in faded white chalk, positioned clear of interactive objects.
    c.save(); c.globalAlpha = .18;
    for (let x = Math.floor(cx / 1200) * 1200 + 370; x < max + 150; x += 1200) {
      if (level.index === 0) {
        gear(c, x, 193, 37, 12, -.12, 'rgba(0,0,0,0)', '#8cd5c9');
        gear(c, x + 60, 167, 22, 9, .1, 'rgba(0,0,0,0)', '#8cd5c9');
      } else if (level.index === 1) {
        rect(c, x - 35, 164, 70, 50, null, 4, '#8cd5c9'); label(c, 'PID', x, 189, 18, '#b8ead8', 'center');
        for (let i = 0; i < 5; i++) { line(c, x - 53, 168 + i * 10, x - 35, 168 + i * 10, '#8cd5c9', 2); line(c, x + 35, 168 + i * 10, x + 72, 168 + i * 10, '#8cd5c9', 2); }
      } else if (level.index === 2) {
        for (const xx of [x - 40, x + 25, x + 90]) { rect(c, xx, 175, 50, 28, null, 3, '#cfccf3'); label(c, 'IMPACT', xx + 25, 189, 7, '#ebddf5', 'center'); }
        line(c, x + 10, 190, x + 25, 190, '#cfccf3'); line(c, x + 75, 190, x + 90, 190, '#cfccf3');
      } else {
        rect(c, x - 28, 150, 62, 82, '#beaa80', 1, '#ead7a5');
        for (let i = 0; i < 6; i++) line(c, x - 20, 168 + i * 8, x + 25, 168 + i * 8, '#53483c');
        circle(c, x + 19, 215, 11, '#ae6470', '#ffb28d', 2);
      }
      line(c, x - 57, 246, x + 92, 246, '#8cd5c9');
      line(c, x - 57, 239, x - 57, 253, '#8cd5c9');
      line(c, x + 92, 239, x + 92, 253, '#8cd5c9');
      label(c, ['JEU FONCTIONNEL : 0.2 mm', 'TEMPS DE RÉPONSE : 3 CAFÉS', 'ORGANIGRAMME DE L’ORGANIGRAMME', 'ANNEXE DE L’ANNEXE'][level.index || 0], x + 15, 266, 9, '#d1fff1', 'center', 500);
    }
    c.restore();
    if (game.mode === 'menu') this.robotArm(974, 690, t);
  }

  officeBackdrop(cx, max, index, t) {
    const c = this.ctx;
    for (let x = Math.floor((cx - 220) / 470) * 470; x < max + 250; x += 470) {
      if (index === 2) {
        rect(c, x + 12, 73, 19, 687, 'rgba(208,218,228,.18)', 1, '#788798');
        rect(c, x + 36, 190, 389, 370, 'rgba(178,203,226,.05)', 4, '#72829a');
        for (let i = 1; i < 4; i++) line(c, x + 36 + i * 98, 190, x + 36 + i * 98, 560, 'rgba(180,195,211,.25)', 2);
        for (let i = 0; i < 6; i++) line(c, x + 37, 205 + i * 45, x + 425, 205 + i * 45, 'rgba(168,184,205,.12)', 1);
        line(c, x + 125, 0, x + 125, 111, '#4d5c75', 2);
        rect(c, x + 66, 110, 122, 8, '#e1dce6', 4); rect(c, x + 75, 118, 106, 2, '#f0f4e9', 1);
        // Potted office plant, decorative rather than a playable ledge.
        rect(c, x + 84, 616, 34, 31, '#706787', 4, '#aea1ba', 1);
        line(c, x + 101, 616, x + 101, 558, '#5c877d', 3);
        for (let i = 0; i < 5; i++) {
          c.save(); c.translate(x + 101, 568 + i * 9); c.rotate(i % 2 ? .9 : -.9);
          ellipse(c, 0, -13, 7, 18, i % 2 ? '#4b8a88' : '#668d7c'); c.restore();
        }
      } else {
        rect(c, x + 10, 60, 34, 700, '#605449', 2, '#a18a69', 1.5);
        for (let i = 0; i < 4; i++) line(c, x + 16 + i * 7, 82, x + 16 + i * 7, 750, '#403d3b', 2);
        rect(c, x - 4, 61, 62, 21, '#8d7a5d', 2, '#b79f77');
        rect(c, x, 707, 51, 19, '#9d8663', 2, '#b39c75');
        c.beginPath(); c.moveTo(x + 65, 418); c.lineTo(x + 65, 277); c.arc(x + 228, 277, 163, Math.PI, TAU); c.lineTo(x + 391, 418); c.closePath();
        c.fillStyle = 'rgba(184,165,117,.075)'; c.fill(); c.strokeStyle = '#82735c'; c.lineWidth = 3; c.stroke();
        line(c, x + 228, 125, x + 228, 417, '#786950', 2); line(c, x + 69, 277, x + 387, 277, '#786950', 2);
        rect(c, x + 96, 436, 101, 157, '#817257', 3, '#b39b72', 1.5);
        rect(c, x + 106, 446, 81, 137, '#a18b65', 1);
        for (let i = 0; i < 9; i++) line(c, x + 115, 460 + i * 11, x + 175, 460 + i * 11, '#73634f', 2);
        circle(c, x + 171, 562, 12, '#905457', '#c49173', 2);
        label(c, 'RAPPORT', x + 146, 455, 7, '#d9c59a', 'center', 700);
      }
    }
  }

  robotArm(x, y, t) {
    const c = this.ctx;
    c.save(); c.translate(x, y);
    const elbow = { x: 35 + Math.sin(t * .45) * 5, y: -275 };
    const wrist = { x: -102, y: -365 + Math.sin(t * .65) * 5 };
    const steel = '#abbaa3', outline = '#1a3c45';
    // Large warm metal articulated arm frames the tiny playable engineer.
    c.lineCap = 'round';
    for (const segment of [[-8, -117, elbow.x, elbow.y], [elbow.x, elbow.y, wrist.x, wrist.y]]) {
      line(c, ...segment, outline, 49); line(c, ...segment, steel, 38);
      line(c, segment[0] - 7, segment[1] - 4, segment[2] - 7, segment[3] - 4, '#dee5c5', 4);
    }
    for (const point of [{ x: -8, y: -117 }, elbow, wrist]) {
      gear(c, point.x, point.y, 29, 14, t * .03, '#516f6b', '#173c44');
      circle(c, point.x, point.y, 22, '#123c47', '#91ada0', 3);
      circle(c, point.x, point.y, 15, '#3c7c78', '#d8e1ba', 1.5);
      circle(c, point.x - 3, point.y - 4, 5, '#a7f3d3');
    }
    // Hydraulic line follows both links and gives the arm real mechanical detail.
    c.beginPath(); c.moveTo(-28, -133); c.bezierCurveTo(-10, -160, -8, -238, elbow.x - 15, elbow.y - 14);
    c.bezierCurveTo(elbow.x - 43, elbow.y - 28, wrist.x + 56, wrist.y + 6, wrist.x - 4, wrist.y + 20);
    c.strokeStyle = '#0b303b'; c.lineWidth = 6; c.stroke(); c.strokeStyle = '#ecb85f'; c.lineWidth = 2; c.stroke();
    c.save(); c.translate(wrist.x - 21, wrist.y - 9); c.rotate(-.3);
    rect(c, -23, -10, 34, 20, '#748f80', 5, outline, 2);
    line(c, -19, -7, -37, -24, '#cbd5b6', 8); line(c, -37, -24, -47, -17, '#cbd5b6', 6);
    line(c, -19, 7, -36, 25, '#cbd5b6', 8); line(c, -36, 25, -47, 18, '#cbd5b6', 6);
    line(c, -45, -26, -47, 31, '#527c7b', 9); line(c, -44, -23, -46, 28, '#b1d1b6', 3);
    c.beginPath(); c.arc(-44, -36, 13, .4, Math.PI * 1.4); c.strokeStyle = '#bed3b7'; c.lineWidth = 8; c.stroke();
    c.restore();
    rect(c, -73, -113, 128, 107, '#133c44', 16, '#456c63', 3);
    rect(c, -62, -105, 106, 78, '#294f51', 10, '#80967c', 2);
    rect(c, -53, -96, 89, 48, '#062c38', 9, '#5e9e8b', 2);
    c.save(); c.shadowColor = '#8affda'; c.shadowBlur = 15;
    circle(c, -6, -73, 14, '#6ef1cf'); c.shadowBlur = 0;
    circle(c, -3 + Math.sin(t * .6) * 3, -73, 7, '#1d6165');
    circle(c, -6, -78, 3, '#d1ffe3'); c.restore();
    for (let i = 0; i < 3; i++) rect(c, -43 + i * 17, -37, 10, 3, '#e1c178', 1);
    label(c, 'PROTO — 404', -10, -17, 9, '#b1c6a9', 'center', 700);
    rect(c, -81, -7, 146, 16, '#355f5b', 5, '#90ab8b', 2);
    for (const xx of [-64, 50]) circle(c, xx, 0, 3, '#d9ce97');
    c.restore();
  }

  machine(x, y, t, variant) {
    const c = this.ctx;
    rect(c, x, y - 114, 180, 180, '#123b43', 8, '#2b5d5a', 2);
    rect(c, x + 9, y - 105, 162, 99, '#0e2d38', 5, '#37615e');
    if (variant % 2 === 0) {
      gear(c, x + 52, y - 59, 32, 12, t * .13, '#28565a', '#427e73');
      gear(c, x + 113, y - 43, 25, 10, -t * .17, '#28565a', '#427e73');
      circle(c, x + 145, y - 85, 4, '#d9bb66');
    } else {
      for (let i = 0; i < 3; i++) {
        rect(c, x + 26 + i * 45, y - 85, 27, 57, '#133e46', 8, '#427b72');
        rect(c, x + 31 + i * 45, y - 52 - Math.sin(t * .8 + i) * 9, 17, 28 + Math.sin(t * .8 + i) * 9, '#2b807b', 4);
        line(c, x + 39 + i * 45, y - 105, x + 39 + i * 45, y - 85, '#385e5c', 6);
      }
    }
    for (let i = 0; i < 6; i++) rect(c, x + 20 + i * 16, y + 15, 8, 26, '#092c35', 2);
    circle(c, x + 143, y + 27, 13, '#163941', '#456a60', 2);
    line(c, x + 143, y + 27, x + 148, y + 19, '#9cc2a6', 2);
    rect(c, x + 15, y + 66, 21, 12, '#092b34', 2); rect(c, x + 144, y + 66, 21, 12, '#092b34', 2);
    label(c, 'PROTO • ' + String(variant + 1).padStart(2, '0'), x + 22, y - 94, 7, '#6d9990', 'left', 500);
  }

  presentation(x, y, t, variant) {
    const c = this.ctx;
    line(c, x + 117, y + 142, x + 117, y + 205, '#30434f', 9);
    line(c, x + 66, y + 211, x + 167, y + 211, '#30434f', 8);
    rect(c, x, y, 240, 150, '#17283b', 7, '#5b657d', 2);
    rect(c, x + 10, y + 9, 220, 132, '#233b50', 2, '#526a7a');
    rect(c, x + 11, y + 10, 218, 25, '#444568', 2);
    label(c, variant % 2 ? 'PLUS D’IMPACT. MOINS DE SENS.' : 'LA CROISSANCE DE LA CROISSANCE', x + 20, y + 23, 8, '#ddc9e4');
    line(c, x + 31, y + 112, x + 208, y + 112, '#587888');
    line(c, x + 31, y + 112, x + 31, y + 50, '#587888');
    for (let i = 0; i < 6; i++) {
      const height = 10 + i * 7 + hash(i + variant) * 13;
      rect(c, x + 45 + i * 26, y + 110 - height, 15, height, i > 3 ? '#bc8acb' : '#559d9c', 2);
    }
    c.beginPath(); c.moveTo(x + 44, y + 89); c.lineTo(x + 81, y + 83); c.lineTo(x + 110, y + 88); c.lineTo(x + 141, y + 71); c.lineTo(x + 175, y + 60); c.lineTo(x + 205, y + 44);
    c.strokeStyle = '#dec58e'; c.lineWidth = 2; c.stroke();
    c.beginPath(); c.moveTo(x + 196, y + 45); c.lineTo(x + 205, y + 44); c.lineTo(x + 202, y + 54); c.stroke();
    label(c, 'Source : on a mis une flèche qui monte.', x + 120, y + 128, 7, '#9fb7bd', 'center', 500);
    circle(c, x + 229, y + 146, 2, '#7cceb6');
  }

  oscilloscope(x, y, t, variant) {
    const c = this.ctx;
    rect(c, x, y, 218, 121, '#19434d', 9, '#4e7b78', 2);
    rect(c, x + 10, y + 10, 157, 84, '#062f3c', 5, '#4c9387', 2);
    c.save(); round(c, x + 12, y + 12, 153, 80, 3); c.clip();
    c.globalAlpha = .23;
    for (let i = 0; i < 7; i++) line(c, x + 15, y + 18 + i * 12, x + 165, y + 18 + i * 12, '#71c7b1');
    for (let i = 0; i < 10; i++) line(c, x + 16 + i * 16, y + 12, x + 16 + i * 16, y + 92, '#71c7b1');
    c.globalAlpha = 1;
    for (let wave = 0; wave < 2; wave++) {
      c.beginPath();
      for (let dx = 0; dx < 156; dx += 3) {
        const yy = y + 52 + Math.sin(dx * .047 - t * 1.3 + variant + wave) * (24 - wave * 8) * Math.exp(-dx * .004);
        if (!dx) c.moveTo(x + 12, yy); else c.lineTo(x + 12 + dx, yy);
      }
      c.strokeStyle = wave ? '#ddbd79' : '#86e5c6'; c.lineWidth = 1.5; c.stroke();
    }
    c.restore();
    for (let i = 0; i < 3; i++) {
      circle(c, x + 190, y + 26 + i * 28, 9, '#102f3b', '#719083', 1.5);
      line(c, x + 190, y + 26 + i * 28, x + 194, y + 22 + i * 28, '#bcc29d', 2);
    }
    label(c, 'ASSERVISSEMENT ÉMOTIONNEL', x + 13, y + 108, 7, '#91b6a1');
    for (const xx of [x + 23, x + 187]) rect(c, xx, y + 121, 13, 23, '#153b43', 2);
  }

  juryDesk(x, y, t, variant) {
    const c = this.ctx;
    for (let i = 0; i < 3; i++) {
      rect(c, x + 21 + i * 80, y - 86, 40, 62, '#334d4f', 11, '#61796a', 1.5);
      circle(c, x + 41 + i * 80, y - 104, 13, '#738476', '#284a4e', 2);
      rect(c, x + 26 + i * 80, y - 97, 31, 5, '#294750', 2);
      line(c, x + 41 + i * 80, y - 109, x + 41 + i * 80, y - 115, '#aab899', 1);
      line(c, x + 60 + i * 80, y - 21, x + 66 + i * 80, y - 44, '#1b3841', 2);
      circle(c, x + 66 + i * 80, y - 46, 4, '#576b65');
    }
    rect(c, x, y - 20, 274, 61, '#254e4f', 6, '#628375', 2);
    rect(c, x - 8, y - 27, 290, 11, '#8caa8b', 3, '#25494b');
    for (let i = 0; i < 3; i++) {
      rect(c, x + 18 + i * 82, y - 33, 37, 5, '#bbc29b', 1);
      rect(c, x + 21 + i * 82, y - 8, 46, 14, '#152f3a', 3, '#718374');
      label(c, ['DOUTE', 'NORME', 'POURQUOI ?'][i], x + 44 + i * 82, y - 1, 6, '#bfcca8', 'center');
    }
    label(c, 'COMMISSION DES QUESTIONS IMPOSSIBLES', x + 136, y + 25, 8, '#9eb49a', 'center');
    rect(c, x + 12, y + 41, 18, 29, '#123841', 2); rect(c, x + 244, y + 41, 18, 29, '#123841', 2);
  }

  platform(p, t, index = 0) {
    const c = this.ctx, moving = p.type === 'moving', belt = p.type === 'conveyor';
    const floor = p.type === 'floor' || (p.h || 24) > 55, h = Math.max(p.h || 24, 10);
    const palette = [
      ['#42636a', '#213b46', '#d5c29a', '#132c38'],
      ['#135664', '#092f40', '#85efd8', '#0b2738'],
      ['#a5abc1', '#56647e', '#f4edff', '#31374f'],
      ['#bbaa80', '#796148', '#f0ddb0', '#443a35'],
    ][index] || ['#42636a', '#213b46', '#d5c29a', '#132c38'];
    if (moving) this.movingGuides(p, t);
    rect(c, p.x + 2, p.y + 5, p.w, h, 'rgba(0,12,20,.4)', 4);
    const g = c.createLinearGradient(p.x, p.y, p.x, p.y + h);
    g.addColorStop(0, palette[0]); g.addColorStop(1, palette[1]);
    rect(c, p.x, p.y, p.w, h, g, floor ? 3 : 5, palette[3], 2);
    rect(c, p.x + 1, p.y, p.w - 2, 6, moving ? '#ffd287' : belt ? '#c6a16a' : palette[2], 2);
    rect(c, p.x + 1, p.y + 6, p.w - 2, 3, palette[3]);
    c.save(); round(c, p.x + 2, p.y + 9, p.w - 4, h - 10, 2); c.clip();
    if (index === 0) {
      if (floor) for (let x = p.x + 17; x < p.x + p.w; x += 84) {
        rect(c, x, p.y + 21, 57, Math.max(h - 34, 13), '#132e3a', 3, '#60736a');
        line(c, x + 5, p.y + 26, x + 49, p.y + h - 18, '#3e5b62', 4);
        circle(c, x + 5, p.y + 26, 2, '#b8aa87'); circle(c, x + 49, p.y + h - 18, 2, '#b8aa87');
      } else {
        rect(c, p.x, p.y + h - 9, p.w, 8, '#c4a467'); c.fillStyle = '#34494b';
        for (let x = p.x - 12; x < p.x + p.w + 20; x += 22) {
          c.beginPath(); c.moveTo(x, p.y + h - 9); c.lineTo(x + 10, p.y + h - 9); c.lineTo(x + 18, p.y + h); c.lineTo(x + 8, p.y + h); c.closePath(); c.fill();
        }
      }
    } else if (index === 1) {
      for (let x = p.x + 16; x < p.x + p.w; x += 82) {
        const yy = p.y + Math.min(h - 6, floor ? 40 : 14);
        line(c, x, yy, x + 30, yy, '#60ac92', 1.5); line(c, x + 30, yy, x + 39, yy + 9, '#60ac92', 1.5);
        line(c, x + 39, yy + 9, x + 66, yy + 9, '#60ac92', 1.5);
        circle(c, x, yy, 2.5, '#1b514f', '#b5e5b6'); circle(c, x + 66, yy + 9, 2.5, '#1b514f', '#b5e5b6');
        if (floor) { rect(c, x + 15, yy + 23, 24, 21, '#082537', 2, '#3d7d74'); for (let i = 0; i < 4; i++) line(c, x + 11, yy + 25 + i * 5, x + 15, yy + 25 + i * 5, '#89bc94', 1); }
      }
      line(c, p.x, p.y + h - 4, p.x + p.w, p.y + h - 4, '#36a9a5', 2);
    } else if (index === 2) {
      c.fillStyle = 'rgba(220,233,255,.17)';
      for (let x = p.x - 35; x < p.x + p.w; x += 100) {
        c.beginPath(); c.moveTo(x, p.y + 9); c.lineTo(x + 22, p.y + 9); c.lineTo(x + h + 20, p.y + h); c.lineTo(x + h - 4, p.y + h); c.closePath(); c.fill();
      }
      for (let x = p.x + 28; x < p.x + p.w; x += 80) line(c, x, p.y + 10, x, p.y + h - 3, '#b6b5ca', 1.5);
      line(c, p.x, p.y + h - 4, p.x + p.w, p.y + h - 4, '#bea4d0', 2);
      if (floor) label(c, 'ESPACE DE CO-CONSTRUCTION', p.x + p.w / 2, p.y + 35, 8, '#d9d6e7', 'center', 700);
    } else {
      for (let yy = p.y + 12; yy < p.y + h; yy += floor ? 17 : 4) line(c, p.x + 4, yy, p.x + p.w - 5, yy, floor ? '#554539' : '#dfcea3', 1);
      if (floor) for (let x = p.x + 16; x < p.x + p.w; x += 89) {
        rect(c, x, p.y + 20, 67, Math.max(12, h - 32), '#635440', 4, '#a18a65');
        rect(c, x + 7, p.y + 26, 53, Math.max(7, h - 45), '#807058', 2, '#4e4438');
      }
      else { rect(c, p.x + 3, p.y + 9, 6, h - 10, '#87545a'); circle(c, p.x + p.w - 14, p.y + 14, 5, '#ad5a65', '#edb899', 1); }
    }
    c.restore();
    if (belt) this.conveyor(p, t, h);
    else if (index < 2) for (let x = p.x + 10; x < p.x + p.w - 3; x += 42) {
      circle(c, x, p.y + 13, 2, palette[2]); line(c, x - 1, p.y + 13, x + 1, p.y + 13, palette[3]);
    }
    if (moving) {
      rect(c, p.x + 3, p.y + 8, 4, h - 10, '#f7b468', 1); rect(c, p.x + p.w - 7, p.y + 8, 4, h - 10, '#f7b468', 1);
      label(c, Math.abs(p.amplitudeY || 0) > Math.abs(p.amplitudeX || 0) ? '↕' : '↔', p.x + p.w / 2, p.y + Math.min(h - 7, 15), 14, '#ffe1a9', 'center', 700);
      for (const x of [p.x + 14, p.x + p.w - 14]) {
        rect(c, x - 8, p.y + h - 1, 16, 8, '#3b3b40', 3, '#be9767');
        const plume = c.createLinearGradient(x, p.y + h + 6, x, p.y + h + 29);
        plume.addColorStop(0, '#ffc47d'); plume.addColorStop(1, 'rgba(255,173,99,0)');
        c.beginPath(); c.moveTo(x - 5, p.y + h + 6); c.lineTo(x + 5, p.y + h + 6); c.lineTo(x, p.y + h + 29); c.closePath(); c.fillStyle = plume; c.fill();
      }
    }
    if (p.label) {
      const lw = Math.min(p.w - 20, 108);
      rect(c, p.x + (p.w - lw) / 2, p.y + h + 5, lw, 15, index === 3 ? '#69513f' : '#453858', 3, index === 3 ? '#c3a279' : '#8a698f');
      label(c, p.label, p.x + p.w / 2, p.y + h + 13, 7, '#edcce4', 'center', 700);
    }
  }

  conveyor(p, t, h) {
    const c = this.ctx, dir = p.beltDir || 1, speed = p.beltSpeed || 60;
    c.save(); round(c, p.x + 2, p.y + 1, p.w - 4, Math.min(h - 2, 26), 3); c.clip();
    rect(c, p.x + 2, p.y + 1, p.w - 4, Math.min(h - 2, 26), '#2a333b', 3);
    const slide = (t * speed * dir) % 19;
    for (let x = p.x - 20 + slide; x < p.x + p.w + 20; x += 19) {
      line(c, x, p.y + 2, x + 5, p.y + Math.min(h - 2, 26), '#677b73', 2);
      line(c, x + 3, p.y + 2, x + 8, p.y + Math.min(h - 2, 26), '#17242e', 2);
    }
    for (let x = p.x + 34; x < p.x + p.w - 25; x += 50) label(c, dir > 0 ? '››' : '‹‹', x, p.y + 13, 17, '#ffda8b', 'center', 800);
    c.restore();
    const r = Math.min(h * .4, 9);
    for (const x of [p.x + r + 3, p.x + p.w - r - 3]) {
      gear(c, x, p.y + r + 3, r, 9, t * dir * speed / 15, '#b89456', '#384d4c'); circle(c, x, p.y + r + 3, 2, '#e1c993');
    }
    line(c, p.x + 3, p.y + 1, p.x + p.w - 3, p.y + 1, '#ead08b', 2);
  }

  movingGuides(p, t) {
    const c = this.ctx, bx = p.baseX ?? p.x, by = p.baseY ?? p.y;
    const ax = Math.abs(p.amplitudeX || 0), ay = Math.abs(p.amplitudeY || 0);
    c.save(); c.globalAlpha = .5;
    if (ax > 0 && ay > 0) {
      c.setLineDash([3, 8]); line(c, bx - ax + p.w / 2, by - ay, bx + ax + p.w / 2, by + ay, '#e7a26a', 2); c.setLineDash([]);
      for (const pos of [[bx - ax + p.w / 2, by - ay], [bx + ax + p.w / 2, by + ay]]) circle(c, pos[0], pos[1], 6, null, '#e2ab74', 1.5);
    } else if (ay >= ax) {
      for (const x of [bx - 8, bx + p.w + 8]) {
        line(c, x, by - ay - 17, x, by + ay + 36, '#553f34', 7);
        line(c, x, by - ay - 17, x, by + ay + 36, '#e7a26a', 1.5);
        for (const y of [by - ay - 17, by + ay + 36]) rect(c, x - 5, y - 3, 10, 6, '#e2ab74', 1);
      }
    } else {
      const y = by + (p.h || 24) + 13;
      line(c, bx - ax - 10, y, bx + ax + p.w + 10, y, '#4e3a32', 6);
      line(c, bx - ax - 10, y, bx + ax + p.w + 10, y, '#e7a26a', 1.5);
      for (const x of [bx - ax - 10, bx + ax + p.w + 10]) rect(c, x - 3, y - 5, 6, 10, '#e2ab74', 1);
    }
    c.restore();
  }

  hazard(h, t) {
    const c = this.ctx;
    if (h.type === 'acid') {
      const g = c.createLinearGradient(0, h.y, 0, h.y + h.h);
      g.addColorStop(0, '#87eab8'); g.addColorStop(.12, '#37b8a0'); g.addColorStop(1, '#0c5262');
      rect(c, h.x, h.y + 3, h.w, h.h, g);
      c.beginPath(); c.moveTo(h.x, h.y + 5);
      for (let x = 0; x <= h.w; x += 7) c.lineTo(h.x + x, h.y + Math.sin(x * .09 + t * 3) * 2);
      c.lineTo(h.x + h.w, h.y + 9); c.lineTo(h.x, h.y + 9); c.closePath(); c.fillStyle = '#a4f5c8'; c.fill();
      for (let i = 0; i < Math.min(12, h.w / 17); i++) {
        const x = h.x + hash(i + h.x) * h.w, y = h.y + 15 + ((hash(i + 2) * 70 - t * 15) % 70 + 70) % 70;
        circle(c, x, y, 2 + hash(i + 3) * 4, null, 'rgba(165,251,202,.3)', 1);
      }
      if (h.w > 130) label(c, 'LIQUIDE DE REFROIDISSEMENT « BIO »', h.x + h.w / 2, h.y + Math.min(h.h * .6, 52), 8, '#b6e8d1', 'center');
    } else {
      rect(c, h.x, h.y + h.h - 5, h.w, 7, '#432c37', 2, '#89434a');
      const count = Math.max(1, Math.floor(h.w / 21)), step = h.w / count;
      for (let i = 0; i < count; i++) {
        const x = h.x + i * step;
        c.beginPath(); c.moveTo(x + 1, h.y + h.h - 4); c.lineTo(x + step * .5, h.y); c.lineTo(x + step - 1, h.y + h.h - 4); c.closePath();
        c.fillStyle = '#bb6371'; c.fill(); c.strokeStyle = '#542d3c'; c.lineWidth = 1.5; c.stroke();
        line(c, x + step * .5, h.y + 2, x + step - 3, h.y + h.h - 7, '#ffa9a3', 1.5);
      }
    }
  }

  pickup(item, t) {
    const c = this.ctx, bob = Math.sin(t * 3.2 + item.x * .04) * 4;
    const x = item.x, y = item.y + bob;
    c.save(); c.translate(x, y);
    if (item.type === 'module') {
      c.shadowColor = '#72e9df'; c.shadowBlur = 15;
      c.save(); c.rotate(Math.sin(t * 1.1 + item.x) * .08);
      rect(c, -14, -16, 28, 32, '#205360', 6, '#8bffee', 2);
      rect(c, -8, -10, 16, 20, '#50d7ce', 2); rect(c, -4, -6, 8, 12, '#d5fff2', 1);
      c.shadowBlur = 0;
      for (let i = 0; i < 4; i++) {
        line(c, -18, -10 + i * 7, -14, -10 + i * 7, '#84e7d4', 2);
        line(c, 14, -10 + i * 7, 18, -10 + i * 7, '#84e7d4', 2);
      }
      c.restore();
      c.globalAlpha = .4;
      c.setLineDash([3, 6]); circle(c, 0, 0, 25, null, '#83eddf'); c.setLineDash([]);
      c.globalAlpha = 1;
      label(c, 'ECTS', 0, -29, 8, '#a9ffe8', 'center', 700);
    } else if (item.type === 'coffee') {
      c.shadowColor = '#e9c58a'; c.shadowBlur = 9;
      rect(c, -10, -7, 19, 20, P.cream, 3, '#775d44', 1.5); c.shadowBlur = 0;
      circle(c, 12, 1, 6, null, P.cream, 3);
      ellipse(c, -.5, -7, 8, 2.5, '#533d31');
      line(c, -6, 14, 6, 14, '#96735a', 2);
      c.globalAlpha = .65; c.strokeStyle = '#f3dfb9'; c.lineWidth = 1.3;
      for (let i = 0; i < 2; i++) {
        c.beginPath(); c.moveTo(-4 + i * 7, -13); c.bezierCurveTo(-9 + i * 7, -19, 2 + i * 7, -22, -3 + i * 7, -28); c.stroke();
      }
    } else {
      const squeeze = .6 + Math.abs(Math.cos(t * 2 + item.x * .03)) * .4;
      c.scale(squeeze, 1); c.shadowColor = '#ffc95e'; c.shadowBlur = 9;
      c.beginPath();
      for (let i = 0; i < 6; i++) {
        const a = i / 6 * TAU; if (!i) c.moveTo(Math.cos(a) * 9, Math.sin(a) * 9); else c.lineTo(Math.cos(a) * 9, Math.sin(a) * 9);
      }
      c.closePath(); c.fillStyle = '#ffcf66'; c.fill(); c.strokeStyle = '#99652d'; c.lineWidth = 1.5; c.stroke();
      c.shadowBlur = 0; circle(c, 0, 0, 3.2, '#596758');
      line(c, -5, -5, 2, -6, '#fff4af', 1.5);
    }
    c.restore();
  }

  checkpoint(cp, t) {
    const c = this.ctx, color = cp.active ? '#8affda' : '#8faaa5';
    rect(c, cp.x - 10, cp.y - 1, 38, 7, '#17363e', 3, '#60857b');
    line(c, cp.x + 2, cp.y - 4, cp.x + 2, cp.y - 94, '#708c7f', 3);
    const flap = Math.sin(t * 4) * 3;
    c.beginPath(); c.moveTo(cp.x + 4, cp.y - 91); c.quadraticCurveTo(cp.x + 23, cp.y - 94 + flap, cp.x + 41, cp.y - 89);
    c.lineTo(cp.x + 35, cp.y - 68); c.quadraticCurveTo(cp.x + 20, cp.y - 68 + flap, cp.x + 4, cp.y - 72); c.closePath();
    c.fillStyle = cp.active ? '#3ba887' : '#415f5d'; c.fill();
    label(c, cp.active ? '✓' : '↺', cp.x + 21, cp.y - 81, 13, color, 'center', 700);
    c.save(); c.shadowColor = color; c.shadowBlur = cp.active ? 15 : 0;
    circle(c, cp.x + 2, cp.y - 95, 3, color); c.restore();
  }

  exit(exit, game, t) {
    const c = this.ctx, x = exit.x, y = exit.y, w = exit.w || 70, h = exit.h || 100;
    const open = exit.open;
    rect(c, x - 11, y - 8, w + 22, h + 12, '#092632', 10, '#466e6d', 3);
    rect(c, x - 4, y - 1, w + 8, h + 2, '#0c3c44', 7, open ? '#68eaca' : '#638985', 2);
    const g = c.createLinearGradient(x, y, x + w, y + h);
    if (open) { g.addColorStop(0, '#227d80'); g.addColorStop(.5, '#52e4c2'); g.addColorStop(1, '#13535f'); }
    else { g.addColorStop(0, '#1d444c'); g.addColorStop(1, '#102e39'); }
    rect(c, x + 4, y + 6, w - 8, h - 6, g, 4);
    if (open) {
      c.save(); round(c, x + 4, y + 6, w - 8, h - 6, 4); c.clip(); c.globalAlpha = .35;
      for (let i = 0; i < 11; i++) {
        const yy = y + ((i * 13 - t * 23) % h + h) % h;
        line(c, x + 7, yy, x + w - 7, yy - 4, '#d0ffdd', 1);
      }
      c.restore();
      const halo = c.createRadialGradient(x + w / 2, y + h / 2, 8, x + w / 2, y + h / 2, 90);
      halo.addColorStop(0, 'rgba(116,255,198,.15)'); halo.addColorStop(1, 'rgba(116,255,198,0)');
      c.fillStyle = halo; c.fillRect(x - 55, y - 35, 180, 180);
      label(c, '↗', x + w / 2, y + h / 2, 35, '#d0ffdd', 'center', 500);
    } else {
      for (let xx = x + 14; xx < x + w; xx += 17) line(c, xx, y + 10, xx, y + h - 6, '#376166', 3);
      round(c, x + w / 2 - 9, y + 38, 18, 16, 3); c.fillStyle = '#d8bd7b'; c.fill();
      c.beginPath(); c.arc(x + w / 2, y + 38, 6, Math.PI, 0); c.strokeStyle = '#d8bd7b'; c.lineWidth = 3; c.stroke();
      circle(c, x + w / 2, y + 45, 2, '#505d4c');
    }
    rect(c, x - 18, y - 39, w + 36, 25, '#193b42', 4, '#6a8e79', 1.5);
    label(c, (game.level?.index || 0) >= 3 ? 'LE JURY' : 'PROCHAIN TP', x + w / 2, y - 26, 10, '#d2dec0', 'center', 800);
    const lamps = [x - 7, x + w + 7];
    for (const xx of lamps) for (let i = 0; i < 5; i++) rect(c, xx - 2, y + 7 + i * 18, 4, 8, open ? '#9effd7' : '#cb995c', 1);
    rect(c, x - 13, y + h, w + 26, 8, '#769e8b', 3, '#163d44', 1.5);
  }

  npc(npc, t) {
    const c = this.ctx, x = npc.x, y = npc.y, hue = npc.color || '#b58bd2';
    const guest = npc.guestId || npc.id || '', float = Math.sin(t * 1.2 + x) * .8;
    if (guest === 'arduino' || guest === 'coach') { this.specialGuest(npc, t); return; }
    const variant = guest === 'couple' || guest === 'jury' ? 0 : guest === 'iso' ? 2 : 1;
    c.save(); c.translate(x, y + float);
    ellipse(c, 12, 2, 19, 4, 'rgba(0,17,25,.32)');
    line(c, 6, -12, 4, -2, '#1c2d3a', 7); line(c, 19, -12, 21, -2, '#1c2d3a', 7);
    rect(c, -2, -4, 13, 5, '#557075', 2); rect(c, 17, -4, 13, 5, '#557075', 2);
    rect(c, -1, -34, 28, 27, hue, 7, '#102b35', 1.8);
    rect(c, 7, -34, 9, 25, '#e6debc', 2); line(c, 12, -30, 12, -13, '#466a63', 2);
    line(c, 1, -28, -6, -13, hue, 7); line(c, 26, -28, 32, -16, hue, 7);
    circle(c, 12, -45, 11, '#deba86', '#283e3a', 1.5);
    if (guest === 'pid') {
      rect(c, -1, -58, 26, 27, '#749b94', 6, '#264d53', 1.5);
      rect(c, 2, -50, 20, 9, '#143947', 3);
      rect(c, 6, -47, 4, 3, '#9affe5', 1); rect(c, 15, -47, 4, 3, '#9affe5', 1);
      for (let i = 0; i < 3; i++) line(c, 7 + i * 5, -36, 9 + i * 5, -36, '#20434b', 1.5);
      line(c, 12, -59, 12, -65, '#7eb2a5', 2); circle(c, 12, -67, 3, '#aff5d0');
    } else if (variant === 0) {
      ellipse(c, 12, -50, 13, 5, '#4f7770'); rect(c, 0, -55, 25, 5, '#81a192', 2);
      circle(c, 7, -44, 4, null, '#3b5855', 1.5); circle(c, 17, -44, 4, null, '#3b5855', 1.5); line(c, 11, -44, 13, -44, '#3b5855');
      rect(c, 3, -38, 18, 7, '#e7e3cf', 4);
    } else if (variant === 1) {
      c.beginPath(); c.moveTo(0, -48); c.lineTo(2, -58); c.lineTo(8, -55); c.lineTo(12, -62); c.lineTo(17, -56); c.lineTo(23, -59); c.lineTo(25, -48); c.closePath(); c.fillStyle = guest === 'linkedin' ? '#8e6449' : '#293f41'; c.fill();
      circle(c, 8, -45, 1.6, '#24403c'); circle(c, 18, -45, 1.6, '#24403c');
      line(c, 8, -36, 17, -35, '#845e4f', 1.3);
    } else {
      ellipse(c, 12, -52, 13, 6, '#a76647'); rect(c, 0, -53, 6, 21, '#a76647', 3); rect(c, 20, -53, 6, 21, '#a76647', 3);
      circle(c, 8, -44, 1.5, '#24403c'); circle(c, 17, -44, 1.5, '#24403c');
      c.beginPath(); c.arc(13, -40, 4, 0, Math.PI); c.strokeStyle = '#955740'; c.lineWidth = 1.2; c.stroke();
    }
    if (guest === 'linkedin') {
      c.beginPath(); c.moveTo(9, -33); c.lineTo(15, -33); c.lineTo(14, -27); c.lineTo(16, -13); c.lineTo(11, -10); c.lineTo(8, -14); c.lineTo(11, -27); c.closePath(); c.fillStyle = '#da6887'; c.fill();
      rect(c, -8, -18, 9, 12, '#174c72', 2); label(c, 'in', -3.5, -12, 7, '#aeddf4', 'center', 800);
    }
    rect(c, 25, -23, 14, 19, '#d4c794', 2, '#627264', 1); line(c, 29, -16, 35, -16, '#7b856f'); line(c, 29, -12, 35, -12, '#7b856f');
    const name = npc.name || 'LE PROF';
    c.font = '700 8px "Trebuchet MS", system-ui, sans-serif';
    const tw = Math.min(180, c.measureText(name).width + 14);
    rect(c, 12 - tw / 2, -78, tw, 16, '#13323c', 4, '#638179');
    label(c, name, 12, -70, 8, '#e2dfbf', 'center', 700);
    c.restore();
  }

  specialGuest(npc, t) {
    const c = this.ctx, board = (npc.guestId || npc.id) === 'arduino';
    c.save(); c.translate(npc.x, npc.y);
    ellipse(c, 14, 2, 21, 4, 'rgba(0,17,25,.3)');
    if (board) {
      line(c, 5, -10, 2, -3, '#688d72', 5); line(c, 25, -10, 29, -3, '#688d72', 5);
      rect(c, -5, -4, 13, 5, '#b6c791', 2); rect(c, 23, -4, 13, 5, '#b6c791', 2);
      rect(c, -6, -51, 41, 42, '#298f70', 5, '#b3d495', 1.5);
      for (let i = 0; i < 7; i++) { rect(c, -10, -46 + i * 5, 5, 2, '#d4c781'); rect(c, 35, -46 + i * 5, 5, 2, '#d4c781'); }
      rect(c, 1, -42, 27, 20, '#134c4d', 3, '#83bea1');
      rect(c, 6, -35, 5, 4, '#b9ffd9', 1); rect(c, 19, -35, 5, 4, '#b9ffd9', 1);
      line(c, 10, -27, 19, -27, '#92e5b1', 1.5);
      rect(c, 0, -17, 9, 6, '#d6d6ac', 1); circle(c, 29, -17, 2, '#eff07f');
      label(c, 'UNO', 20, -15, 6, '#bbffcf', 'center', 800);
      line(c, 13, -52, 13, -59, '#95c788', 2); circle(c, 13, -61, 3, '#cbf49f');
      line(c, -8, -33, -17, -23 + Math.sin(t * 3) * 3, '#8bc498', 3);
      line(c, 39, -32, 45, -41 + Math.sin(t * 3) * 3, '#8bc498', 3); circle(c, 45, -41 + Math.sin(t * 3) * 3, 3, '#d4dbaf');
    } else {
      const bob = Math.sin(t * 2.1 + npc.x) * 3;
      c.translate(0, -5 + bob);
      rect(c, -9, -55, 47, 52, '#994a8d', 6, '#edb1d7', 1.8);
      rect(c, -3, -48, 35, 38, '#ead5df', 2, '#ae94a8');
      rect(c, 4, -60, 20, 10, '#796586', 3, '#b4a4bd', 1.5);
      line(c, 7, -34, 10, -32, '#714968', 2); line(c, 20, -32, 23, -34, '#714968', 2);
      c.beginPath(); c.arc(15, -27, 6, 0, Math.PI); c.strokeStyle = '#a35480'; c.lineWidth = 1.5; c.stroke();
      for (let i = 0; i < 3; i++) line(c, 4, -19 + i * 3, 24, -19 + i * 3, '#b394aa', 1);
      line(c, -9, -34, -19, -24, '#d887ba', 4); circle(c, -21, -22, 3, '#e9accb');
      line(c, 38, -34, 45, -40, '#d887ba', 4); circle(c, 47, -41, 3, '#e9accb');
      c.save(); c.globalAlpha = .45; ellipse(c, 14, 3, 17, 3, '#c795e3'); c.restore();
      label(c, 'PITCH', 14, -42, 7, '#986783', 'center', 800);
      c.translate(0, 5 - bob);
    }
    const name = npc.name || (board ? 'Arduino sans port' : 'Coach de pitch');
    c.font = '700 8px "Trebuchet MS", system-ui, sans-serif';
    const tw = Math.min(180, c.measureText(name).width + 14);
    rect(c, 14 - tw / 2, -83, tw, 16, board ? '#173e3b' : '#493249', 4, board ? '#96be92' : '#ce98be');
    label(c, name, 14, -75, 8, board ? '#b8eac8' : '#f8d7eb', 'center', 700);
    c.restore();
  }

  enemy(enemy, t) {
    const c = this.ctx, w = enemy.w || 42, h = enemy.h || 38;
    // Internal animation never shifts the body out of the engine's collision box.
    c.save(); c.translate(enemy.x, enemy.y);
    c.beginPath(); c.rect(0, 0, w, h); c.clip();
    if (enemy.type === 'buzzword') {
      rect(c, 1, 1, w - 2, h - 8, '#754880', 9, '#d794dc', 1.8);
      c.beginPath(); c.moveTo(15, h - 9); c.lineTo(19, h - 1); c.lineTo(29, h - 9); c.closePath(); c.fillStyle = '#754880'; c.fill();
      line(c, 15, h - 9, 19, h - 1, '#d794dc', 1.5); line(c, 19, h - 1, 29, h - 9, '#d794dc', 1.5);
      rect(c, 6, h - 23, 14, 11, '#285d90', 2); label(c, 'in', 13, h - 17, 8, '#d6eeff', 'center', 800);
      const text = enemy.label || 'SYNERGIE';
      c.font = '800 9px "Trebuchet MS", system-ui, sans-serif';
      const size = Math.min(9, 9 * (w - 14) / Math.max(1, c.measureText(text).width));
      label(c, text, w / 2, 12, size, '#ffe9f4', 'center', 800);
      const eyeX = w * .62;
      line(c, eyeX - 10, h - 23, eyeX - 2, h - 20, '#ffd2de', 2);
      line(c, eyeX + 10, h - 23, eyeX + 2, h - 20, '#ffd2de', 2);
      line(c, eyeX - 5, h - 14, eyeX + 5, h - 14, '#4b295e', 2);
      c.restore(); return;
    }
    if (enemy.type === 'gear') { c.scale(w / 60, h / 52); this.gearMonster(enemy, t); }
    else if (enemy.type === 'drone') { c.scale(w / 70, h / 46); this.droneMonster(enemy, t); }
    else if (enemy.type === 'stamp') { c.scale(w / 58, h / 55); this.stampMonster(enemy, t); }
    else if (enemy.type === 'question') { c.scale(w / 56, h / 60); this.questionMonster(enemy, t); }
    else { c.scale(w / 42, h / 38); this.basicMonster(enemy, t); }
    c.restore();
  }

  gearMonster(enemy, t) {
    const c = this.ctx, step = Math.sin(t * 11 + enemy.x * .07);
    ellipse(c, 30, 51, 26, 1, 'rgba(0,12,21,.4)');
    for (const side of [-1, 1]) {
      line(c, 30 + side * 13, 39, 30 + side * 18, 45 + step * side, '#aa7655', 5);
      rect(c, 30 + side * 18 - 8, 45 + step * side, 16, 5, '#765b4a', 2, '#d7aa70');
      line(c, 30 + side * 18, 24, 30 + side * 27, 31, '#c09663', 5);
      circle(c, 30 + side * 27, 31, 2.5, '#e3c18b');
    }
    gear(c, 30, 23, 22, 13, (enemy.dir || 1) * t * 1.1, '#a57454', '#e1b97d', false);
    circle(c, 30, 23, 14, '#503c40', '#6a5046', 1.5);
    rect(c, 17, 17, 26, 9, '#272f3a', 3);
    rect(c, 20, 20, 6, 3, '#ffb974', 1); rect(c, 34, 20, 6, 3, '#ffb974', 1);
    line(c, 19, 15, 27, 19, '#ffc990', 2); line(c, 41, 15, 33, 19, '#ffc990', 2);
    c.beginPath(); c.moveTo(23, 31); c.lineTo(26, 35); c.lineTo(30, 31); c.lineTo(34, 35); c.lineTo(38, 31); c.strokeStyle = '#e6c39b'; c.lineWidth = 2; c.stroke();
  }

  droneMonster(enemy, t) {
    const c = this.ctx, rotor = Math.sin(t * 31) * 4;
    line(c, 13, 10, 8, 5, '#5c9c9e', 4); line(c, 57, 10, 62, 5, '#5c9c9e', 4);
    for (const x of [9, 61]) { ellipse(c, x, 4, 8 + rotor * .2, 2, '#a6e5d7'); circle(c, x, 4, 2, '#246b7a'); }
    rect(c, 1, 14, 68, 14, '#286e80', 6, '#87d7d1', 1.5);
    rect(c, 9, 8, 52, 29, '#245463', 7, '#84c8be', 2);
    rect(c, 15, 13, 40, 19, '#082c3d', 4, '#4aada8');
    c.beginPath();
    for (let dx = 0; dx < 36; dx += 2) { const yy = 22 + Math.sin(dx * .32 - t * 6) * 4; if (!dx) c.moveTo(17 + dx, yy); else c.lineTo(17 + dx, yy); }
    c.strokeStyle = '#b3ffe0'; c.lineWidth = 1.4; c.stroke();
    line(c, 17, 13, 27, 17, '#ff977c', 2); line(c, 53, 13, 43, 17, '#ff977c', 2);
    for (const x of [20, 50]) {
      rect(c, x - 5, 36, 10, 5, '#406f71', 2);
      c.beginPath(); c.moveTo(x - 3, 41); c.lineTo(x + 3, 41); c.lineTo(x, 46); c.closePath(); c.fillStyle = '#76e3e4'; c.fill();
    }
    circle(c, 4, 22, 2, '#ffb773'); circle(c, 66, 22, 2, '#ffb773');
  }

  stampMonster(enemy, t) {
    const c = this.ctx, step = Math.sin(t * 10 + enemy.x * .08);
    line(c, 15, 43, 12, 51 + step, '#8d545e', 4); line(c, 43, 43, 46, 51 - step, '#8d545e', 4);
    rect(c, 4, 50 + step, 15, 4, '#472d37', 1); rect(c, 39, 50 - step, 15, 4, '#472d37', 1);
    rect(c, 23, 13, 12, 22, '#863a4c', 4, '#e19a8c', 1.5);
    rect(c, 13, 1, 32, 18, '#b85a68', 8, '#f0ac91', 1.5);
    line(c, 17, 8, 25, 10, '#ffd0a6', 2); line(c, 41, 8, 33, 10, '#ffd0a6', 2);
    circle(c, 22, 12, 1.6, '#4f2b37'); circle(c, 36, 12, 1.6, '#4f2b37');
    rect(c, 2, 31, 54, 17, '#9b4659', 3, '#e0a28b', 1.8);
    rect(c, 4, 43, 50, 5, '#492738', 1);
    label(c, 'REFUSÉ', 29, 39, 8, '#ffd5a8', 'center', 800);
    line(c, 2, 31, 1, 23, '#b76f77', 3); line(c, 56, 31, 57, 23, '#b76f77', 3);
  }

  questionMonster(enemy, t) {
    const c = this.ctx;
    c.beginPath(); c.moveTo(4, 22); c.quadraticCurveTo(4, 4, 28, 2); c.quadraticCurveTo(53, 3, 52, 22);
    c.lineTo(55, 46); c.lineTo(46, 52); c.lineTo(41, 45); c.lineTo(31, 58); c.lineTo(24, 48); c.lineTo(13, 54); c.lineTo(9, 43); c.lineTo(1, 48); c.closePath();
    c.fillStyle = '#dbbf86'; c.fill(); c.strokeStyle = '#8e6860'; c.lineWidth = 1.5; c.stroke();
    label(c, '?', 28, 24, 40, '#aa5068', 'center', 800);
    line(c, 12, 37, 21, 40, '#633d49', 2); line(c, 44, 37, 35, 40, '#633d49', 2);
    rect(c, 17, 41, 4, 3, '#d06365', 1); rect(c, 35, 41, 4, 3, '#d06365', 1);
    line(c, 23, 48, 33, 48, '#875765', 1.5);
  }

  basicMonster(enemy, t) {
    const c = this.ctx, h = 38;
    c.translate(21, 38);
    ellipse(c, 0, 0, 20, 1, 'rgba(0,12,21,.4)');
    const step = Math.sin(t * 12 + enemy.x * .09);
    for (const direction of [-1, 1]) {
      line(c, direction * 11, -8, direction * 16, -3 + step * direction * 2, '#a35b67', 5);
      rect(c, direction * 16 - 7, -4 + step * direction * 2, 14, 5, '#41505b', 2, '#ad7480');
    }
    const body = c.createLinearGradient(0, -h, 0, 0); body.addColorStop(0, '#94495e'); body.addColorStop(1, '#552b45');
    rect(c, -19, -h + 4, 38, h - 11, body, 9, '#27293a', 2);
    rect(c, -21, -h + 14, 42, 9, '#263844', 3, '#af6b78');
    c.save(); c.shadowColor = P.red; c.shadowBlur = 9;
    for (const x of [-8, 8]) rect(c, x - 4, -h + 17, 8, 3, '#ffb29a', 1);
    c.restore();
    line(c, -4, -h + 11, -1, -h + 14, '#f7948d', 1.5); line(c, 4, -h + 11, 1, -h + 14, '#f7948d', 1.5);
    line(c, 0, -h + 4, 0, -h + 1, '#9e717b', 2); circle(c, 0, -h + 2, 2, '#ffba7c');
    for (let i = 0; i < 3; i++) line(c, -6 + i * 6, -8, -6 + i * 6, -13, '#aa777b', 1);
  }

  player(player, t, mode) {
    const c = this.ctx, w = player.w || 34, h = player.h || 48;
    const center = player.x + w / 2, bottom = player.y + h;
    if (player.invincible > 0 && Math.floor(t * 16) % 2 === 0) return;
    const speed = Math.abs(player.vx || 0), phase = player.walkPhase || t * Math.min(speed / 22, 14);
    const walk = player.grounded && speed > 12 ? Math.sin(phase) : 0;
    const grounded = player.grounded || mode === 'menu';
    const bob = grounded ? Math.abs(walk) * 1.5 : 0;
    c.save();
    ellipse(c, center, bottom + 3, grounded ? 21 : 14, grounded ? 4 : 2.5, grounded ? 'rgba(0,12,21,.45)' : 'rgba(0,12,21,.2)');
    c.translate(center, bottom - bob); c.scale(player.facing === -1 ? -1 : 1, 1);
    // Small rucksack and a ruler instantly establish the silhouette.
    rect(c, -18, -35, 10, 23, '#5e8f83', 4, '#163c43', 1.5);
    rect(c, -17, -33, 7, 3, '#98c1a0', 1);
    line(c, -17, -36, -18, -47, '#bdab68', 3);
    for (let yy = -44; yy <= -38; yy += 3) line(c, -18, yy, -16, yy, '#5b644b');
    // Scarf draws a short arc behind the moving engineer.
    c.beginPath(); c.moveTo(-5, -32); c.quadraticCurveTo(-16, -33, -24 - speed * .016, -29 + Math.sin(t * 10) * 3);
    c.lineTo(-20 - speed * .015, -24 + Math.sin(t * 10) * 3); c.quadraticCurveTo(-12, -28, -4, -27);
    c.closePath(); c.fillStyle = '#e97668'; c.fill();
    const leftLeg = grounded ? walk * 5 : -4, rightLeg = grounded ? -walk * 5 : 6;
    line(c, -6, -15, -7 + leftLeg, -4, '#2a4552', 7);
    line(c, 6, -15, 7 + rightLeg, -4, '#355767', 7);
    rect(c, -13 + leftLeg, -5, 14, 6, '#192d39', 2, '#597179', 1);
    rect(c, 3 + rightLeg, -5, 15, 6, '#192d39', 2, '#597179', 1);
    // Coat with shaded hem, pockets and a tactile utility belt.
    const coat = c.createLinearGradient(-12, -34, 12, -12); coat.addColorStop(0, '#fff5d5'); coat.addColorStop(1, '#bdc7af');
    rect(c, -12, -34, 25, 25, coat, 7, '#224149', 1.5);
    c.beginPath(); c.moveTo(-10, -21); c.lineTo(-15, -10); c.lineTo(-2, -10); c.lineTo(0, -21); c.closePath(); c.fillStyle = '#e9e6c9'; c.fill();
    c.beginPath(); c.moveTo(2, -23); c.lineTo(4, -10); c.lineTo(15, -10); c.lineTo(12, -23); c.closePath(); c.fillStyle = '#cad3b9'; c.fill();
    line(c, 0, -31, 1, -11, '#8da496', 1);
    rect(c, -13, -19, 27, 4, '#7f6b46', 1);
    rect(c, 2, -20, 5, 5, '#e6c574', 1, '#866543');
    rect(c, -8, -18, 4, 10, '#9b7a45', 1); line(c, -6, -17, -6, -10, '#e7bd64', 1.5);
    // Sleeves and hands react to takeoff; the front hand holds a tiny wrench.
    const armY = grounded ? -22 + walk * 2 : -31;
    line(c, -10, -29, -14 - walk * 1.5, grounded ? -18 - walk * 2 : -27, '#e7e9cf', 7);
    circle(c, -14 - walk * 1.5, grounded ? -15 - walk * 2 : -24, 3.6, '#e7b879');
    line(c, 10, -28, 16 + walk * 1.5, armY, '#f3edce', 7);
    circle(c, 17 + walk * 1.5, armY + 2, 3.7, '#e7b879');
    line(c, 20 + walk * 1.5, armY + 2, 23 + walk * 1.5, armY - 10, '#b4c7bb', 2.5);
    c.beginPath(); c.arc(23 + walk * 1.5, armY - 11, 3.5, .3, Math.PI * 1.25); c.strokeStyle = '#cee0ce'; c.lineWidth = 2.5; c.stroke();
    // Face, protective glasses and cheerful oversized yellow hardhat.
    rect(c, -9, -46, 22, 17, '#e9ba7d', 7, '#294048', 1.2);
    rect(c, -9, -42, 3, 9, '#ad835c', 1);
    circle(c, 13, -37, 3, '#f0c58a');
    rect(c, -4, -42, 18, 6, '#b5e8df', 2, '#426c6a', 1.1);
    rect(c, -2, -41, 3, 3, '#294f55', 1); rect(c, 8, -41, 3, 3, '#294f55', 1);
    line(c, 3, -39, 7, -39, '#436a66', 1);
    line(c, 7, -32, 11, -32, '#8a5b41', 1.2);
    c.beginPath(); c.arc(0, -46, 15, Math.PI, 0); c.lineTo(15, -43); c.lineTo(-15, -43); c.closePath();
    const hat = c.createLinearGradient(0, -60, 0, -41); hat.addColorStop(0, '#ffe9a4'); hat.addColorStop(.5, '#ffcc5e'); hat.addColorStop(1, '#d69b39');
    c.fillStyle = hat; c.fill(); c.strokeStyle = '#775c32'; c.lineWidth = 1.3; c.stroke();
    rect(c, -18, -45, 38, 5, '#ffd76d', 2, '#9e7439', 1);
    line(c, -1, -58, -1, -47, '#fff3c2', 3);
    rect(c, 5, -53, 5, 5, '#6e966f', 1); line(c, 7, -52, 7, -49, '#ecedbc');
    c.restore();
  }

  particles(particles) {
    const c = this.ctx;
    for (const p of particles) {
      c.globalAlpha = Math.max(0, Math.min(1, p.life / (p.maxLife || 1)));
      const size = p.size || 3;
      if (size > 3.5) {
        c.save(); c.translate(p.x, p.y); c.rotate((p.life || 0) * 4);
        rect(c, -size / 2, -size / 2, size, size, p.color || '#ffe4a3', 1);
        c.restore();
      } else circle(c, p.x, p.y, size, p.color || '#baffdf');
    }
    c.globalAlpha = 1;
  }

  foreground(game, t) {
    const c = this.ctx, w = this.width, h = this.height;
    // Cinematic peripheral falloff leaves the actual game bright and crisp.
    const vignette = c.createRadialGradient(w * .53, h * .48, Math.min(w, h) * .23, w * .53, h * .48, Math.max(w, h) * .69);
    vignette.addColorStop(0, 'rgba(3,16,24,0)'); vignette.addColorStop(1, 'rgba(3,16,24,.6)');
    c.fillStyle = vignette; c.fillRect(0, 0, w, h);
    const bottom = c.createLinearGradient(0, h - 70, 0, h);
    bottom.addColorStop(0, 'rgba(2,19,25,0)'); bottom.addColorStop(1, 'rgba(2,19,25,.25)');
    c.fillStyle = bottom; c.fillRect(0, h - 70, w, 70);
  }
}

export default Renderer;
