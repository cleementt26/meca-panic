const TAU = Math.PI * 2;
const P = {
  ink: '#06171f', navy: '#09252f', steel: '#16454d', teal: '#40d5c6',
  mint: '#b5fff0', gold: '#ffd46b', orange: '#f9a945', cream: '#f5edcf',
  red: '#ff6c78', pink: '#e87da5', blue: '#6cdcff', muted: '#669594',
};

function round(c, x, y, w, h, r = 8) {
  r = Math.min(r, Math.abs(w) / 2, Math.abs(h) / 2);
  c.beginPath();
  c.moveTo(x + r, y); c.arcTo(x + w, y, x + w, y + h, r);
  c.arcTo(x + w, y + h, x, y + h, r); c.arcTo(x, y + h, x, y, r);
  c.arcTo(x, y, x + w, y, r); c.closePath();
}
function rect(c, x, y, w, h, fill, r = 0, stroke = null, line = 1) {
  if (r) round(c, x, y, w, h, r); else { c.beginPath(); c.rect(x, y, w, h); }
  if (fill) { c.fillStyle = fill; c.fill(); }
  if (stroke) { c.strokeStyle = stroke; c.lineWidth = line; c.stroke(); }
}
function line(c, x1, y1, x2, y2, color, width = 1) {
  c.beginPath(); c.moveTo(x1, y1); c.lineTo(x2, y2); c.strokeStyle = color;
  c.lineWidth = width; c.stroke();
}
function circle(c, x, y, r, fill, stroke = null, lw = 1) {
  c.beginPath(); c.arc(x, y, r, 0, TAU);
  if (fill) { c.fillStyle = fill; c.fill(); }
  if (stroke) { c.strokeStyle = stroke; c.lineWidth = lw; c.stroke(); }
}
function ellipse(c, x, y, rx, ry, fill) {
  c.beginPath(); c.ellipse(x, y, rx, ry, 0, 0, TAU); c.fillStyle = fill; c.fill();
}
function label(c, text, x, y, size = 12, color = P.cream, align = 'left', weight = 600) {
  c.font = `${weight} ${size}px "Trebuchet MS", system-ui, sans-serif`;
  c.fillStyle = color; c.textAlign = align; c.textBaseline = 'middle'; c.fillText(text, x, y);
}
function hash(n) { const v = Math.sin(n * 127.1 + 311.7) * 43758.5453; return v - Math.floor(v); }
function gear(c, x, y, r, teeth, rotation, fill, rim, hub = true) {
  c.save(); c.translate(x, y); c.rotate(rotation); c.beginPath();
  for (let i = 0; i < teeth * 4; i++) {
    const a = i / (teeth * 4) * TAU;
    const rad = i % 4 === 1 || i % 4 === 2 ? r : r * .87;
    const px = Math.cos(a) * rad, py = Math.sin(a) * rad;
    if (!i) c.moveTo(px, py); else c.lineTo(px, py);
  }
  c.closePath(); c.fillStyle = fill; c.fill();
  if (rim) { c.strokeStyle = rim; c.lineWidth = 2; c.stroke(); }
  circle(c, 0, 0, r * .68, null, rim || '#17434a', 2);
  if (hub) {
    for (let i = 0; i < 6; i++) {
      const a = i / 6 * TAU;
      line(c, Math.cos(a) * r * .2, Math.sin(a) * r * .2, Math.cos(a) * r * .65, Math.sin(a) * r * .65, rim || '#17434a', r * .085);
    }
    circle(c, 0, 0, r * .22, fill, rim || '#17434a', 2);
    circle(c, 0, 0, r * .085, rim || '#17434a');
  }
  c.restore();
}

export class Renderer {
  constructor(canvas) {
    this.canvas = canvas;
    this.ctx = canvas.getContext('2d', { alpha: false });
    this.width = 1000; this.height = 650; this.dpr = 1; this.elapsed = 0;
    this.resize();
  }

  resize() {
    const bounds = this.canvas.getBoundingClientRect();
    this.width = Math.max(1, bounds.width || window.innerWidth || 1000);
    this.height = Math.max(1, bounds.height || window.innerHeight || 650);
    this.dpr = Math.min(window.devicePixelRatio || 1, 2);
    this.canvas.width = Math.round(this.width * this.dpr);
    this.canvas.height = Math.round(this.height * this.dpr);
    this.ctx.setTransform(this.dpr, 0, 0, this.dpr, 0, 0);
  }

  render(game, dt = 1 / 60) {
    this.elapsed += Math.min(dt || 0, .05);
    const c = this.ctx, t = Number.isFinite(game.time) ? game.time : this.elapsed;
    const level = game.level;
    c.setTransform(this.dpr, 0, 0, this.dpr, 0, 0);
    c.globalAlpha = 1; c.shadowBlur = 0;
    this.background(game, t);
    if (!level) return;
    const scale = game.viewScale || 1, camera = game.camera || { x: 0, y: 0 };
    const shake = Math.min(game.effects?.shake || 0, 1) * 20;
    c.save();
    c.translate(shake ? Math.sin(t * 97) * shake : 0, shake ? Math.cos(t * 83) * shake * .6 : 0);
    c.scale(scale, scale); c.translate(-camera.x, -camera.y);
    this.worldBackdrop(game, t);
    for (const cp of level.checkpoints || []) this.checkpoint(cp, t);
    for (const p of level.platforms || []) if (this.visible(p, game, 90)) this.platform(p, t);
    for (const h of level.hazards || []) if (this.visible(h, game, 90)) this.hazard(h, t);
    if (level.exit) this.exit(level.exit, game, t);
    for (const item of level.pickups || []) if (!item.collected && this.visible(item, game, 70)) this.pickup(item, t);
    for (const npc of level.npcs || []) if (this.visible(npc, game, 100)) this.npc(npc, t);
    for (const enemy of level.enemies || []) if (enemy.alive && this.visible(enemy, game, 80)) this.enemy(enemy, t);
    if (game.player) this.player(game.player, t, game.mode);
    this.particles(game.particles || []);
    c.restore();
    this.foreground(game, t);
    if ((game.effects?.flash || 0) > 0) {
      c.fillStyle = `rgba(255,245,205,${Math.min(game.effects.flash * .5, .35)})`;
      c.fillRect(0, 0, this.width, this.height);
    }
  }

  visible(o, game, padding = 0) {
    const cx = game.camera?.x || 0, cy = game.camera?.y || 0, s = game.viewScale || 1;
    return o.x + (o.w || 80) > cx - padding && o.x < cx + this.width / s + padding &&
      o.y + (o.h || 120) > cy - padding && o.y < cy + this.height / s + padding;
  }

  background(game, t) {
    const c = this.ctx, w = this.width, h = this.height;
    const camera = game.camera || { x: 0, y: 0 }, s = game.viewScale || 1;
    const index = game.level?.index || 0;
    const sky = c.createLinearGradient(0, 0, 0, h);
    sky.addColorStop(0, index === 2 ? '#231c38' : index === 3 ? '#222c2e' : '#081f2b');
    sky.addColorStop(.6, index === 2 ? '#294256' : index === 1 ? '#104d55' : index === 3 ? '#42514a' : '#12474d');
    sky.addColorStop(1, '#062028');
    c.fillStyle = sky; c.fillRect(0, 0, w, h);

    // The circular reactor is a landmark, offset in depth as the camera moves.
    const reactorX = w * .76 - camera.x * s * .035;
    const reactorY = h * .35 - camera.y * s * .06;
    const radius = Math.min(w * .205, h * .39);
    const glow = c.createRadialGradient(reactorX, reactorY, radius * .2, reactorX, reactorY, radius * 1.9);
    glow.addColorStop(0, 'rgba(73,220,190,.17)'); glow.addColorStop(1, 'rgba(30,160,155,0)');
    c.fillStyle = glow; c.fillRect(0, 0, w, h);
    c.save(); c.globalAlpha = .28;
    gear(c, reactorX, reactorY, radius, 32, t * .024, '#164b50', '#54a59b');
    circle(c, reactorX, reactorY, radius * .78, '#123e47', '#3d8780', 1);
    c.setLineDash([3, 13]); circle(c, reactorX, reactorY, radius * .73, null, '#77beb0', 1); c.setLineDash([]);
    for (let i = 0; i < 12; i++) {
      const a = i * TAU / 12 + t * .024;
      const x = reactorX + Math.cos(a) * radius * .55, y = reactorY + Math.sin(a) * radius * .55;
      circle(c, x, y, 3, '#8ddace');
    }
    circle(c, reactorX, reactorY, radius * .37, '#173e48', '#61bba9', 2);
    circle(c, reactorX, reactorY, radius * .33, null, '#307275', 8);
    gear(c, reactorX, reactorY, radius * .25, 16, -t * .07, '#204c51', '#81c9b6');
    c.restore();

    // Distant factory roof, windows, cables and fine blueprint annotations.
    const roofY = h * .66 - camera.y * s * .1;
    const offset = ((-camera.x * s * .13) % 250) - 250;
    for (let x = offset; x < w + 250; x += 250) {
      const n = Math.round((x - offset) / 250), bh = 75 + hash(n + 10) * 115;
      rect(c, x, roofY - bh, 217, h - roofY + bh, '#0b303b');
      rect(c, x + 23, roofY - bh - 36, 40, 36, '#0b303b');
      rect(c, x + 77, roofY - bh - 18, 21, 18, '#0b303b');
      line(c, x, roofY - bh, x + 217, roofY - bh, '#25565b', 2);
      for (let col = 0; col < 5; col++) for (let row = 0; row < 3; row++) {
        rect(c, x + 18 + col * 40, roofY - bh + 22 + row * 33, 20, 14,
          hash(col + row * 5 + n * 17) > .38 ? '#245857' : '#133e47', 2);
        line(c, x + 28 + col * 40, roofY - bh + 22 + row * 33, x + 28 + col * 40, roofY - bh + 36 + row * 33, '#143d46');
      }
      c.beginPath(); c.moveTo(x + 50, roofY - bh - 34);
      c.bezierCurveTo(x + 100, roofY - bh + 2, x + 180, roofY - bh + 2, x + 250, roofY - bh - 25);
      c.strokeStyle = '#1e5057'; c.lineWidth = 2; c.stroke();
    }

    c.save(); c.globalAlpha = .085;
    const grid = 46 * s;
    for (let x = (-camera.x * s * .06) % grid; x < w; x += grid) line(c, x, 0, x, h, '#a6eadd');
    for (let y = (-camera.y * s * .06) % grid; y < h; y += grid) line(c, 0, y, w, y, '#a6eadd');
    c.restore();
    c.save(); c.globalAlpha = .15;
    label(c, 'FIG. 07 / SYSTÈME À PEU PRÈS STABLE', w * .62, 32, 9, '#b6ead8', 'left', 500);
    line(c, w * .62, 48, w * .89, 48, '#8bbcac');
    label(c, 'η = CONFIANCE / CAFÉ', w * .68, h * .17, 10, '#b6ead8', 'left', 500);
    c.restore();

    // Broad shafts of daylight, with no noisy per-frame texture.
    c.save(); c.globalCompositeOperation = 'screen';
    for (let i = 0; i < 3; i++) {
      const top = w * (.55 + i * .19);
      const beam = c.createLinearGradient(top, 0, top - h * .35, h);
      beam.addColorStop(0, 'rgba(168,235,202,.07)'); beam.addColorStop(1, 'rgba(94,221,192,0)');
      c.beginPath(); c.moveTo(top, 0); c.lineTo(top + 55, 0);
      c.lineTo(top - h * .5 + 130, h); c.lineTo(top - h * .5 - 160, h);
      c.closePath(); c.fillStyle = beam; c.fill();
    }
    c.restore();
    for (let i = 0; i < 64; i++) {
      const x = ((hash(i + 40) * w + t * (3 + hash(i) * 7) - camera.x * s * .04) % w + w) % w;
      const y = ((hash(i + 99) * h - t * (2 + hash(i + 3) * 5)) % h + h) % h;
      circle(c, x, y, .5 + hash(i + 7) * 1.1, `rgba(174,231,208,${.08 + hash(i + 1) * .17})`);
    }
  }

  worldBackdrop(game, t) {
    const c = this.ctx, level = game.level, cx = game.camera?.x || 0;
    const max = cx + this.width / (game.viewScale || 1);
    const stageHeight = 760;
    // Monumental structural ribs give the level its readable vertical scale.
    for (let x = Math.floor((cx - 160) / 430) * 430; x < max + 200; x += 430) {
      rect(c, x + 18, 66, 27, stageHeight - 66, '#0c3039', 2, '#214c52');
      rect(c, x + 5, 69, 52, 14, '#245054', 2);
      rect(c, x + 6, 610, 50, 14, '#21494f', 2);
      line(c, x + 47, 92, x + 205, 217, '#16424b', 12);
      line(c, x + 40, 92, x + 205, 217, '#2a565b', 2);
      circle(c, x + 31, 93, 3, '#4b6e6d');
      circle(c, x + 31, 598, 3, '#4b6e6d');
      const light = c.createRadialGradient(x + 140, 138, 2, x + 140, 138, 75);
      light.addColorStop(0, 'rgba(250,204,95,.11)'); light.addColorStop(1, 'rgba(250,204,95,0)');
      c.fillStyle = light; c.fillRect(x + 65, 63, 150, 150);
      line(c, x + 140, 0, x + 140, 127, '#10373e', 4);
      rect(c, x + 121, 127, 38, 8, '#45645d', 3);
      rect(c, x + 124, 136, 32, 4, '#ffdb8c', 2);
    }

    // Utility pipes travel behind all collision platforms.
    for (const y of [254, 550]) {
      line(c, Math.max(0, cx - 60), y + 4, Math.min(level.width, max + 60), y + 4, '#071f29', 17);
      line(c, Math.max(0, cx - 60), y, Math.min(level.width, max + 60), y, '#275052', 11);
      line(c, Math.max(0, cx - 60), y - 4, Math.min(level.width, max + 60), y - 4, '#3c6864', 1);
      for (let x = Math.floor(cx / 180) * 180; x < max + 90; x += 180) {
        rect(c, x, y - 9, 10, 18, '#163a44', 2, '#386460');
        circle(c, x + 5, y - 6, 1, '#6d8580');
        circle(c, x + 5, y + 6, 1, '#6d8580');
      }
    }

    const corporate = level.index === 2;
    const jokes = corporate
      ? ['ALIGNEMENT STRATÉGIQUE', 'VISION 360°', 'ÇA SCALE', 'ROADMAP DE LA ROADMAP', 'PIVOTER EST UN MÉTIER', 'SYNERGIE À IMPACT POSITIF']
      : level.index === 1
        ? ['LE SYSTÈME EST STABLE. TOI, MOINS.', 'ERREUR : CONFIANCE TROP ÉLEVÉE', 'P + I + D ≠ REPOS', 'BOUCLE FERMÉE, NUITS OUVERTES', 'DÉPASSEMENT DE DEADLINE', 'ATTENTION AU POINT-VIRGULE']
        : level.index === 3
          ? ['SOUTENANCE : LE BOSS FINAL', 'VOTRE ANNEXE A UNE ANNEXE ?', '10 MINUTES. 12 QUESTIONS.', 'CERTIFIÉ PRESQUE CONFORME', 'DÉMONSTRATION SOUS PRESSION', 'MERCI DE JUSTIFIER LE CAFÉ']
          : ['LABO : ÇA DEVRAIT MARCHER', 'CECI N’EST PAS UN BUG', 'BUREAU DES TOLÉRANCES', 'ISO 9001 — À PEU PRÈS', 'LE CAFÉ EST STRUCTUREL', 'NE PAS SIMULER LE TRAVAIL'];
    for (let x = Math.floor((cx - 300) / 680) * 680; x < max + 200; x += 680) {
      const i = Math.abs(Math.floor(x / 680));
      if (corporate) this.presentation(x + 225, 398, t, i);
      else if (level.index === 1) this.oscilloscope(x + 225, 425, t, i);
      else if (level.index === 3) this.juryDesk(x + 185, 592, t, i);
      else this.machine(x + 230, 510, t, i);
      const sx = x + 90, sy = 325 - (i % 2) * 66;
      line(c, sx + 25, sy - 60, sx + 25, sy, '#436764', 2);
      line(c, sx + 189, sy - 60, sx + 189, sy, '#436764', 2);
      rect(c, sx, sy, 214, 43, '#102f39', 6, '#446963', 1.5);
      rect(c, sx + 8, sy + 8, 4, 27, P.gold, 2);
      label(c, jokes[i % jokes.length], sx + 22, sy + 22, 10, '#a8bbaa', 'left', 700);
      circle(c, sx + 204, sy + 8, 2, '#739083'); circle(c, sx + 204, sy + 35, 2, '#739083');
    }

    // Blueprints in faded white chalk, positioned clear of interactive objects.
    c.save(); c.globalAlpha = .18;
    for (let x = Math.floor(cx / 1200) * 1200 + 370; x < max + 150; x += 1200) {
      gear(c, x, 193, 37, 12, -.12, 'rgba(0,0,0,0)', '#8cd5c9');
      gear(c, x + 60, 167, 22, 9, .1, 'rgba(0,0,0,0)', '#8cd5c9');
      line(c, x - 57, 246, x + 92, 246, '#8cd5c9');
      line(c, x - 57, 239, x - 57, 253, '#8cd5c9');
      line(c, x + 92, 239, x + 92, 253, '#8cd5c9');
      label(c, 'JEU FONCTIONNEL : 0.2 mm', x + 15, 266, 9, '#d1fff1', 'center', 500);
    }
    c.restore();
    if (game.mode === 'menu') this.robotArm(974, 690, t);
  }

  robotArm(x, y, t) {
    const c = this.ctx;
    c.save(); c.translate(x, y);
    const elbow = { x: 35 + Math.sin(t * .45) * 5, y: -275 };
    const wrist = { x: -102, y: -365 + Math.sin(t * .65) * 5 };
    const steel = '#abbaa3', outline = '#1a3c45';
    // Large warm metal articulated arm frames the tiny playable engineer.
    c.lineCap = 'round';
    for (const segment of [[-8, -117, elbow.x, elbow.y], [elbow.x, elbow.y, wrist.x, wrist.y]]) {
      line(c, ...segment, outline, 49); line(c, ...segment, steel, 38);
      line(c, segment[0] - 7, segment[1] - 4, segment[2] - 7, segment[3] - 4, '#dee5c5', 4);
    }
    for (const point of [{ x: -8, y: -117 }, elbow, wrist]) {
      gear(c, point.x, point.y, 29, 14, t * .03, '#516f6b', '#173c44');
      circle(c, point.x, point.y, 22, '#123c47', '#91ada0', 3);
      circle(c, point.x, point.y, 15, '#3c7c78', '#d8e1ba', 1.5);
      circle(c, point.x - 3, point.y - 4, 5, '#a7f3d3');
    }
    // Hydraulic line follows both links and gives the arm real mechanical detail.
    c.beginPath(); c.moveTo(-28, -133); c.bezierCurveTo(-10, -160, -8, -238, elbow.x - 15, elbow.y - 14);
    c.bezierCurveTo(elbow.x - 43, elbow.y - 28, wrist.x + 56, wrist.y + 6, wrist.x - 4, wrist.y + 20);
    c.strokeStyle = '#0b303b'; c.lineWidth = 6; c.stroke(); c.strokeStyle = '#ecb85f'; c.lineWidth = 2; c.stroke();
    c.save(); c.translate(wrist.x - 21, wrist.y - 9); c.rotate(-.3);
    rect(c, -23, -10, 34, 20, '#748f80', 5, outline, 2);
    line(c, -19, -7, -37, -24, '#cbd5b6', 8); line(c, -37, -24, -47, -17, '#cbd5b6', 6);
    line(c, -19, 7, -36, 25, '#cbd5b6', 8); line(c, -36, 25, -47, 18, '#cbd5b6', 6);
    line(c, -45, -26, -47, 31, '#527c7b', 9); line(c, -44, -23, -46, 28, '#b1d1b6', 3);
    c.beginPath(); c.arc(-44, -36, 13, .4, Math.PI * 1.4); c.strokeStyle = '#bed3b7'; c.lineWidth = 8; c.stroke();
    c.restore();
    rect(c, -73, -113, 128, 107, '#133c44', 16, '#456c63', 3);
    rect(c, -62, -105, 106, 78, '#294f51', 10, '#80967c', 2);
    rect(c, -53, -96, 89, 48, '#062c38', 9, '#5e9e8b', 2);
    c.save(); c.shadowColor = '#8affda'; c.shadowBlur = 15;
    circle(c, -6, -73, 14, '#6ef1cf'); c.shadowBlur = 0;
    circle(c, -3 + Math.sin(t * .6) * 3, -73, 7, '#1d6165');
    circle(c, -6, -78, 3, '#d1ffe3'); c.restore();
    for (let i = 0; i < 3; i++) rect(c, -43 + i * 17, -37, 10, 3, '#e1c178', 1);
    label(c, 'PROTO — 404', -10, -17, 9, '#b1c6a9', 'center', 700);
    rect(c, -81, -7, 146, 16, '#355f5b', 5, '#90ab8b', 2);
    for (const xx of [-64, 50]) circle(c, xx, 0, 3, '#d9ce97');
    c.restore();
  }

  machine(x, y, t, variant) {
    const c = this.ctx;
    rect(c, x, y - 114, 180, 180, '#123b43', 8, '#2b5d5a', 2);
    rect(c, x + 9, y - 105, 162, 99, '#0e2d38', 5, '#37615e');
    if (variant % 2 === 0) {
      gear(c, x + 52, y - 59, 32, 12, t * .13, '#28565a', '#427e73');
      gear(c, x + 113, y - 43, 25, 10, -t * .17, '#28565a', '#427e73');
      circle(c, x + 145, y - 85, 4, '#d9bb66');
    } else {
      for (let i = 0; i < 3; i++) {
        rect(c, x + 26 + i * 45, y - 85, 27, 57, '#133e46', 8, '#427b72');
        rect(c, x + 31 + i * 45, y - 52 - Math.sin(t * .8 + i) * 9, 17, 28 + Math.sin(t * .8 + i) * 9, '#2b807b', 4);
        line(c, x + 39 + i * 45, y - 105, x + 39 + i * 45, y - 85, '#385e5c', 6);
      }
    }
    for (let i = 0; i < 6; i++) rect(c, x + 20 + i * 16, y + 15, 8, 26, '#092c35', 2);
    circle(c, x + 143, y + 27, 13, '#163941', '#456a60', 2);
    line(c, x + 143, y + 27, x + 148, y + 19, '#9cc2a6', 2);
    rect(c, x + 15, y + 66, 21, 12, '#092b34', 2); rect(c, x + 144, y + 66, 21, 12, '#092b34', 2);
    label(c, 'PROTO • ' + String(variant + 1).padStart(2, '0'), x + 22, y - 94, 7, '#6d9990', 'left', 500);
  }

  presentation(x, y, t, variant) {
    const c = this.ctx;
    line(c, x + 117, y + 142, x + 117, y + 205, '#30434f', 9);
    line(c, x + 66, y + 211, x + 167, y + 211, '#30434f', 8);
    rect(c, x, y, 240, 150, '#17283b', 7, '#5b657d', 2);
    rect(c, x + 10, y + 9, 220, 132, '#233b50', 2, '#526a7a');
    rect(c, x + 11, y + 10, 218, 25, '#444568', 2);
    label(c, variant % 2 ? 'PLUS D’IMPACT. MOINS DE SENS.' : 'LA CROISSANCE DE LA CROISSANCE', x + 20, y + 23, 8, '#ddc9e4');
    line(c, x + 31, y + 112, x + 208, y + 112, '#587888');
    line(c, x + 31, y + 112, x + 31, y + 50, '#587888');
    for (let i = 0; i < 6; i++) {
      const height = 10 + i * 7 + hash(i + variant) * 13;
      rect(c, x + 45 + i * 26, y + 110 - height, 15, height, i > 3 ? '#bc8acb' : '#559d9c', 2);
    }
    c.beginPath(); c.moveTo(x + 44, y + 89); c.lineTo(x + 81, y + 83); c.lineTo(x + 110, y + 88); c.lineTo(x + 141, y + 71); c.lineTo(x + 175, y + 60); c.lineTo(x + 205, y + 44);
    c.strokeStyle = '#dec58e'; c.lineWidth = 2; c.stroke();
    c.beginPath(); c.moveTo(x + 196, y + 45); c.lineTo(x + 205, y + 44); c.lineTo(x + 202, y + 54); c.stroke();
    label(c, 'Source : on a mis une flèche qui monte.', x + 120, y + 128, 7, '#9fb7bd', 'center', 500);
    circle(c, x + 229, y + 146, 2, '#7cceb6');
  }

  oscilloscope(x, y, t, variant) {
    const c = this.ctx;
    rect(c, x, y, 218, 121, '#19434d', 9, '#4e7b78', 2);
    rect(c, x + 10, y + 10, 157, 84, '#062f3c', 5, '#4c9387', 2);
    c.save(); round(c, x + 12, y + 12, 153, 80, 3); c.clip();
    c.globalAlpha = .23;
    for (let i = 0; i < 7; i++) line(c, x + 15, y + 18 + i * 12, x + 165, y + 18 + i * 12, '#71c7b1');
    for (let i = 0; i < 10; i++) line(c, x + 16 + i * 16, y + 12, x + 16 + i * 16, y + 92, '#71c7b1');
    c.globalAlpha = 1;
    for (let wave = 0; wave < 2; wave++) {
      c.beginPath();
      for (let dx = 0; dx < 156; dx += 3) {
        const yy = y + 52 + Math.sin(dx * .047 - t * 1.3 + variant + wave) * (24 - wave * 8) * Math.exp(-dx * .004);
        if (!dx) c.moveTo(x + 12, yy); else c.lineTo(x + 12 + dx, yy);
      }
      c.strokeStyle = wave ? '#ddbd79' : '#86e5c6'; c.lineWidth = 1.5; c.stroke();
    }
    c.restore();
    for (let i = 0; i < 3; i++) {
      circle(c, x + 190, y + 26 + i * 28, 9, '#102f3b', '#719083', 1.5);
      line(c, x + 190, y + 26 + i * 28, x + 194, y + 22 + i * 28, '#bcc29d', 2);
    }
    label(c, 'ASSERVISSEMENT ÉMOTIONNEL', x + 13, y + 108, 7, '#91b6a1');
    for (const xx of [x + 23, x + 187]) rect(c, xx, y + 121, 13, 23, '#153b43', 2);
  }

  juryDesk(x, y, t, variant) {
    const c = this.ctx;
    for (let i = 0; i < 3; i++) {
      rect(c, x + 21 + i * 80, y - 86, 40, 62, '#334d4f', 11, '#61796a', 1.5);
      circle(c, x + 41 + i * 80, y - 104, 13, '#738476', '#284a4e', 2);
      rect(c, x + 26 + i * 80, y - 97, 31, 5, '#294750', 2);
      line(c, x + 41 + i * 80, y - 109, x + 41 + i * 80, y - 115, '#aab899', 1);
      line(c, x + 60 + i * 80, y - 21, x + 66 + i * 80, y - 44, '#1b3841', 2);
      circle(c, x + 66 + i * 80, y - 46, 4, '#576b65');
    }
    rect(c, x, y - 20, 274, 61, '#254e4f', 6, '#628375', 2);
    rect(c, x - 8, y - 27, 290, 11, '#8caa8b', 3, '#25494b');
    for (let i = 0; i < 3; i++) {
      rect(c, x + 18 + i * 82, y - 33, 37, 5, '#bbc29b', 1);
      rect(c, x + 21 + i * 82, y - 8, 46, 14, '#152f3a', 3, '#718374');
      label(c, ['DOUTE', 'NORME', 'POURQUOI ?'][i], x + 44 + i * 82, y - 1, 6, '#bfcca8', 'center');
    }
    label(c, 'COMMISSION DES QUESTIONS IMPOSSIBLES', x + 136, y + 25, 8, '#9eb49a', 'center');
    rect(c, x + 12, y + 41, 18, 29, '#123841', 2); rect(c, x + 244, y + 41, 18, 29, '#123841', 2);
  }

  platform(p, t) {
    const c = this.ctx, moving = p.type === 'moving', floor = p.type === 'floor';
    const h = Math.max(p.h || 24, 10);
    // A slight undershadow makes every top surface legible against the lab.
    rect(c, p.x + 2, p.y + 5, p.w, h, 'rgba(0,12,20,.5)', 4);
    const g = c.createLinearGradient(p.x, p.y, p.x, p.y + h);
    g.addColorStop(0, floor ? '#286069' : '#3a7073'); g.addColorStop(1, floor ? '#12343f' : '#1a404a');
    rect(c, p.x, p.y, p.w, h, g, floor ? 3 : 5, '#08242e', 2);
    rect(c, p.x + 1, p.y, p.w - 2, 6, moving ? '#81d7e9' : '#9dd7bd', 2);
    rect(c, p.x + 1, p.y + 6, p.w - 2, 3, '#24484b');
    c.save(); round(c, p.x + 2, p.y + 9, p.w - 4, h - 10, 2); c.clip();
    if (floor) {
      for (let x = p.x + 18; x < p.x + p.w; x += 82) {
        rect(c, x, p.y + 20, 55, Math.max(h - 33, 13), '#102f3a', 3, '#326064');
        line(c, x + 5, p.y + 25, x + 48, p.y + h - 18, '#284b52', 3);
        circle(c, x + 5, p.y + 25, 2, '#6b8278'); circle(c, x + 49, p.y + h - 18, 2, '#6b8278');
      }
      line(c, p.x, p.y + 15, p.x + p.w, p.y + 15, '#174149');
    } else {
      // Narrow warning stripes stay below the playable upper edge.
      rect(c, p.x, p.y + h - 9, p.w, 8, '#b9a567');
      c.fillStyle = '#304649';
      for (let x = p.x - 12; x < p.x + p.w + 20; x += 22) {
        c.beginPath(); c.moveTo(x, p.y + h - 9); c.lineTo(x + 10, p.y + h - 9);
        c.lineTo(x + 18, p.y + h); c.lineTo(x + 8, p.y + h); c.closePath(); c.fill();
      }
    }
    c.restore();
    for (let x = p.x + 10; x < p.x + p.w - 3; x += 42) {
      circle(c, x, p.y + 13, 2, '#aac6af'); line(c, x - 1, p.y + 13, x + 1, p.y + 13, '#3a5854');
    }
    if (moving) {
      for (const x of [p.x + 14, p.x + p.w - 14]) {
        rect(c, x - 8, p.y + h - 1, 16, 8, '#173841', 3, '#598f8c');
        c.save(); c.globalAlpha = .6 + Math.sin(t * 12 + x) * .15;
        const plume = c.createLinearGradient(x, p.y + h + 6, x, p.y + h + 32);
        plume.addColorStop(0, '#72e6ee'); plume.addColorStop(1, 'rgba(95,222,237,0)');
        c.beginPath(); c.moveTo(x - 5, p.y + h + 6); c.lineTo(x + 5, p.y + h + 6); c.lineTo(x, p.y + h + 32); c.closePath();
        c.fillStyle = plume; c.fill(); c.restore();
      }
    }
    if (p.label) {
      const lw = Math.min(p.w - 20, 93);
      rect(c, p.x + (p.w - lw) / 2, p.y + h + 5, lw, 15, '#453858', 3, '#8a698f');
      label(c, p.label, p.x + p.w / 2, p.y + h + 13, 7, '#edcce4', 'center', 700);
    }
  }

  hazard(h, t) {
    const c = this.ctx;
    if (h.type === 'acid') {
      const g = c.createLinearGradient(0, h.y, 0, h.y + h.h);
      g.addColorStop(0, '#87eab8'); g.addColorStop(.12, '#37b8a0'); g.addColorStop(1, '#0c5262');
      rect(c, h.x, h.y + 3, h.w, h.h, g);
      c.beginPath(); c.moveTo(h.x, h.y + 5);
      for (let x = 0; x <= h.w; x += 7) c.lineTo(h.x + x, h.y + Math.sin(x * .09 + t * 3) * 2);
      c.lineTo(h.x + h.w, h.y + 9); c.lineTo(h.x, h.y + 9); c.closePath(); c.fillStyle = '#a4f5c8'; c.fill();
      for (let i = 0; i < Math.min(12, h.w / 17); i++) {
        const x = h.x + hash(i + h.x) * h.w, y = h.y + 15 + ((hash(i + 2) * 70 - t * 15) % 70 + 70) % 70;
        circle(c, x, y, 2 + hash(i + 3) * 4, null, 'rgba(165,251,202,.3)', 1);
      }
      if (h.w > 130) label(c, 'LIQUIDE DE REFROIDISSEMENT « BIO »', h.x + h.w / 2, h.y + Math.min(h.h * .6, 52), 8, '#b6e8d1', 'center');
    } else {
      rect(c, h.x, h.y + h.h - 5, h.w, 7, '#432c37', 2, '#89434a');
      const count = Math.max(1, Math.floor(h.w / 21)), step = h.w / count;
      for (let i = 0; i < count; i++) {
        const x = h.x + i * step;
        c.beginPath(); c.moveTo(x + 1, h.y + h.h - 4); c.lineTo(x + step * .5, h.y); c.lineTo(x + step - 1, h.y + h.h - 4); c.closePath();
        c.fillStyle = '#bb6371'; c.fill(); c.strokeStyle = '#542d3c'; c.lineWidth = 1.5; c.stroke();
        line(c, x + step * .5, h.y + 2, x + step - 3, h.y + h.h - 7, '#ffa9a3', 1.5);
      }
    }
  }

  pickup(item, t) {
    const c = this.ctx, bob = Math.sin(t * 3.2 + item.x * .04) * 4;
    const x = item.x, y = item.y + bob;
    c.save(); c.translate(x, y);
    if (item.type === 'module') {
      c.shadowColor = '#72e9df'; c.shadowBlur = 15;
      c.save(); c.rotate(Math.sin(t * 1.1 + item.x) * .08);
      rect(c, -14, -16, 28, 32, '#205360', 6, '#8bffee', 2);
      rect(c, -8, -10, 16, 20, '#50d7ce', 2); rect(c, -4, -6, 8, 12, '#d5fff2', 1);
      c.shadowBlur = 0;
      for (let i = 0; i < 4; i++) {
        line(c, -18, -10 + i * 7, -14, -10 + i * 7, '#84e7d4', 2);
        line(c, 14, -10 + i * 7, 18, -10 + i * 7, '#84e7d4', 2);
      }
      c.restore();
      c.globalAlpha = .4;
      c.setLineDash([3, 6]); circle(c, 0, 0, 25, null, '#83eddf'); c.setLineDash([]);
      c.globalAlpha = 1;
      label(c, 'ECTS', 0, -29, 8, '#a9ffe8', 'center', 700);
    } else if (item.type === 'coffee') {
      c.shadowColor = '#e9c58a'; c.shadowBlur = 9;
      rect(c, -10, -7, 19, 20, P.cream, 3, '#775d44', 1.5); c.shadowBlur = 0;
      circle(c, 12, 1, 6, null, P.cream, 3);
      ellipse(c, -.5, -7, 8, 2.5, '#533d31');
      line(c, -6, 14, 6, 14, '#96735a', 2);
      c.globalAlpha = .65; c.strokeStyle = '#f3dfb9'; c.lineWidth = 1.3;
      for (let i = 0; i < 2; i++) {
        c.beginPath(); c.moveTo(-4 + i * 7, -13); c.bezierCurveTo(-9 + i * 7, -19, 2 + i * 7, -22, -3 + i * 7, -28); c.stroke();
      }
    } else {
      const squeeze = .6 + Math.abs(Math.cos(t * 2 + item.x * .03)) * .4;
      c.scale(squeeze, 1); c.shadowColor = '#ffc95e'; c.shadowBlur = 9;
      c.beginPath();
      for (let i = 0; i < 6; i++) {
        const a = i / 6 * TAU; if (!i) c.moveTo(Math.cos(a) * 9, Math.sin(a) * 9); else c.lineTo(Math.cos(a) * 9, Math.sin(a) * 9);
      }
      c.closePath(); c.fillStyle = '#ffcf66'; c.fill(); c.strokeStyle = '#99652d'; c.lineWidth = 1.5; c.stroke();
      c.shadowBlur = 0; circle(c, 0, 0, 3.2, '#596758');
      line(c, -5, -5, 2, -6, '#fff4af', 1.5);
    }
    c.restore();
  }

  checkpoint(cp, t) {
    const c = this.ctx, color = cp.active ? '#8affda' : '#8faaa5';
    rect(c, cp.x - 10, cp.y - 1, 38, 7, '#17363e', 3, '#60857b');
    line(c, cp.x + 2, cp.y - 4, cp.x + 2, cp.y - 94, '#708c7f', 3);
    const flap = Math.sin(t * 4) * 3;
    c.beginPath(); c.moveTo(cp.x + 4, cp.y - 91); c.quadraticCurveTo(cp.x + 23, cp.y - 94 + flap, cp.x + 41, cp.y - 89);
    c.lineTo(cp.x + 35, cp.y - 68); c.quadraticCurveTo(cp.x + 20, cp.y - 68 + flap, cp.x + 4, cp.y - 72); c.closePath();
    c.fillStyle = cp.active ? '#3ba887' : '#415f5d'; c.fill();
    label(c, cp.active ? '✓' : '↺', cp.x + 21, cp.y - 81, 13, color, 'center', 700);
    c.save(); c.shadowColor = color; c.shadowBlur = cp.active ? 15 : 0;
    circle(c, cp.x + 2, cp.y - 95, 3, color); c.restore();
  }

  exit(exit, game, t) {
    const c = this.ctx, x = exit.x, y = exit.y, w = exit.w || 70, h = exit.h || 100;
    const open = exit.open;
    rect(c, x - 11, y - 8, w + 22, h + 12, '#092632', 10, '#466e6d', 3);
    rect(c, x - 4, y - 1, w + 8, h + 2, '#0c3c44', 7, open ? '#68eaca' : '#638985', 2);
    const g = c.createLinearGradient(x, y, x + w, y + h);
    if (open) { g.addColorStop(0, '#227d80'); g.addColorStop(.5, '#52e4c2'); g.addColorStop(1, '#13535f'); }
    else { g.addColorStop(0, '#1d444c'); g.addColorStop(1, '#102e39'); }
    rect(c, x + 4, y + 6, w - 8, h - 6, g, 4);
    if (open) {
      c.save(); round(c, x + 4, y + 6, w - 8, h - 6, 4); c.clip(); c.globalAlpha = .35;
      for (let i = 0; i < 11; i++) {
        const yy = y + ((i * 13 - t * 23) % h + h) % h;
        line(c, x + 7, yy, x + w - 7, yy - 4, '#d0ffdd', 1);
      }
      c.restore();
      const halo = c.createRadialGradient(x + w / 2, y + h / 2, 8, x + w / 2, y + h / 2, 90);
      halo.addColorStop(0, 'rgba(116,255,198,.15)'); halo.addColorStop(1, 'rgba(116,255,198,0)');
      c.fillStyle = halo; c.fillRect(x - 55, y - 35, 180, 180);
      label(c, '↗', x + w / 2, y + h / 2, 35, '#d0ffdd', 'center', 500);
    } else {
      for (let xx = x + 14; xx < x + w; xx += 17) line(c, xx, y + 10, xx, y + h - 6, '#376166', 3);
      round(c, x + w / 2 - 9, y + 38, 18, 16, 3); c.fillStyle = '#d8bd7b'; c.fill();
      c.beginPath(); c.arc(x + w / 2, y + 38, 6, Math.PI, 0); c.strokeStyle = '#d8bd7b'; c.lineWidth = 3; c.stroke();
      circle(c, x + w / 2, y + 45, 2, '#505d4c');
    }
    rect(c, x - 18, y - 39, w + 36, 25, '#193b42', 4, '#6a8e79', 1.5);
    label(c, (game.level?.index || 0) >= 3 ? 'LE JURY' : 'PROCHAIN TP', x + w / 2, y - 26, 10, '#d2dec0', 'center', 800);
    const lamps = [x - 7, x + w + 7];
    for (const xx of lamps) for (let i = 0; i < 5; i++) rect(c, xx - 2, y + 7 + i * 18, 4, 8, open ? '#9effd7' : '#cb995c', 1);
    rect(c, x - 13, y + h, w + 26, 8, '#769e8b', 3, '#163d44', 1.5);
  }

  npc(npc, t) {
    const c = this.ctx, x = npc.x, y = npc.y, hue = npc.color || '#b58bd2';
    const guest = npc.guestId || npc.id || '', float = Math.sin(t * 1.2 + x) * .8;
    const variant = guest === 'couple' || guest === 'jury' ? 0 : guest === 'iso' ? 2 : 1;
    c.save(); c.translate(x, y + float);
    ellipse(c, 12, 2, 19, 4, 'rgba(0,17,25,.32)');
    line(c, 6, -12, 4, -2, '#1c2d3a', 7); line(c, 19, -12, 21, -2, '#1c2d3a', 7);
    rect(c, -2, -4, 13, 5, '#557075', 2); rect(c, 17, -4, 13, 5, '#557075', 2);
    rect(c, -1, -34, 28, 27, hue, 7, '#102b35', 1.8);
    rect(c, 7, -34, 9, 25, '#e6debc', 2); line(c, 12, -30, 12, -13, '#466a63', 2);
    line(c, 1, -28, -6, -13, hue, 7); line(c, 26, -28, 32, -16, hue, 7);
    circle(c, 12, -45, 11, '#deba86', '#283e3a', 1.5);
    if (guest === 'pid') {
      rect(c, -1, -58, 26, 27, '#749b94', 6, '#264d53', 1.5);
      rect(c, 2, -50, 20, 9, '#143947', 3);
      rect(c, 6, -47, 4, 3, '#9affe5', 1); rect(c, 15, -47, 4, 3, '#9affe5', 1);
      for (let i = 0; i < 3; i++) line(c, 7 + i * 5, -36, 9 + i * 5, -36, '#20434b', 1.5);
      line(c, 12, -59, 12, -65, '#7eb2a5', 2); circle(c, 12, -67, 3, '#aff5d0');
    } else if (variant === 0) {
      ellipse(c, 12, -50, 13, 5, '#4f7770'); rect(c, 0, -55, 25, 5, '#81a192', 2);
      circle(c, 7, -44, 4, null, '#3b5855', 1.5); circle(c, 17, -44, 4, null, '#3b5855', 1.5); line(c, 11, -44, 13, -44, '#3b5855');
      rect(c, 3, -38, 18, 7, '#e7e3cf', 4);
    } else if (variant === 1) {
      c.beginPath(); c.moveTo(0, -48); c.lineTo(2, -58); c.lineTo(8, -55); c.lineTo(12, -62); c.lineTo(17, -56); c.lineTo(23, -59); c.lineTo(25, -48); c.closePath(); c.fillStyle = guest === 'linkedin' ? '#8e6449' : '#293f41'; c.fill();
      circle(c, 8, -45, 1.6, '#24403c'); circle(c, 18, -45, 1.6, '#24403c');
      line(c, 8, -36, 17, -35, '#845e4f', 1.3);
    } else {
      ellipse(c, 12, -52, 13, 6, '#a76647'); rect(c, 0, -53, 6, 21, '#a76647', 3); rect(c, 20, -53, 6, 21, '#a76647', 3);
      circle(c, 8, -44, 1.5, '#24403c'); circle(c, 17, -44, 1.5, '#24403c');
      c.beginPath(); c.arc(13, -40, 4, 0, Math.PI); c.strokeStyle = '#955740'; c.lineWidth = 1.2; c.stroke();
    }
    if (guest === 'linkedin') {
      c.beginPath(); c.moveTo(9, -33); c.lineTo(15, -33); c.lineTo(14, -27); c.lineTo(16, -13); c.lineTo(11, -10); c.lineTo(8, -14); c.lineTo(11, -27); c.closePath(); c.fillStyle = '#da6887'; c.fill();
      rect(c, -8, -18, 9, 12, '#174c72', 2); label(c, 'in', -3.5, -12, 7, '#aeddf4', 'center', 800);
    }
    rect(c, 25, -23, 14, 19, '#d4c794', 2, '#627264', 1); line(c, 29, -16, 35, -16, '#7b856f'); line(c, 29, -12, 35, -12, '#7b856f');
    const name = npc.name || 'LE PROF';
    c.font = '700 8px "Trebuchet MS", system-ui, sans-serif';
    const tw = Math.min(180, c.measureText(name).width + 14);
    rect(c, 12 - tw / 2, -78, tw, 16, '#13323c', 4, '#638179');
    label(c, name, 12, -70, 8, '#e2dfbf', 'center', 700);
    c.restore();
  }

  enemy(enemy, t) {
    const c = this.ctx, w = enemy.w || 42, h = enemy.h || 38;
    if (enemy.type === 'buzzword') {
      const yy = enemy.y + Math.sin(t * 3 + enemy.x * .013) * 2;
      c.save(); c.shadowColor = '#ad65cf'; c.shadowBlur = 13;
      rect(c, enemy.x, yy, w, h - 3, '#67407b', 10, '#bc80d6', 1.8);
      c.shadowBlur = 0;
      c.beginPath(); c.moveTo(enemy.x + 14, yy + h - 4); c.lineTo(enemy.x + 17, yy + h + 8); c.lineTo(enemy.x + 28, yy + h - 4); c.closePath();
      c.fillStyle = '#67407b'; c.fill(); line(c, enemy.x + 14, yy + h - 4, enemy.x + 17, yy + h + 8, '#bc80d6', 1.5);
      line(c, enemy.x + 17, yy + h + 8, enemy.x + 28, yy + h - 4, '#bc80d6', 1.5);
      const text = enemy.label || 'SYNERGIE';
      const size = text.length > 19 ? 6.5 : text.length > 12 ? 7.5 : 9;
      label(c, text, enemy.x + w / 2, yy + 14, size, '#ffe9f4', 'center', 800);
      line(c, enemy.x + w / 2 - 8, yy + h - 12, enemy.x + w / 2 - 2, yy + h - 9, '#ffc1db', 2);
      line(c, enemy.x + w / 2 + 8, yy + h - 12, enemy.x + w / 2 + 2, yy + h - 9, '#ffc1db', 2);
      c.restore();
      return;
    }
    c.save(); c.translate(enemy.x + w / 2, enemy.y + h);
    ellipse(c, 0, 1, 23, 4, 'rgba(0,12,21,.45)');
    const step = Math.sin(t * 12 + enemy.x * .09);
    for (const direction of [-1, 1]) {
      line(c, direction * 11, -8, direction * 16, -3 + step * direction * 2, '#a35b67', 5);
      rect(c, direction * 16 - 7, -4 + step * direction * 2, 14, 5, '#41505b', 2, '#ad7480');
    }
    const body = c.createLinearGradient(0, -h, 0, 0); body.addColorStop(0, '#94495e'); body.addColorStop(1, '#552b45');
    rect(c, -19, -h + 4, 38, h - 11, body, 9, '#27293a', 2);
    rect(c, -21, -h + 14, 42, 9, '#263844', 3, '#af6b78');
    c.save(); c.shadowColor = P.red; c.shadowBlur = 9;
    for (const x of [-8, 8]) rect(c, x - 4, -h + 17, 8, 3, '#ffb29a', 1);
    c.restore();
    line(c, -4, -h + 11, -1, -h + 14, '#f7948d', 1.5); line(c, 4, -h + 11, 1, -h + 14, '#f7948d', 1.5);
    line(c, 0, -h + 4, 0, -h - 4, '#9e717b', 2); circle(c, 0, -h - 5, 3, '#ffba7c');
    for (let i = 0; i < 3; i++) line(c, -6 + i * 6, -8, -6 + i * 6, -13, '#aa777b', 1);
    label(c, 'BUG', 0, -h - 16, 7, '#e79396', 'center', 700);
    c.restore();
  }

  player(player, t, mode) {
    const c = this.ctx, w = player.w || 34, h = player.h || 48;
    const center = player.x + w / 2, bottom = player.y + h;
    if (player.invincible > 0 && Math.floor(t * 16) % 2 === 0) return;
    const speed = Math.abs(player.vx || 0), phase = player.walkPhase || t * Math.min(speed / 22, 14);
    const walk = player.grounded && speed > 12 ? Math.sin(phase) : 0;
    const grounded = player.grounded || mode === 'menu';
    const bob = grounded ? Math.abs(walk) * 1.5 : 0;
    c.save();
    ellipse(c, center, bottom + 3, grounded ? 21 : 14, grounded ? 4 : 2.5, grounded ? 'rgba(0,12,21,.45)' : 'rgba(0,12,21,.2)');
    c.translate(center, bottom - bob); c.scale(player.facing === -1 ? -1 : 1, 1);
    // Small rucksack and a ruler instantly establish the silhouette.
    rect(c, -18, -35, 10, 23, '#5e8f83', 4, '#163c43', 1.5);
    rect(c, -17, -33, 7, 3, '#98c1a0', 1);
    line(c, -17, -36, -18, -47, '#bdab68', 3);
    for (let yy = -44; yy <= -38; yy += 3) line(c, -18, yy, -16, yy, '#5b644b');
    // Scarf draws a short arc behind the moving engineer.
    c.beginPath(); c.moveTo(-5, -32); c.quadraticCurveTo(-16, -33, -24 - speed * .016, -29 + Math.sin(t * 10) * 3);
    c.lineTo(-20 - speed * .015, -24 + Math.sin(t * 10) * 3); c.quadraticCurveTo(-12, -28, -4, -27);
    c.closePath(); c.fillStyle = '#e97668'; c.fill();
    const leftLeg = grounded ? walk * 5 : -4, rightLeg = grounded ? -walk * 5 : 6;
    line(c, -6, -15, -7 + leftLeg, -4, '#2a4552', 7);
    line(c, 6, -15, 7 + rightLeg, -4, '#355767', 7);
    rect(c, -13 + leftLeg, -5, 14, 6, '#192d39', 2, '#597179', 1);
    rect(c, 3 + rightLeg, -5, 15, 6, '#192d39', 2, '#597179', 1);
    // Coat with shaded hem, pockets and a tactile utility belt.
    const coat = c.createLinearGradient(-12, -34, 12, -12); coat.addColorStop(0, '#fff5d5'); coat.addColorStop(1, '#bdc7af');
    rect(c, -12, -34, 25, 25, coat, 7, '#224149', 1.5);
    c.beginPath(); c.moveTo(-10, -21); c.lineTo(-15, -10); c.lineTo(-2, -10); c.lineTo(0, -21); c.closePath(); c.fillStyle = '#e9e6c9'; c.fill();
    c.beginPath(); c.moveTo(2, -23); c.lineTo(4, -10); c.lineTo(15, -10); c.lineTo(12, -23); c.closePath(); c.fillStyle = '#cad3b9'; c.fill();
    line(c, 0, -31, 1, -11, '#8da496', 1);
    rect(c, -13, -19, 27, 4, '#7f6b46', 1);
    rect(c, 2, -20, 5, 5, '#e6c574', 1, '#866543');
    rect(c, -8, -18, 4, 10, '#9b7a45', 1); line(c, -6, -17, -6, -10, '#e7bd64', 1.5);
    // Sleeves and hands react to takeoff; the front hand holds a tiny wrench.
    const armY = grounded ? -22 + walk * 2 : -31;
    line(c, -10, -29, -14 - walk * 1.5, grounded ? -18 - walk * 2 : -27, '#e7e9cf', 7);
    circle(c, -14 - walk * 1.5, grounded ? -15 - walk * 2 : -24, 3.6, '#e7b879');
    line(c, 10, -28, 16 + walk * 1.5, armY, '#f3edce', 7);
    circle(c, 17 + walk * 1.5, armY + 2, 3.7, '#e7b879');
    line(c, 20 + walk * 1.5, armY + 2, 23 + walk * 1.5, armY - 10, '#b4c7bb', 2.5);
    c.beginPath(); c.arc(23 + walk * 1.5, armY - 11, 3.5, .3, Math.PI * 1.25); c.strokeStyle = '#cee0ce'; c.lineWidth = 2.5; c.stroke();
    // Face, protective glasses and cheerful oversized yellow hardhat.
    rect(c, -9, -46, 22, 17, '#e9ba7d', 7, '#294048', 1.2);
    rect(c, -9, -42, 3, 9, '#ad835c', 1);
    circle(c, 13, -37, 3, '#f0c58a');
    rect(c, -4, -42, 18, 6, '#b5e8df', 2, '#426c6a', 1.1);
    rect(c, -2, -41, 3, 3, '#294f55', 1); rect(c, 8, -41, 3, 3, '#294f55', 1);
    line(c, 3, -39, 7, -39, '#436a66', 1);
    line(c, 7, -32, 11, -32, '#8a5b41', 1.2);
    c.beginPath(); c.arc(0, -46, 15, Math.PI, 0); c.lineTo(15, -43); c.lineTo(-15, -43); c.closePath();
    const hat = c.createLinearGradient(0, -60, 0, -41); hat.addColorStop(0, '#ffe9a4'); hat.addColorStop(.5, '#ffcc5e'); hat.addColorStop(1, '#d69b39');
    c.fillStyle = hat; c.fill(); c.strokeStyle = '#775c32'; c.lineWidth = 1.3; c.stroke();
    rect(c, -18, -45, 38, 5, '#ffd76d', 2, '#9e7439', 1);
    line(c, -1, -58, -1, -47, '#fff3c2', 3);
    rect(c, 5, -53, 5, 5, '#6e966f', 1); line(c, 7, -52, 7, -49, '#ecedbc');
    c.restore();
  }

  particles(particles) {
    const c = this.ctx;
    for (const p of particles) {
      c.globalAlpha = Math.max(0, Math.min(1, p.life / (p.maxLife || 1)));
      const size = p.size || 3;
      if (size > 3.5) {
        c.save(); c.translate(p.x, p.y); c.rotate((p.life || 0) * 4);
        rect(c, -size / 2, -size / 2, size, size, p.color || '#ffe4a3', 1);
        c.restore();
      } else circle(c, p.x, p.y, size, p.color || '#baffdf');
    }
    c.globalAlpha = 1;
  }

  foreground(game, t) {
    const c = this.ctx, w = this.width, h = this.height;
    // Cinematic peripheral falloff leaves the actual game bright and crisp.
    const vignette = c.createRadialGradient(w * .53, h * .48, Math.min(w, h) * .23, w * .53, h * .48, Math.max(w, h) * .69);
    vignette.addColorStop(0, 'rgba(3,16,24,0)'); vignette.addColorStop(1, 'rgba(3,16,24,.6)');
    c.fillStyle = vignette; c.fillRect(0, 0, w, h);
    const bottom = c.createLinearGradient(0, h - 70, 0, h);
    bottom.addColorStop(0, 'rgba(2,19,25,0)'); bottom.addColorStop(1, 'rgba(2,19,25,.25)');
    c.fillStyle = bottom; c.fillRect(0, h - 70, w, 70);
  }
}

export default Renderer;
