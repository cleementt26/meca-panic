export const guests = [
  {
    id: 'couple',
    name: 'Prof. Couple',
    role: 'Mécanique • option soupir',
    color: '#ffb96b',
    lines: [
      'Dans ce couple, au moins une force est réciproque.',
      'Si ça bouge : mécanique. Si ça ne bouge pas : sujet de partiel.',
      'SolidWorks a planté ? Excellent. Tu viens de simuler la vraie vie.',
      'La tolérance, c’est ±0,01 mm sur la pièce. Zéro sur le retard.',
      'Un bon ingénieur vérifie ses unités. Un grand ingénieur retrouve son fichier.'
    ]
  },
  {
    id: 'pid',
    name: 'Dr. PID',
    role: 'Robot d’asservissement • émotion instable',
    color: '#80e5ee',
    lines: [
      'J’ai réglé mon anxiété en PID. Maintenant, je dépasse aussi mes objectifs.',
      'MATLAB : une licence entière pour découvrir qu’il manque un point-virgule.',
      'Mon diagramme de Bode ressemble à mon moral : ça descend avec la fréquence.',
      'Le terme intégral accumule les erreurs. Comme ton groupe de projet.',
      'Le dépassement est maîtrisé. C’est la deadline qui ne l’est pas.'
    ]
  },
  {
    id: 'iso',
    name: 'Madame ISO',
    role: 'Normes & marges • certifiée conforme',
    color: '#bcb0ff',
    lines: [
      'Votre prototype fonctionne. Hélas, la marge gauche fait 2,4 cm.',
      'La créativité est autorisée. Veuillez remplir le formulaire C-17.',
      'Tu as sauvé le monde ? Très bien. Où est l’annexe qui le prouve ?',
      'Les tolérances sont larges. Sauf pour la police du rapport.',
      'ISO 9001 : écrire ce qu’on fait. Puis expliquer pourquoi on n’a pas dormi.'
    ]
  },
  {
    id: 'stagiaire',
    name: 'Le stagiaire',
    role: 'Expert en tout • depuis mardi',
    color: '#a9ef96',
    lines: [
      'On m’a confié la mécatronique. Je pensais que c’était le mot de passe Wi-Fi.',
      'Projet de groupe : cinq noms sur la couverture, une personne sur le fichier.',
      'J’ai nommé mon fichier final_FINAL_v12. C’est une stratégie de versionnage.',
      'Mon tuteur dit “c’est simple”. J’ai donc prévu trois semaines.',
      'Le café est un composant structurel de mon diplôme.'
    ]
  },
  {
    id: 'linkedin',
    name: 'Kevin Synergie',
    role: 'Chief Bullshit Officer',
    color: '#ffca6c',
    lines: [
      'Je ne construis rien mais je fédère. C’est écrit dans mon titre LinkedIn.',
      'Notre levier ? Activer les leviers. Le prototype viendra dans le prochain pivot.',
      'L’intrapreneuriat exigeant, c’est entrepreneuriat sans argent et exigeant sans salaire.',
      'J’ai transformé vos trois semaines de travail en un post LinkedIn. Quel impact !',
      'On manque de pièces, mais la synergie est parfaitement approvisionnée.',
      'La transformation avance. On a renommé le dossier “Transformation”.',
      'Tu as fait une machine qui fonctionne ? Attention : tu n’as pas aligné les parties prenantes.',
      'Le bullshit est scalable. Ton moteur, lui, a besoin de boulons.',
      'Aujourd’hui, j’ai activé les leviers d’un intrapreneuriat exigeant. En vrai, j’ai renommé trois slides. #Gratitude #Impact',
      'Notre vision 360° ? Tourner en rond. Notre quick win ? Changer la couleur du PowerPoint.',
      'On va challenger ton mindset et embarquer les stakeholders. Ou, en français : encore une réunion.'
    ]
  },
  {
    id: 'jury',
    name: 'Le jury',
    role: 'Soutenance • difficulté légendaire',
    color: '#ff8fa7',
    lines: [
      'Votre machine marche. Mais avez-vous envisagé de faire autrement ?',
      'Vous avez dix minutes. Ma première question en prendra douze.',
      'Très belle démonstration. Pouvez-vous la refaire sans la chance ?',
      'Le budget est dépassé. C’est donc un projet industriel très réaliste.',
      'Nous avons lu votre rapport. Enfin, sa mise en page. Félicitations.'
    ]
  }
];

export const levelCopy = [
  {
    name: 'L’ATELIER DU CHAOS',
    subtitle: 'Mécanique appliquée • café obligatoire',
    brief: 'Récupère les boulons et les modules. Évite les prototypes qui ont obtenu “presque conforme”.',
    completion: 'Assemblage validé ! Il ne reste qu’une vis sur l’établi. On dira que c’est une optimisation.'
  },
  {
    name: 'LE LABO D’ASSERVISSEMENT',
    subtitle: 'Le système est stable. Toi, moins.',
    brief: 'Saute entre les plateformes et dompte les robots. Le double saut est ton seul dépassement autorisé.',
    completion: 'Boucle fermée ! Le robot suit la consigne. Le groupe de projet, toujours pas.'
  },
  {
    name: 'PIVOTLAND',
    subtitle: 'Management • bullshit à valeur ajoutée',
    brief: 'Collecte 3 preuves de travail réel pour sortir du bullshit. Méfie-toi des leviers, des synergies et des posts LinkedIn.',
    completion: 'IMPACT CONCRET ! Trois preuves de travail réel. Kevin propose quand même un atelier d’alignement.'
  },
  {
    name: 'LA SOUTENANCE FINALE',
    subtitle: 'Boss final : « une petite question »',
    brief: 'Livre ton prototype au jury. Traverse les normes, garde ton café et n’avoue jamais que ça marchait hier.',
    completion: 'DIPLÔME DÉBLOQUÉ ! Tu sais sauter, bricoler et justifier un retard. La formation est complète.'
  }
];
