export const guests = [
  {
    id: 'couple',
    name: 'Prof. Couple',
    role: 'Mécanique • option soupir',
    color: '#ffb96b',
    lines: [
      'Dans ce couple, au moins une force est réciproque.',
      'Si ça bouge : mécanique. Si ça ne bouge pas : sujet de partiel.',
      'SolidWorks a planté ? Excellent. Tu viens de simuler la vraie vie.',
      'La tolérance, c’est ±0,01 mm sur la pièce. Zéro sur le retard.',
      'Un bon ingénieur vérifie ses unités. Un grand ingénieur retrouve son fichier.'
    ]
  },
  {
    id: 'pid',
    name: 'Dr. PID',
    role: 'Robot d’asservissement • émotion instable',
    color: '#80e5ee',
    lines: [
      'J’ai réglé mon anxiété en PID. Maintenant, je dépasse aussi mes objectifs.',
      'MATLAB : une licence entière pour découvrir qu’il manque un point-virgule.',
      'Mon diagramme de Bode ressemble à mon moral : ça descend avec la fréquence.',
      'Le terme intégral accumule les erreurs. Comme ton groupe de projet.',
      'Le dépassement est maîtrisé. C’est la deadline qui ne l’est pas.'
    ]
  },
  {
    id: 'arduino',
    name: 'Maître Arduino',
    role: 'Électronique • dompteur de faux contacts',
    color: '#71f4cf',
    lines: [
      'Trois heures de debug. Le câble USB ne transférait que mon désespoir.',
      'Avant de refaire le code, relie la masse. C’est aussi valable pour ton équipe.',
      'L’oscilloscope ne ment pas. Il dessine juste ton humiliation en temps réel.',
      'Tu as inversé le plus et le moins. La fumée confirme ton sens de l’innovation.',
      'Ce bouton rebondit plus que ton professeur sur une question de partiel.',
      'Serial.println : transformer une panne obscure en 4 000 lignes obscures.',
      'Une résistance pull-up, c’est un bouton qui a besoin d’encouragement.',
      'La breadboard est sans soudure. Ton raisonnement aussi, apparemment.'
    ]
  },
  {
    id: 'iso',
    name: 'Madame ISO',
    role: 'Normes & marges • certifiée conforme',
    color: '#bcb0ff',
    lines: [
      'Votre prototype fonctionne. Hélas, la marge gauche fait 2,4 cm.',
      'La créativité est autorisée. Veuillez remplir le formulaire C-17.',
      'Tu as sauvé le monde ? Très bien. Où est l’annexe qui le prouve ?',
      'Les tolérances sont larges. Sauf pour la police du rapport.',
      'ISO 9001 : écrire ce qu’on fait. Puis expliquer pourquoi on n’a pas dormi.'
    ]
  },
  {
    id: 'stagiaire',
    name: 'Le stagiaire',
    role: 'Expert en tout • depuis mardi',
    color: '#a9ef96',
    lines: [
      'On m’a confié la mécatronique. Je pensais que c’était le mot de passe Wi-Fi.',
      'Projet de groupe : cinq noms sur la couverture, une personne sur le fichier.',
      'J’ai nommé mon fichier final_FINAL_v12. C’est une stratégie de versionnage.',
      'Mon tuteur dit “c’est simple”. J’ai donc prévu trois semaines.',
      'Le café est un composant structurel de mon diplôme.'
    ]
  },
  {
    id: 'linkedin',
    name: 'Kevin Synergie',
    role: 'Chief Bullshit Officer',
    color: '#ffca6c',
    lines: [
      'Je ne construis rien mais je fédère. C’est écrit dans mon titre LinkedIn.',
      'Notre levier ? Activer les leviers. Le prototype viendra dans le prochain pivot.',
      'L’intrapreneuriat exigeant, c’est entrepreneuriat sans argent et exigeant sans salaire.',
      'J’ai transformé vos trois semaines de travail en un post LinkedIn. Quel impact !',
      'On manque de pièces, mais la synergie est parfaitement approvisionnée.',
      'La transformation avance. On a renommé le dossier “Transformation”.',
      'Tu as fait une machine qui fonctionne ? Attention : tu n’as pas aligné les parties prenantes.',
      'Le bullshit est scalable. Ton moteur, lui, a besoin de boulons.',
      'Aujourd’hui, j’ai activé les leviers d’un intrapreneuriat exigeant. En vrai, j’ai renommé trois slides. #Gratitude #Impact',
      'Notre vision 360° ? Tourner en rond. Notre quick win ? Changer la couleur du PowerPoint.',
      'On va challenger ton mindset et embarquer les stakeholders. Ou, en français : encore une réunion.'
    ]
  },
  {
    id: 'coach',
    name: 'Coach Pivot',
    role: 'Pitch & PowerPoint • prototype optionnel',
    color: '#ed9bff',
    lines: [
      'Ton moteur tourne ? Bien. Mais peut-il tenir dans une slide ?',
      'Un prototype raté, c’est une panne. Deux prototypes ratés, c’est une roadmap.',
      'Pas de clients ? Parfait : personne ne contredit ton étude de marché.',
      'La preuve de concept est solide. Mets-la en police 48 : le jury ne vérifie pas à cette taille.',
      'On a pivoté de la mécatronique vers le conseil. Les pièces étaient trop concrètes.',
      'Il manque un roulement ? Remplace-le par un camembert. Les deux sont circulaires.',
      'Pitch en 30 secondes : 25 pour la vision, 5 pour changer le câble HDMI.',
      'J’appelle ça du storytelling. Ton binôme appelle ça mentir sur l’avancement.'
    ]
  },
  {
    id: 'jury',
    name: 'Le jury',
    role: 'Soutenance • difficulté légendaire',
    color: '#ff8fa7',
    lines: [
      'Votre machine marche. Mais avez-vous envisagé de faire autrement ?',
      'Vous avez dix minutes. Ma première question en prendra douze.',
      'Très belle démonstration. Pouvez-vous la refaire sans la chance ?',
      'Le budget est dépassé. C’est donc un projet industriel très réaliste.',
      'Nous avons lu votre rapport. Enfin, sa mise en page. Félicitations.'
    ]
  }
];

export const levelCopy = [
  {
    name: 'L’ATELIER DU CHAOS',
    subtitle: 'Mécanique appliquée • café obligatoire',
    universe: 'Fonderie mécanique au coucher du soleil',
    motif: 'Convoyeurs, presses et copeaux',
    goal: 'Assembler le prototype',
    guestIds: ['couple', 'stagiaire'],
    brief: 'Traverse les convoyeurs de l’atelier et récupère les modules du prototype. Attention aux machines “presque conformes”.',
    completion: 'ASSEMBLAGE VALIDÉ ! Tu as survécu aux convoyeurs. La vis en trop ? Une marge de sécurité.'
  },
  {
    name: 'LA TOUR D’ASSERVISSEMENT',
    subtitle: 'Le système est stable. Toi, moins.',
    universe: 'Tour électronique illuminée de signaux',
    motif: 'Ascenseurs, circuits et robots',
    goal: 'Fermer la boucle de contrôle',
    guestIds: ['pid', 'arduino'],
    brief: 'Grimpe la tour par ses ascenseurs, récupère les modules et évite les robots de contrôle. Ton dépassement doit rester vertical.',
    completion: 'BOUCLE FERMÉE ! La tour est sous contrôle. Le robot suit la consigne. Le groupe de projet, toujours pas.'
  },
  {
    name: 'PIVOTLAND',
    subtitle: 'Management • bullshit à valeur ajoutée',
    universe: 'Campus du management et de la transformation',
    motif: 'Réunions, slides et plateformes de pitch',
    goal: 'Collecter 3 preuves de travail réel',
    guestIds: ['linkedin', 'coach'],
    brief: 'Saute entre les plateformes de réunion et collecte 3 preuves de travail réel pour sortir du bullshit. La synergie ne remplace pas les boulons.',
    completion: 'IMPACT CONCRET ! Trois preuves, zéro PowerPoint. Kevin veut un post LinkedIn. Coach Pivot réclame les droits du pitch.'
  },
  {
    name: 'LA SOUTENANCE FINALE',
    subtitle: 'Boss final : « une petite question »',
    universe: 'Bibliothèque suspendue et terrasses du jury',
    motif: 'Livres, normes et dernière soutenance',
    goal: 'Livrer le prototype au jury',
    guestIds: ['iso', 'jury'],
    brief: 'Traverse les bibliothèques et leurs terrasses pour livrer ton prototype au jury. Garde ton café et respecte les marges, même dans le vide.',
    completion: 'DIPLÔME DÉBLOQUÉ ! Atelier, contrôle, bullshit, soutenance : quatre mondes traversés. Tu peux maintenant expliquer pourquoi ça marchait hier.'
  }
];
