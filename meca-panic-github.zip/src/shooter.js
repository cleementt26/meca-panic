const W = 1000;
const H = 650;
const TAU = Math.PI * 2;
const clamp = (value, min, max) => Math.max(min, Math.min(max, value));
const distance2 = (a, b) => (a.x - b.x) ** 2 + (a.y - b.y) ** 2;

/** A short maintenance-drone shoot-em-up inside an aircraft transmission. */
export class WorkshopShooter {
  constructor({ sound, onComplete } = {}) {
    this.sound = sound;
    this.onComplete = onComplete;
    this.reset();
  }

  reset() {
    this._health = 3;
    this._kills = 0;
    this._cores = 0;
    this._score = 0;
    this._elapsed = 0;
    this._done = null;
    this._player = { x: 180, y: 350, r: 19, invulnerable: 1.6 };
    this._shots = [];
    this._foeShots = [];
    this._enemies = [];
    this._particles = [];
    this._spawnedCores = 0;
    this._nextWave = 2;
    this._wave = 0;
    this._shotCooldown = 0;
    this._shake = 0;
    this._id = 0;
    this._coreFlash = 0;
    return this;
  }

  get health() { return this._health; }
  get kills() { return this._kills; }
  get cores() { return this._cores; }
  get score() { return this._score; }
  get elapsed() { return this._elapsed; }
  get projectiles() { return [...this._shots, ...this._foeShots]; }
  get enemies() { return this._enemies; }
  get player() { return this._player; }
  get done() { return this._done; }

  _cue(name) { this.sound?.cue?.(name); }

  _finish(result) {
    if (this._done) return null;
    this._done = result;
    if (result === 'won') this._cue('win');
    if (typeof this.onComplete === 'function') this.onComplete(result);
    return result;
  }

  _spawn(type, y, coreIndex = -1) {
    const boss = type === 'servo';
    const maxHp = boss ? 8 + coreIndex : 2;
    this._enemies.push({
      id: ++this._id, type, x: W + 75, y, baseY: y,
      r: boss ? 48 : 23, hp: maxHp, maxHp,
      age: 0, coreIndex, fireTimer: boss ? 2.7 : 3.4,
      windup: 0, aim: Math.PI, hit: 0,
      phase: coreIndex * 1.6 + this._wave * 0.7
    });
  }

  _burst(x, y, color, count = 12) {
    for (let i = 0; i < count; i++) {
      const angle = Math.random() * TAU;
      const speed = 50 + Math.random() * 190;
      this._particles.push({ x, y, vx: Math.cos(angle) * speed, vy: Math.sin(angle) * speed,
        ttl: 0.3 + Math.random() * 0.55, life: 0.85, color, size: 1 + Math.random() * 3 });
    }
    if (this._particles.length > 220) this._particles.splice(0, this._particles.length - 220);
  }

  _fireEnemy(enemy) {
    const spread = enemy.type === 'servo' ? [-0.17, 0, 0.17] : [0];
    for (const offset of spread) {
      const angle = enemy.aim + offset;
      const speed = enemy.type === 'servo' ? 205 : 225;
      this._foeShots.push({ x: enemy.x - enemy.r, y: enemy.y,
        vx: Math.cos(angle) * speed, vy: Math.sin(angle) * speed,
        r: 7, age: 0, hostile: true });
    }
  }

  update(dt, input = {}) {
    if (this._done) return null;
    dt = clamp(Number(dt) || 0, 0, 0.05);
    if (!dt) return null;
    this._elapsed += dt;
    this._shake = Math.max(0, this._shake - dt * 22);
    this._coreFlash = Math.max(0, this._coreFlash - dt);
    const player = this._player;
    player.invulnerable = Math.max(0, player.invulnerable - dt);
    let dx = Number(Boolean(input.right)) - Number(Boolean(input.left));
    let dy = Number(Boolean(input.down)) - Number(Boolean(input.up));
    if (dx && dy) { dx *= Math.SQRT1_2; dy *= Math.SQRT1_2; }
    player.x = clamp(player.x + dx * 340 * dt, 65, 480);
    player.y = clamp(player.y + dy * 340 * dt, 175, 573);
    this._shotCooldown -= dt;
    if (input.shoot && this._shotCooldown <= 0) {
      this._shotCooldown = 0.17;
      this._shots.push({ x: player.x + 42, y: player.y, vx: 730, vy: 0, r: 6, age: 0, hostile: false });
      // One sound per burst avoids overwhelming the music or spawning excess voices.
      if ((Math.floor(this._elapsed / 0.17) % 3) === 0) this._cue('bolt');
    }

    const coreTimes = [9, 20, 31];
    const coreHeights = [220, 365, 510];
    while (this._spawnedCores < 3 && this._elapsed >= coreTimes[this._spawnedCores]) {
      this._spawn('servo', coreHeights[this._spawnedCores], this._spawnedCores);
      ++this._spawnedCores;
      this._coreFlash = 1.8;
    }
    if (this._elapsed >= this._nextWave && this._elapsed < 37) {
      const lane = [270, 490, 350, 205, 550, 410][this._wave % 6];
      this._spawn('bot', lane);
      this._wave++;
      this._nextWave += 2.8;
    }

    for (const enemy of this._enemies) {
      enemy.age += dt;
      enemy.hit = Math.max(0, enemy.hit - dt);
      enemy.x -= dt * (enemy.type === 'servo' ? (enemy.x > 840 ? 105 : 0) : 104);
      enemy.y = enemy.baseY + Math.sin(enemy.age * (enemy.type === 'servo' ? 1.5 : 2) + enemy.phase)
        * (enemy.type === 'servo' ? 25 : 18);
      if (enemy.x < W - 15) {
        if (enemy.windup > 0) {
          enemy.windup -= dt;
          if (enemy.windup <= 0) {
            this._fireEnemy(enemy);
            enemy.fireTimer = enemy.type === 'servo' ? 3.1 : 4.2;
          }
        } else {
          enemy.fireTimer -= dt;
          if (enemy.fireTimer <= 0 && enemy.x > player.x + 90) {
            enemy.aim = Math.atan2(player.y - enemy.y, player.x - enemy.x);
            enemy.windup = 0.95;
          }
        }
      }
    }
    for (const shot of [...this._shots, ...this._foeShots]) {
      shot.x += shot.vx * dt;
      shot.y += shot.vy * dt;
      shot.age += dt;
    }
    for (const shot of this._shots) {
      if (shot.dead) continue;
      for (const enemy of this._enemies) {
        if (enemy.hp <= 0 || distance2(shot, enemy) > (shot.r + enemy.r) ** 2) continue;
        shot.dead = true;
        enemy.hp--;
        enemy.hit = 0.13;
        this._burst(shot.x, shot.y, '#80fff1', 4);
        if (enemy.hp <= 0) {
          ++this._kills;
          this._score += enemy.type === 'servo' ? 600 : 100;
          this._burst(enemy.x, enemy.y, enemy.type === 'servo' ? '#ffba73' : '#80fff1', 30);
          this._shake = enemy.type === 'servo' ? 6 : 2;
          this._cue(enemy.type === 'servo' ? 'module' : 'stomp');
          if (enemy.type === 'servo') {
            ++this._cores;
            this._coreFlash = 1.2;
          }
        }
        break;
      }
    }
    if (!player.invulnerable) {
      const bullet = this._foeShots.find(shot => !shot.dead && distance2(shot, player) < (shot.r + player.r) ** 2);
      const collision = this._enemies.find(enemy => enemy.hp > 0 && distance2(enemy, player) < (enemy.r + player.r - 4) ** 2);
      if (bullet || collision) {
        if (bullet) bullet.dead = true;
        this._health--;
        player.invulnerable = 1.9;
        this._shake = 9;
        this._burst(player.x, player.y, '#ff8870', 24);
        this._cue('hit');
        // A hit clears nearby projectiles so an unlucky cluster cannot remove two lives.
        for (const shot of this._foeShots) if (distance2(shot, player) < 130 ** 2) shot.dead = true;
        if (this._health <= 0) return this._finish('lost');
      }
    }
    this._shots = this._shots.filter(shot => !shot.dead && shot.x < W + 60 && shot.age < 2);
    this._foeShots = this._foeShots.filter(shot => !shot.dead && shot.x > -40 && shot.x < W + 80
      && shot.y > 155 && shot.y < 610 && shot.age < 6);
    this._enemies = this._enemies.filter(enemy => enemy.hp > 0 && enemy.x > -100);
    for (const particle of this._particles) {
      particle.x += particle.vx * dt;
      particle.y += particle.vy * dt;
      particle.vy += 85 * dt;
      particle.ttl -= dt;
    }
    this._particles = this._particles.filter(particle => particle.ttl > 0);
    if (this._cores === 3 && this._elapsed >= 35) return this._finish('won');
    return null;
  }

  _gear(ctx, x, y, radius, angle, color, teeth = 14) {
    ctx.save(); ctx.translate(x, y); ctx.rotate(angle);
    ctx.beginPath();
    for (let i = 0; i < teeth * 4; i++) {
      const a = i / (teeth * 4) * TAU;
      const r = radius * (i % 4 < 2 ? 1 : 0.84);
      const px = Math.cos(a) * r, py = Math.sin(a) * r;
      if (i === 0) ctx.moveTo(px, py); else ctx.lineTo(px, py);
    }
    ctx.closePath(); ctx.fillStyle = color; ctx.fill();
    ctx.strokeStyle = 'rgba(209,237,237,.2)'; ctx.lineWidth = 1.5; ctx.stroke();
    ctx.beginPath(); ctx.arc(0, 0, radius * 0.62, 0, TAU);
    ctx.fillStyle = '#071c23'; ctx.fill(); ctx.stroke();
    ctx.beginPath(); ctx.arc(0, 0, radius * 0.18, 0, TAU);
    ctx.fillStyle = '#638082'; ctx.fill();
    for (let i = 0; i < 5; i++) {
      const a = i / 5 * TAU;
      ctx.beginPath(); ctx.arc(Math.cos(a) * radius * 0.4, Math.sin(a) * radius * 0.4, radius * 0.045, 0, TAU);
      ctx.fillStyle = '#a8c3bd'; ctx.fill();
    }
    ctx.restore();
  }

  _background(ctx, time) {
    const gradient = ctx.createLinearGradient(0, 0, W, H);
    gradient.addColorStop(0, '#071921'); gradient.addColorStop(0.55, '#12333a'); gradient.addColorStop(1, '#102128');
    ctx.fillStyle = gradient; ctx.fillRect(0, 0, W, H);
    const scroll = (this._elapsed * 34) % 220;
    ctx.lineWidth = 1;
    ctx.strokeStyle = 'rgba(98,215,199,.09)';
    for (let x = -scroll; x < W; x += 44) { ctx.beginPath(); ctx.moveTo(x, 155); ctx.lineTo(x, 604); ctx.stroke(); }
    for (let y = 170; y < 610; y += 44) { ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(W, y); ctx.stroke(); }
    for (let x = -scroll - 40; x < W + 220; x += 220) {
      ctx.strokeStyle = '#315257'; ctx.lineWidth = 12;
      ctx.beginPath(); ctx.moveTo(x, 155); ctx.bezierCurveTo(x + 32, 235, x + 32, 518, x, 608); ctx.stroke();
      ctx.strokeStyle = 'rgba(113,162,157,.2)'; ctx.lineWidth = 2;
      ctx.beginPath(); ctx.moveTo(x - 2, 155); ctx.bezierCurveTo(x + 23, 245, x + 23, 510, x - 2, 608); ctx.stroke();
      for (const y of [178, 228, 542, 585]) {
        ctx.fillStyle = '#709391'; ctx.beginPath(); ctx.arc(x + 10, y, 3, 0, TAU); ctx.fill();
      }
    }
    ctx.globalAlpha = 0.65;
    this._gear(ctx, 770 - scroll, 208, 90, -time * 0.42, '#254449');
    this._gear(ctx, 954 - scroll, 538, 108, time * 0.34, '#3d4e43');
    this._gear(ctx, 238 - scroll, 560, 66, time * 0.7, '#24454c');
    ctx.globalAlpha = 1;
    // Copper buses, translucent inspection windows and ribbed drive shafts.
    for (const y of [165, 595]) {
      ctx.fillStyle = '#071b20'; ctx.fillRect(0, y - 9, W, 20);
      ctx.strokeStyle = '#a16e45'; ctx.lineWidth = 3;
      ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(W, y); ctx.stroke();
      ctx.strokeStyle = 'rgba(255,196,129,.25)'; ctx.lineWidth = 1;
      ctx.beginPath(); ctx.moveTo(0, y - 3); ctx.lineTo(W, y - 3); ctx.stroke();
      for (let x = 12 - scroll % 40; x < W; x += 40) {
        ctx.fillStyle = '#668685'; ctx.fillRect(x, y - 5, 6, 10);
      }
    }
    ctx.fillStyle = 'rgba(12,27,31,.9)'; ctx.fillRect(0, 0, W, 153); ctx.fillRect(0, 610, W, 40);
    ctx.strokeStyle = '#426063'; ctx.lineWidth = 2;
    ctx.beginPath(); ctx.moveTo(0, 153); ctx.lineTo(W, 153); ctx.moveTo(0, 610); ctx.lineTo(W, 610); ctx.stroke();
    ctx.fillStyle = 'rgba(141,194,181,.4)'; ctx.font = '10px monospace';
    ctx.fillText('COUPE TECHNIQUE / TRANSMISSION AÉRONAUTIQUE / ACCÈS MAINTENANCE', 28, 630);
  }

  _drawPlayer(ctx, time) {
    const p = this._player;
    if (p.invulnerable > 0 && Math.floor(time * 14) % 3 === 0) ctx.globalAlpha = 0.42;
    ctx.save(); ctx.translate(p.x, p.y);
    // Maintenance cradle: exposed copper coil and a glass cabin with an engineer.
    const flame = 13 + Math.sin(time * 37) * 5;
    ctx.shadowColor = '#86f5e1'; ctx.shadowBlur = 18;
    ctx.fillStyle = '#8bf5df'; ctx.beginPath(); ctx.moveTo(-32, -9); ctx.lineTo(-32 - flame, 0); ctx.lineTo(-32, 9); ctx.fill();
    ctx.shadowBlur = 0;
    ctx.fillStyle = '#173e48'; ctx.fillRect(-34, -17, 46, 34);
    ctx.strokeStyle = '#b68d5c'; ctx.lineWidth = 3;
    for (let x = -28; x < 3; x += 7) { ctx.beginPath(); ctx.moveTo(x, -15); ctx.lineTo(x, 15); ctx.stroke(); }
    ctx.fillStyle = '#9ab5ae'; ctx.fillRect(-24, 17, 58, 5);
    ctx.fillStyle = '#315760'; ctx.fillRect(-18, -22, 48, 6);
    ctx.beginPath(); ctx.ellipse(7, -2, 28, 23, 0, 0, TAU);
    const glass = ctx.createLinearGradient(-14, -21, 24, 15); glass.addColorStop(0, '#70cfc9'); glass.addColorStop(1, '#173b49');
    ctx.fillStyle = glass; ctx.fill(); ctx.strokeStyle = '#95ddd0'; ctx.lineWidth = 2; ctx.stroke();
    ctx.fillStyle = '#efbc87'; ctx.beginPath(); ctx.arc(9, -5, 9, 0, TAU); ctx.fill();
    ctx.fillStyle = '#ffbd58'; ctx.beginPath(); ctx.arc(9, -9, 11, Math.PI, 0); ctx.fill(); ctx.fillRect(-3, -10, 25, 4);
    ctx.fillStyle = '#152831'; ctx.fillRect(14, -5, 3, 3);
    ctx.fillStyle = '#e66f47'; ctx.fillRect(-2, 6, 21, 12);
    ctx.strokeStyle = 'rgba(215,255,246,.5)'; ctx.lineWidth = 2;
    ctx.beginPath(); ctx.arc(4, -3, 19, Math.PI * 1.1, Math.PI * 1.6); ctx.stroke();
    ctx.fillStyle = '#bbd2bd'; ctx.fillRect(26, -5, 23, 10);
    ctx.fillStyle = '#4d7379'; ctx.fillRect(40, -8, 9, 16);
    if (this._shotCooldown > 0.11) { ctx.shadowColor = '#adfff0'; ctx.shadowBlur = 20; ctx.fillStyle = '#c8fff2'; ctx.beginPath(); ctx.arc(51, 0, 6, 0, TAU); ctx.fill(); }
    ctx.restore(); ctx.globalAlpha = 1;
  }

  _drawEnemy(ctx, enemy, time) {
    const boss = enemy.type === 'servo';
    if (enemy.windup > 0) {
      const endX = enemy.x + Math.cos(enemy.aim) * 1100;
      const endY = enemy.y + Math.sin(enemy.aim) * 1100;
      ctx.save(); ctx.strokeStyle = `rgba(255,131,91,${0.13 + (1 - enemy.windup / 0.95) * 0.22})`;
      ctx.lineWidth = 1.5; ctx.setLineDash([8, 12]);
      ctx.beginPath(); ctx.moveTo(enemy.x - enemy.r, enemy.y); ctx.lineTo(endX, endY); ctx.stroke(); ctx.restore();
    }
    ctx.save(); ctx.translate(enemy.x, enemy.y);
    this._gear(ctx, 0, 0, enemy.r + 9, time * (boss ? 1 : -2) + enemy.phase, enemy.hit > 0 ? '#acfff1' : boss ? '#9c6f42' : '#37545a', boss ? 16 : 10);
    ctx.shadowColor = enemy.windup > 0 ? '#ff6f53' : '#ffb867'; ctx.shadowBlur = boss ? 24 : 8;
    ctx.fillStyle = enemy.windup > 0 ? '#ff745a' : '#eaa770';
    ctx.beginPath(); ctx.arc(0, 0, boss ? 24 : 11, 0, TAU); ctx.fill(); ctx.shadowBlur = 0;
    ctx.fillStyle = '#1e2d2e'; ctx.fillRect(-12, -6, 24, 12);
    ctx.fillStyle = enemy.hit > 0 ? '#eaffff' : '#ffe6ab'; ctx.fillRect(-10, -3, 7, 6); ctx.fillRect(3, -3, 7, 6);
    ctx.strokeStyle = '#adc0aa'; ctx.lineWidth = boss ? 5 : 3;
    ctx.beginPath(); ctx.moveTo(-enemy.r + 12, 0); ctx.lineTo(-enemy.r - 15, 0); ctx.stroke();
    if (boss) {
      ctx.strokeStyle = '#ffb971'; ctx.lineWidth = 2;
      ctx.beginPath(); ctx.arc(0, 0, 62 + Math.sin(time * 4) * 2, 0, TAU); ctx.stroke();
      ctx.fillStyle = '#061c23'; ctx.fillRect(-45, -82, 90, 6);
      ctx.fillStyle = '#ffba73'; ctx.fillRect(-45, -82, 90 * enemy.hp / enemy.maxHp, 6);
      ctx.font = 'bold 11px monospace'; ctx.textAlign = 'center'; ctx.fillStyle = '#ffddaa';
      ctx.fillText(`SERVO ${enemy.coreIndex + 1} / 3`, 0, -92);
    }
    ctx.restore();
  }

  render(canvas, time = this._elapsed) {
    const ctx = canvas.getContext('2d');
    if (!ctx || !canvas.width || !canvas.height) return;
    const scale = Math.min(canvas.width / W, canvas.height / H);
    const offsetX = (canvas.width - W * scale) / 2;
    const offsetY = (canvas.height - H * scale) / 2;
    ctx.save(); ctx.setTransform(1, 0, 0, 1, 0, 0); ctx.fillStyle = '#06181e'; ctx.fillRect(0, 0, canvas.width, canvas.height);
    ctx.translate(offsetX, offsetY); ctx.scale(scale, scale);
    this._background(ctx, time);
    ctx.save(); ctx.beginPath(); ctx.rect(0, 155, W, 452); ctx.clip();
    if (this._shake > 0) ctx.translate(Math.sin(time * 93) * this._shake, Math.cos(time * 79) * this._shake * 0.6);
    for (const enemy of this._enemies) this._drawEnemy(ctx, enemy, time);
    for (const shot of this._shots) {
      ctx.shadowBlur = 15; ctx.shadowColor = '#98fff2'; ctx.strokeStyle = '#b6fff2'; ctx.lineWidth = 4;
      ctx.beginPath(); ctx.moveTo(shot.x - 20, shot.y); ctx.lineTo(shot.x + 5, shot.y); ctx.stroke();
    }
    for (const shot of this._foeShots) {
      ctx.shadowColor = '#ff8c60'; ctx.shadowBlur = 12; ctx.fillStyle = '#ffd6a0';
      ctx.beginPath(); ctx.arc(shot.x, shot.y, shot.r, 0, TAU); ctx.fill();
    }
    ctx.shadowBlur = 0;
    this._drawPlayer(ctx, time);
    for (const particle of this._particles) {
      ctx.globalAlpha = Math.min(1, particle.ttl * 2); ctx.strokeStyle = particle.color; ctx.lineWidth = particle.size;
      ctx.beginPath(); ctx.moveTo(particle.x, particle.y); ctx.lineTo(particle.x - particle.vx * 0.025, particle.y - particle.vy * 0.025); ctx.stroke();
    }
    ctx.globalAlpha = 1;
    if (this._coreFlash > 0) {
      ctx.fillStyle = `rgba(124,255,215,${this._coreFlash * 0.015})`; ctx.fillRect(0, 155, W, 450);
    }
    ctx.restore();
    // HUD sits below the app's fixed title bar, including on short viewports.
    ctx.fillStyle = '#c9f0de'; ctx.font = 'bold 17px system-ui, sans-serif';
    ctx.fillText('BANC D’ESSAI • DÉBUG AU CALIBRE', 28, 126);
    ctx.font = '11px monospace'; ctx.fillStyle = '#91afa9';
    ctx.fillText('FLÈCHES : PILOTER     ESPACE / Z / X : TIR CONTINU', 28, 146);
    ctx.textAlign = 'right'; ctx.font = 'bold 15px monospace'; ctx.fillStyle = '#ffbd7f';
    ctx.fillText(`CŒURS ${this._cores}/3   SCORE ${String(this._score).padStart(4, '0')}`, 973, 126);
    ctx.font = '12px monospace'; ctx.fillStyle = '#bfe8d5';
    ctx.fillText(`INTÉGRITÉ ${'●'.repeat(this._health)}${'○'.repeat(3 - this._health)}   ${Math.floor(this._elapsed)} s`, 973, 146);
    ctx.textAlign = 'left';
    if (this._elapsed < 5) {
      ctx.textAlign = 'center'; ctx.fillStyle = '#bfe8d5'; ctx.font = 'bold 17px system-ui';
      ctx.fillText('Neutralise les 3 cœurs servo. Les lignes orange annoncent les tirs.', W / 2, 185); ctx.textAlign = 'left';
    }
    ctx.restore();
  }
}
