import { levelCopy } from './content.js';

// Each stage is authored separately: these are routes through four places,
// rather than one platform pattern with four coats of paint.
const floor = (id, x, y, w) => ({ id, x, y, w, h: 784 - y, type: 'floor' });
const beam = (id, x, y, w, label) => ({ id, x, y, w, h: 24, type: 'beam', ...(label ? { label } : {}) });
const belt = (id, x, y, w, beltDir = 1) => ({ ...beam(id, x, y, w), type: 'conveyor', beltDir, beltSpeed: 60 });
const lift = (id, x, y, w, amplitudeY, period, phase = 0) => ({
  ...beam(id, x, y, w), type: 'moving', baseX: x, baseY: y,
  amplitudeX: 0, amplitudeY, period, phase, dx: 0, dy: 0
});
const enemy = (type, x, feet, min, max, speed, w = 44, h = 42, extra = {}) => ({
  type, x, y: feet - h, w, h, alive: true, dir: 1, min, max, speed, ...extra
});
const pit = (x, w, type = 'acid') => ({ x, y: 714, w, h: 70, type });

function workshop() {
  return {
    width: 3380, universe: 'factory',
    platforms: [
      floor('work-start', 0, 690, 650), floor('work-bay-a', 800, 690, 460),
      floor('work-bay-b', 1420, 690, 820), floor('work-out', 2400, 690, 980),
      beam('work-press-in', 280, 610, 300), belt('work-press-out', 610, 535, 310),
      beam('work-inspection', 980, 615, 250), belt('work-assembly', 1340, 610, 430, -1),
      beam('work-tooth-bay', 1810, 520, 230), belt('work-packaging', 2050, 600, 350),
      beam('work-crate', 2490, 620, 170), belt('work-last-belt', 2680, 540, 350)
    ],
    modules: [['work-press-out', 765], ['work-assembly', 1560], ['work-last-belt', 2890]],
    coffee: [['work-bay-b', 1640], ['work-packaging', 2250]],
    guests: [['couple', 220, 690], ['stagiaire', 3190, 690]],
    checkpoints: [{ x: 1460, y: 690 }, { x: 2450, y: 690 }],
    enemies: [
      enemy('gear', 565, 690, 530, 600, 66, 48, 48),
      enemy('robot', 905, 690, 850, 1040, 58),
      enemy('gear', 1930, 690, 1850, 2020, 85, 54, 54),
      enemy('robot', 2580, 690, 2540, 2670, 72),
      enemy('gear', 3080, 690, 3050, 3130, 58, 46, 46)
    ],
    hazards: [pit(650, 150), pit(1260, 160), pit(2240, 160), { x: 1860, y: 676, w: 100, h: 14, type: 'spikes' }],
    exit: { x: 3280, y: 580, w: 80, h: 110, open: false }
  };
}

function pidLab() {
  return {
    width: 3080, universe: 'cyberlab',
    platforms: [
      floor('pid-start', 0, 690, 520), floor('pid-well-a', 700, 690, 460),
      floor('pid-well-b', 1300, 690, 640), floor('pid-out', 2120, 690, 960),
      beam('pid-stair-a', 260, 610, 170), beam('pid-stair-b', 450, 525, 160),
      beam('pid-stair-c', 640, 435, 180), beam('pid-tower-a', 850, 345, 260),
      beam('pid-down-a', 1170, 435, 180), beam('pid-down-b', 1390, 525, 200),
      beam('pid-valley', 1570, 610, 230), beam('pid-stair-d', 1710, 535, 170),
      beam('pid-stair-e', 1860, 445, 170), beam('pid-stair-f', 2020, 355, 180),
      beam('pid-tower-b', 2240, 295, 260), beam('pid-down-c', 2580, 395, 180),
      beam('pid-down-d', 2770, 495, 230),
      // Elevators provide an alternate ascent; the fixed stairs are a fair
      // fallback at every phase, including after a checkpoint respawn.
      lift('pid-elevator-a', 545, 590, 100, 115, 7, 0),
      lift('pid-elevator-b', 1930, 575, 110, 140, 8, Math.PI / 2),
      beam('pid-recovery-a', 1120, 610, 160), beam('pid-recovery-b', 2180, 605, 140),
      beam('pid-recovery-c', 2330, 520, 150), beam('pid-recovery-d', 2470, 435, 130),
      beam('pid-recovery-e', 2370, 365, 130)
    ],
    modules: [['pid-tower-a', 1000], ['pid-stair-d', 1810], ['pid-tower-b', 2370]],
    coffee: [['pid-down-b', 1460], ['pid-down-c', 2700]],
    guests: [['pid', 205, 690], ['arduino', 2900, 495]],
    checkpoints: [{ x: 1000, y: 690 }, { x: 2160, y: 690 }],
    enemies: [
      enemy('drone', 775, 545, 730, 825, 75, 48, 32, { baseY: 513, bobAmp: 24, bobPeriod: 2.8 }),
      enemy('drone', 1390, 625, 1325, 1470, 88, 50, 32, { baseY: 593, bobAmp: 24, bobPeriod: 3.4 }),
      enemy('robot', 1770, 690, 1700, 1830, 92, 38, 46),
      enemy('drone', 1950, 645, 1900, 2020, 65, 52, 34, { baseY: 611, bobAmp: 35, bobPeriod: 2.3 }),
      enemy('drone', 2640, 395, 2600, 2710, 61, 46, 34, { baseY: 361, bobAmp: 8, bobPeriod: 3.6 })
    ],
    hazards: [pit(520, 180, 'electric'), pit(1160, 140, 'electric'), pit(1940, 180, 'electric')],
    exit: { x: 2980, y: 580, w: 80, h: 110, open: false }
  };
}

function pivotland() {
  return {
    width: 3540, universe: 'corporate',
    platforms: [
      floor('pivot-start', 0, 690, 480), floor('pivot-breakroom', 950, 690, 430),
      floor('pivot-coworking', 1860, 690, 360), floor('pivot-out', 2980, 690, 560),
      beam('pivot-quick-win', 310, 610, 170, 'QUICK WIN'),
      beam('pivot-levers', 540, 535, 220, 'LEVIERS'),
      // The first proof is behind the ascent: the meeting literally turns
      // back on itself. Bolts make the leftward detour legible.
      beam('pivot-alignment', 360, 450, 180, 'ALIGNEMENT'),
      beam('pivot-vision', 650, 375, 260, 'VISION 360°'),
      beam('pivot-synergy', 990, 460, 180, 'SYNERGIE'),
      beam('pivot-intrapreneur', 1230, 550, 260, 'INTRAPRENEURIAT'),
      beam('pivot-impact', 1510, 630, 170, 'IMPACT'),
      beam('pivot-scalable', 1730, 545, 190, 'SCALABLE'),
      beam('pivot-realdelivery', 1980, 460, 270, 'TRAVAIL RÉEL'),
      beam('pivot-roadmap', 2300, 540, 180, 'ROADMAP'),
      beam('pivot-feedback', 2530, 625, 150, 'FEEDBACK'),
      beam('pivot-demanding', 2720, 535, 260, 'EXIGEANT'),
      beam('pivot-pivot', 3070, 615, 200, 'PIVOT'),
      beam('pivot-recovery-a', 1120, 625, 140, 'PLAN B'),
      beam('pivot-recovery-b', 1850, 620, 130, 'RÉUNION BONUS')
    ],
    modules: [['pivot-alignment', 450], ['pivot-realdelivery', 2150], ['pivot-demanding', 2860]],
    coffee: [['pivot-intrapreneur', 1350], ['pivot-feedback', 2610]],
    guests: [['linkedin', 220, 690], ['coach', 3370, 690]],
    checkpoints: [{ x: 1260, y: 690 }, { x: 1880, y: 690 }],
    enemies: [
      enemy('buzzword', 1040, 690, 970, 1080, 64, 118, 44, { label: 'SYNERGIE' }),
      enemy('buzzword', 1640, 716, 1600, 1690, 74, 96, 42, { label: 'LEVIERS', baseY: 674, bobAmp: 13, bobPeriod: 3.2 }),
      enemy('buzzword', 2020, 690, 1995, 2040, 53, 148, 46, { label: 'INTRAPRENEURIAT' }),
      enemy('buzzword', 2320, 540, 2310, 2340, 48, 112, 42, { label: 'DISRUPTION' }),
      enemy('buzzword', 3230, 690, 3170, 3260, 69, 100, 44, { label: 'MINDSET' })
    ],
    hazards: [pit(480, 470), pit(1380, 480), pit(2220, 760)],
    exit: { x: 3435, y: 580, w: 80, h: 110, open: false }
  };
}

function finalJury() {
  return {
    width: 3380, universe: 'library',
    platforms: [
      // The last stage is a procession of solid library terraces, with a
      // high annex detour. Tall steps collide at the sides like bookcases.
      floor('jury-start', 0, 690, 420), floor('jury-books-a', 520, 610, 260),
      floor('jury-books-b', 850, 525, 370), floor('jury-forms', 1320, 610, 340),
      floor('jury-bottom', 1730, 680, 260), floor('jury-books-c', 2090, 600, 230),
      floor('jury-books-d', 2400, 515, 350), floor('jury-podium', 2860, 600, 520),
      beam('jury-annex-a', 1450, 525, 160, 'ANNEXE A'),
      beam('jury-annex-b', 1700, 440, 250, 'ANNEXE DE L’ANNEXE'),
      beam('jury-annex-c', 2030, 525, 170, 'JUSTIFICATION'),
      beam('jury-recovery', 1830, 600, 160, 'PLAN DE SOUTENANCE')
    ],
    modules: [['jury-books-b', 1080], ['jury-annex-b', 1850], ['jury-books-d', 2520]],
    coffee: [['jury-forms', 1400], ['jury-books-d', 2610]],
    guests: [['iso', 220, 690], ['jury', 3170, 600]],
    checkpoints: [{ x: 1360, y: 610 }, { x: 2150, y: 600 }],
    enemies: [
      enemy('stamp', 685, 610, 675, 725, 42, 54, 52, { label: 'NON CONFORME' }),
      enemy('stamp', 1530, 610, 1515, 1580, 59, 48, 52, { label: 'ANNEXE ?' }),
      enemy('question', 1790, 680, 1740, 1900, 68, 50, 54, { label: 'POURQUOI ?' }),
      enemy('stamp', 2250, 600, 2235, 2270, 43, 48, 52, { label: 'À REFAIRE' }),
      enemy('question', 3020, 600, 2965, 3070, 56, 60, 54, { label: 'UNE PETITE QUESTION' })
    ],
    hazards: [pit(420, 100), pit(780, 70), pit(1220, 100), pit(1660, 70), pit(1990, 100), pit(2320, 80), pit(2750, 110)],
    exit: { x: 3275, y: 490, w: 80, h: 110, open: false }
  };
}

export function makeLevel(index, guestById) {
  const build = [workshop, pidLab, pivotland, finalJury][index];
  if (!build) throw new RangeError(`Unknown stage ${index}`);
  const design = build(), pickups = [];
  const add = (x, y, type) => pickups.push({ id: `${index}-${pickups.length}`, x, y, type, collected: false });
  const surface = id => design.platforms.find(p => p.id === id);
  // Bolts describe every useful fixed ledge, including the reverse detour.
  for (const p of design.platforms.filter(p => p.type !== 'floor' && p.type !== 'moving')) {
    for (let x = p.x + 28; x <= p.x + p.w - 24; x += 58) add(x, p.y - 26, 'bolt');
  }
  for (const p of design.platforms.filter(p => p.type === 'floor')) {
    for (let x = p.x + 105; x < p.x + p.w - 55; x += 125) add(x, p.y - 26, 'bolt');
  }
  for (const [id, x] of design.modules) add(x, surface(id).y - 36, 'module');
  for (const [id, x] of design.coffee) add(x, surface(id).y - 30, 'coffee');
  const npcs = design.guests.map(([guestId, x, y]) => ({ ...guestById[guestId], guestId, x, y }));
  const { modules, coffee, guests, ...level } = design;
  return {
    ...levelCopy[index], ...level, index, height: 760, pickups, npcs,
    checkpoints: design.checkpoints.map(cp => ({ ...cp, active: false }))
  };
}

// Reviewable routes used by the deterministic physics checks. They exercise
// normal movement, the backward meeting detour, all modules and every exit.
// Exit steps keep moving until the game transitions to the next stage.
export const traversalRoutes = [
  [
    { walk: 260 }, { jump: 420 }, { walk: 520 }, { jump: 755, double: true },
    { walk: 795 }, { walk: 870 }, { jump: 1080 }, { walk: 1175 },
    { jump: 1495, double: true }, { walk: 1545 }, { walk: 1720 },
    { jump: 1880 }, { walk: 1980 }, { jump: 2180 }, { walk: 2350 },
    { walk: 2450 }, { jump: 2550 }, { walk: 2605 }, { jump: 2810, double: true },
    { walk: 2875 }, { walk: 2980 }, { jump: 3225, double: true }, { exit: 3320 }
  ],
  [
    { walk: 230 }, { jump: 330 }, { walk: 390 }, { jump: 510 },
    { walk: 555 }, { jump: 700 }, { walk: 760 }, { jump: 970, double: true },
    { walk: 985 }, { walk: 1070 }, { jump: 1250 }, { walk: 1305 },
    { jump: 1470 }, { walk: 1550 }, { walk: 1660 }, { jump: 1785 },
    { walk: 1810 }, { jump: 1930 }, { walk: 1970 }, { jump: 2110 },
    { walk: 2160 }, { jump: 2345, double: true }, { walk: 2355 },
    { walk: 2450 }, { jump: 2680, double: true }, { walk: 2730 },
    { jump: 2850 }, { walk: 2890 }, { exit: 3030 }
  ],
  [
    { walk: 260 }, { jump: 395 }, { walk: 440 }, { jump: 615, double: true },
    { walk: 580 }, { jump: 435 }, { walk: 435 }, { jump: 735, double: true },
    { walk: 865 }, { jump: 1070, double: true }, { walk: 1120 },
    { jump: 1350 }, { walk: 1430 }, { jump: 1580 }, { walk: 1630 },
    { jump: 1800 }, { walk: 1860 }, { jump: 2100, double: true },
    { walk: 2135 }, { walk: 2200 }, { jump: 2425 }, { walk: 2440 },
    { jump: 2600 }, { walk: 2630 }, { jump: 2840, double: true },
    { walk: 2845 }, { walk: 2930 }, { jump: 3150, double: true },
    { walk: 3220 }, { jump: 3400, double: true }, { exit: 3470 }
  ],
  [
    { walk: 350 }, { jump: 585 }, { jump: 765 }, { jump: 985, double: true },
    { walk: 1065 }, { walk: 1160 }, { jump: 1410, double: true },
    { jump: 1530 }, { walk: 1560 }, { jump: 1780, double: true },
    { walk: 1835 }, { walk: 1910 }, { jump: 2120 }, { walk: 2160 },
    { jump: 2465, double: true }, { walk: 2505 }, { walk: 2680 },
    { jump: 2930, double: true }, { jump: 3140, double: true }, { exit: 3320 }
  ]
];
